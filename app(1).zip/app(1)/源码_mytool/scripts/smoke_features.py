# -*- coding: utf-8 -*-
"""全功能冒烟：遍历全部 67 项，每项用一份合理输入跑一次，报告结果分布。

    python scripts/smoke_features.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from qingcha import features

# 每项的测试输入（按 params 顺序）
SAMPLE = {
    'sgh': ['13800138000'], 'cx': ['110101199003074514'], 'xm': ['张三'],
    'wzry': ['测试昵称', '1'], 'cph': ['京A12345'], 'idphoto': [],
    'idcardrand': ['110101'], 'qb': ['10001'], 'mirror': ['110101199003074514'],
    'mghy': ['110101199003074514'], 'jhf': ['张三', '110101199003074514'],
    'd2': ['张三', '110101199003074514'], '3ys': ['张三', '110101199003074514', '13800138000'],
    'yx': ['test@example.com'], 'fr': ['91110108MA01ABCD1E'],
    'sfz': ['110101199003074514'], 'yhgs': ['6222021001116248'],
    'sjhgsd': ['13800138000'], 'k3': ['张三', '110101199003074514', '6222021001116248'],
    'k4': ['张三', '110101199003074514', '13800138000', '6222021001116248'],
    'lm': ['张三', '广东'], 'cxd': ['京A123'], 'hpyj': ['测试昵称', '1'],
    'tyc': ['91110108MA01ABCD1E'], 'jdz': ['张三', '110101199003074514'],
    'bu': ['138', '0000'], 'yyzz': ['91110108MA01ABCD1E'],
    't_idcard': ['110101199003074514'], 't_netaddr': ['192.168.1.0/24'],
}


def main():
    gate = features.gateway_ready()
    print('网关：%s\n' % ('已配置' if gate else '未配置（remote 类会返回提示，属正常）'))
    ok_local = ok_remote_hint = 0
    problems = []
    for f in features.FEATURES:
        vals = SAMPLE.get(f['id'])
        if vals is None:
            vals = ['测试'] * len(f.get('params') or [])
        params = {}
        for i, p in enumerate(f.get('params') or []):
            params[p[0]] = vals[i] if i < len(vals) else ''
        r = features.run(f['id'], params)
        if not r.get('ok'):
            problems.append((f['id'], f['name'], r.get('error')))
            print('✗ %-12s %-12s %s' % (f['id'], f['name'], str(r.get('error'))[:60]))
            continue
        blocks = r.get('blocks') or []
        states = [b.get('state') for b in blocks]
        has_ok = any(s is True for s in states)
        title = blocks[0]['title'] if blocks else '(无结果)'
        flag = '✓' if has_ok else ('·' if f['kind'] in ('remote', 'both') else '?')
        if has_ok:
            ok_local += 1
        elif f['kind'] in ('remote', 'both'):
            ok_remote_hint += 1
        elif f.get('local') in ('ip', 'myip', 'url'):
            ok_remote_hint += 1   # 联网功能受外部限流影响，不算缺陷
        else:
            problems.append((f['id'], f['name'], '无有效结果: ' + title))
        print('%s %-12s %-12s %-4s %s' % (flag, f['id'], f['name'],
                                          f['tab'], title))

    print('\n通过 %d / 提示 %d / 问题 %d / 合计 %d' % (
        ok_local, ok_remote_hint, len(problems), len(features.FEATURES)))
    if problems:
        print('\n需处理：')
        for p in problems:
            print('  %s %s -> %s' % p)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
