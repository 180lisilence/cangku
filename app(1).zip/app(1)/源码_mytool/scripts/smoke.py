# -*- coding: utf-8 -*-
"""全能力冒烟测试：每项能力跑一次真实输入，报告通过/失败。

    python scripts/smoke.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from qingcha import registry

CASES = [
    ('idcard', '11010119900307451X\n44030119851201001X\n110101900307451', {}),
    ('phone', '13800138000\n17012345678\n19212345678\n19912345678\n12345', {}),
    ('bankcard', '6222021001116248\n4532425361234568\n6222021001116245', {}),
    ('uscc', '91110108MA01ABCD1X\n91110108MA01ABCD1E', {}),
    ('plate', '京A12345\n粤B12345D\n京A1234学\n', {}),
    ('netaddr', '8.8.8.8\n192.168.1.0/26\n10.0.0.1\n::1', {}),
    ('ipgeo', '8.8.8.8', {}),
    ('hash', 'hello', {}),
    ('b64', 'hello world', {}),
    ('urlc', '中文 test&a=1', {}),
    ('hexc', '48656c6c6f', {}),
    ('ts', '1700000000', {}),
    ('json', '{"b":1,"a":[2,3]}', {'indent': 2, 'sort': True}),
    ('stats', 'hello 世界\n第二行', {}),
    ('dedupe', 'b\na\nb\nc', {}),
    ('idgen', '', {'area': '330106', 'birth': '19950812', 'gender': '女', 'count': 3}),
    ('usccgen', '91110108MA01ABCD1', {}),
    ('custom', 'test', {'provider': ''}),
]


def main():
    ok = 0
    fail = 0
    for cap, text, opts in CASES:
        r = registry.run(cap, text, opts)
        if not r.get('ok'):
            print('✗ %-10s 执行异常: %s' % (cap, r.get('error')))
            fail += 1
            continue
        items = r['items']
        bad = sum(1 for i in items if i['valid'] is False)
        # ipgeo 属联网，失败可接受但要标出来
        flag = '✓'
        if cap == 'ipgeo' and not any(i['valid'] for i in items):
            flag = '~'
        print('%s %-10s %2d 条 (未通过 %d)  %s' % (
            flag, cap, len(items), bad,
            ' | '.join(i['title'][:26] for i in items[:2])))
        if not items:
            print('   !! 返回 0 条')
            fail += 1
            continue
        ok += 1
    print('\n通过 %d / %d' % (ok, len(CASES)))
    return 0 if fail == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
