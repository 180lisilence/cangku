# -*- coding: utf-8 -*-
"""把 china-division 的 pcas-code.json 压成本地区划表 data/region.json

源数据是分层树，code 长度：2=省 4=市 6=区县 9=街道。
身份证前 6 位对应到「区县」层，所以只保留 len<=6 的节点（街道丢弃且不再递归）。
"""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qingcha import net

SRC = [
    'https://unpkg.com/china-division@2.7.0/dist/pcas-code.json',
    'https://registry.npmmirror.com/china-division/2.7.0/files/dist/pcas-code.json',
]
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(HERE, 'data', 'region.json')

raw = None
for u in SRC:
    try:
        r = net.get(u, timeout=40)
        if r.status == 200 and len(r.body) > 100000:
            raw = r.json(); print('抓取成功', u, len(r.body)); break
    except Exception as e:
        print('失败', u, e)
if raw is None:
    sys.exit('全部数据源失败')

flat = {}
def walk(nodes):
    for n in nodes:
        code = str(n.get('code', ''))
        if not code.isdigit() or len(code) > 6:
            continue
        flat[code] = n['name']
        walk(n.get('children') or [])
walk(raw)

os.makedirs(os.path.dirname(OUT), exist_ok=True)
with open(OUT, 'w', encoding='utf-8') as f:
    json.dump(flat, f, ensure_ascii=False, separators=(',', ':'), sort_keys=True)

prov = sum(1 for k in flat if len(k) == 2)
city = sum(1 for k in flat if len(k) == 4)
cnt = sum(1 for k in flat if len(k) == 6)
print('省级 %d / 地级 %d / 区县 %d / 合计 %d' % (prov, city, cnt, len(flat)))
print('输出 %s %d bytes' % (OUT, os.path.getsize(OUT)))
