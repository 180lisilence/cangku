# -*- coding: utf-8 -*-
"""启动本地 Web 界面。

    python run.py            # 自动选端口并打开浏览器
    python run.py 9000       # 指定端口
    python run.py --no-open  # 不自动开浏览器
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from qingcha import server


def main():
    args = [a for a in sys.argv[1:]]
    no_open = '--no-open' in args
    # 网关快速导入：--gateway base [key]  或  --gateway "base|key"
    gw_parts = []
    if '--gateway' in sys.argv:
        gi = sys.argv.index('--gateway')
        j = gi + 1
        while j < len(sys.argv) and not sys.argv[j].startswith('--') \
                and not sys.argv[j].isdigit():
            gw_parts.append(sys.argv[j])
            j += 1
    if gw_parts:
        from qingcha import features
        cfg = features.apply_gateway_text(' '.join(gw_parts))
        print('网关已写入：base=%s  key=%s' %
              (cfg.get('base'), '已设' if cfg.get('key') else '(空)'))
    args = [a for a in args if not a.startswith('--')]
    port = int(args[0]) if args and args[0].isdigit() else None
    try:
        server.serve(port=port, open_browser=not no_open)
    except OSError as e:
        print('启动失败：%s' % e)
        print('换个端口再试：python run.py 9001')
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
