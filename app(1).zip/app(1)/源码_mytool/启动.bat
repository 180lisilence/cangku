@echo off
chcp 65001 >nul
cd /d "%~dp0"
title 自查工具箱

set PY=
where python >nul 2>nul && set PY=python
if "%PY%"=="" ( where py >nul 2>nul && set PY=py )
if "%PY%"=="" (
  echo [错误] 没有找到 Python，请先安装 Python 3.8+ 并勾选 Add to PATH
  pause
  exit /b 1
)

%PY% run.py
if errorlevel 1 pause
