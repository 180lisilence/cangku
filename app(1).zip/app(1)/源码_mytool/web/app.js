'use strict';

/* ============================================================
   状态
   ============================================================ */
const S = {
  feats: [],
  counts: {},
  tab: 'free',
  page: 'feat',
  cur: null,
  gwReady: false,
  stats: {},
  runs: Number(localStorage.getItem('qc_runs') || 0),
};

const $ = id => document.getElementById(id);

/* 素描风头像（统一，复刻原版列表观感） */
const AVA = `<svg viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
<defs><linearGradient id="ag" x1="0" y1="0" x2="0" y2="1">
<stop offset="0" stop-color="#f6f6f7"/><stop offset="1" stop-color="#e4e4e7"/></linearGradient></defs>
<circle cx="24" cy="24" r="24" fill="url(#ag)"/>
<g stroke-linecap="round" stroke-linejoin="round">
  <!-- 长发外轮廓 -->
  <path d="M24 7.4c-7.9 0-13.2 5.8-13.2 14.2 0 5.2 1.1 9.9 2.7 13.1-1.7.6-2.9.5-3.9-.2C8.2 31.6 7.6 26 8.6 21 10.2 13 16.3 6.6 24 6.6s13.8 6.4 15.4 14.4c1 5 .4 10.6-.9 13.5-1 .7-2.2.8-3.9.2 1.6-3.2 2.7-7.9 2.7-13.1C37.2 13.2 31.9 7.4 24 7.4z" fill="#5d5d64"/>
  <!-- 脸 -->
  <path d="M17.6 24.2c0 6.2 2.9 10.3 6.4 10.3s6.4-4.1 6.4-10.3c0-6-2.9-9.6-6.4-9.6s-6.4 3.6-6.4 9.6z" fill="#fdfdfe"/>
  <!-- 刘海 -->
  <path d="M17.2 21.6c1.1-5.2 3.8-7.9 6.8-7.9s5.7 2.7 6.8 7.9c-1.9-2.7-4.1-4-6.8-4s-4.9 1.3-6.8 4z" fill="#4f4f56"/>
  <!-- 双侧发丝 -->
  <path d="M16.1 22.4c-.9 4.6-.6 8.6.6 11.6" stroke="#6a6a71" stroke-width="1.15" fill="none"/>
  <path d="M31.9 22.4c.9 4.6.6 8.6-.6 11.6" stroke="#6a6a71" stroke-width="1.15" fill="none"/>
  <!-- 眉 -->
  <path d="M19.1 23.1c.9-.55 2-.55 2.9-.1" stroke="#8d8d94" stroke-width=".75" fill="none"/>
  <path d="M26 23c.9-.45 2-.45 2.9.1" stroke="#8d8d94" stroke-width=".75" fill="none"/>
  <!-- 眼 -->
  <ellipse cx="20.7" cy="25.4" rx="1.05" ry="1.45" fill="#3f3f46"/>
  <ellipse cx="27.3" cy="25.4" rx="1.05" ry="1.45" fill="#3f3f46"/>
  <circle cx="20.35" cy="24.9" r=".34" fill="#fff"/>
  <circle cx="26.95" cy="24.9" r=".34" fill="#fff"/>
  <!-- 鼻与嘴 -->
  <path d="M24 26.9v1.7" stroke="#d6d6db" stroke-width=".7" fill="none"/>
  <path d="M22.7 30.4q1.3 1.05 2.6 0" stroke="#c2c2c9" stroke-width=".85" fill="none"/>
  <!-- 颈与肩 -->
  <path d="M20.9 34.2c.6 1.4 1.7 2.2 3.1 2.2s2.5-.8 3.1-2.2" stroke="#dcdce1" stroke-width="1" fill="none"/>
  <path d="M13.8 46.4c.7-5 4.6-8.2 10.2-8.2s9.5 3.2 10.2 8.2z" fill="#e9e9ec"/>
</g>
</svg>`;

const CHEV = `<svg class="chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 5l7 7-7 7"/></svg>`;

/* ============================================================
   初始化
   ============================================================ */
async function boot() {
  try {
    const [fr, sr, gr] = await Promise.all([
      fetch('/api/features').then(r => r.json()),
      fetch('/api/stats').then(r => r.json()),
      fetch('/api/gateway').then(r => r.json()),
    ]);
    S.feats = fr.features || [];
    S.counts = fr.counts || {};
    S.gwReady = !!fr.gateway_ready;
    S.stats = sr.stats || {};
    fillGateway(gr.gateway || {});
  } catch (e) {
    $('list').innerHTML = '<div class="empty">无法连接本地服务<br><span style="font-size:11px">' + esc(e.message) + '</span></div>';
    return;
  }
  renderTabs();
  renderList();
  renderStats();
  renderMe();
  bindNav();

  // 支持 #/f/<id> 直达某功能，#/f/<id>?q=xxx 自动填充并执行，便于收藏与分享
  if (location.hash === '#/me') { go('me'); return; }
  if (location.hash === '#/home') { go('home'); return; }
  const m = location.hash.match(/^#\/f\/([\w]+)(?:\?(.*))?$/);
  if (m && S.feats.some(f => f.id === m[1])) {
    go('feat');
    setTimeout(() => {
      openDetail(m[1]);
      if (m[2] != null) {
        const qs = new URLSearchParams(m[2]);
        const q = qs.get('q');
        const feat = S.feats.find(f => f.id === m[1]);
        if (q && feat && feat.params && feat.params.length) {
          const el = $('fld_' + feat.params[0].k);
          if (el) el.value = q;
        }
        setTimeout(runDetail, 140);
      }
    }, 60);
  }
}

/* ============================================================
   统计
   ============================================================ */
function renderStats() {
  const region = S.stats.region_count || 0;
  const phone = S.stats.phone_count || 0;
  const records = region + phone;
  const total = S.counts.total || S.feats.length;
  if ($('s-records')) $('s-records').textContent = fmt(records);
  if ($('s-feats')) $('s-feats').textContent = total;
  if ($('s-total')) $('s-total').textContent = total;
  if ($('a-region')) $('a-region').textContent = fmt(region) + ' 条';
  if ($('a-phone')) $('a-phone').textContent = fmt(phone) + ' 条';
  if ($('a-runs')) $('a-runs').textContent = fmt(S.runs);
  if ($('m-records')) $('m-records').textContent = fmt(records) + ' 条';
  if ($('m-feats')) $('m-feats').textContent = total + ' 项';
  const local = S.feats.filter(f => f.kind !== 'remote').length;
  if ($('a-local')) $('a-local').textContent = local + ' 项';
  if ($('a-remote')) $('a-remote').textContent = (S.feats.length - local) + ' 项';
  bumpRuns();
}

function bumpRuns() {
  const el = $('s-runs');
  if (el) el.textContent = fmt(S.runs);
  const a = $('a-runs');
  if (a) a.textContent = fmt(S.runs);
}

/* ============================================================
   功能列表
   ============================================================ */
const TABS = [
  { k: 'free', label: 'Free-免费版' },
  { k: 'pro', label: 'Pro-高级版' },
  { k: 'pro2', label: 'Pro-其他功能' },
];

function renderTabs() {
  $('tabs').innerHTML = TABS.map(t =>
    `<div class="tab ${t.k === S.tab ? 'on' : ''}" data-tab="${t.k}">${t.label}</div>`
  ).join('');
  $('tabs').querySelectorAll('.tab').forEach(el => {
    el.onclick = () => {
      S.tab = el.dataset.tab;
      renderTabs();
      renderList();
      $('page-feat').scrollTo({ top: 0, behavior: 'smooth' });
    };
  });
}

function renderList() {
  const arr = S.feats.filter(f => f.tab === S.tab);
  if (!arr.length) {
    $('list').innerHTML = '<div class="empty">该分类暂无功能</div>';
    return;
  }
  $('list').innerHTML = arr.map(f => {
    const tag = f.kind === 'remote'
      ? '<span class="tagl gw">需网关</span>'
      : '<span class="tagl local">本地</span>';
    return `<div class="item" data-id="${f.id}">
      <div class="ava">${AVA}</div>
      <div class="txt">
        <div class="t">${esc(f.name)}${tag}</div>
        <div class="s">${esc(f.en || '')}</div>
      </div>
      ${CHEV}
    </div>`;
  }).join('');
  $('list').querySelectorAll('.item').forEach(el => {
    el.onclick = () => openDetail(el.dataset.id);
  });
}

/* ============================================================
   详情页
   ============================================================ */
function openDetail(id) {
  const f = S.feats.find(x => x.id === id);
  if (!f) return;
  S.cur = f;
  $('d-name').textContent = f.name;
  $('d-en').textContent = f.en || '';
  $('d-desc').textContent = f.desc || '';

  let html = '';
  const ps = f.params || [];
  if (!ps.length) {
    html = '<div class="empty" style="padding:18px 0;font-size:12px">此功能无需输入，直接查询</div>';
  } else {
    ps.forEach(p => {
      if (p.k === 'style') {
        html += field(p, `<select id="fld_${p.k}">` +
          ['一寸', '二寸', '小一寸', '大一寸', '小二寸', '五寸']
            .map(o => `<option>${o}</option>`).join('') + `</select>`);
      } else if (p.k === 'bg') {
        html += field(p, `<select id="fld_${p.k}">` +
          ['白', '蓝', '红', '灰'].map(o => `<option>${o}</option>`).join('') + `</select>`);
      } else if (p.k === 'gender') {
        html += field(p, `<select id="fld_${p.k}"><option>男</option><option>女</option></select>`);
      } else {
        html += field(p, `<input id="fld_${p.k}" placeholder="${esc(p.ph || '')}" autocomplete="off">`);
      }
    });
  }
  $('d-fields').innerHTML = html;
  $('d-res').innerHTML = '';

  if (f.kind === 'remote' && !S.gwReady) {
    $('d-res').innerHTML = `<div class="blk na">
      <div class="bh"><span class="dot"></span>未配置网关</div>
      <table class="kv">
        <tr><td class="k">当前状态</td><td class="v">该功能需要接口网关才能查询</td></tr>
        <tr><td class="k">配置方法</td><td class="v">底部「我的」→ 网关设置 → 填地址与密钥</td></tr>
      </table></div>`;
  }

  $('page-detail').classList.remove('hide-right');
  $('page-feat').classList.add('hide-left');
  S.page = 'detail';
  const first = $('d-fields').querySelector('input,select');
  if (first) setTimeout(() => first.focus(), 320);
}

function field(p, ctrl) {
  return `<div class="field"><label>${esc(p.label)}</label>${ctrl}</div>`;
}

async function runDetail() {
  if (!S.cur) return;
  const f = S.cur;
  const params = {};
  (f.params || []).forEach(p => {
    const el = $('fld_' + p.k);
    params[p.k] = el ? el.value.trim() : '';
  });

  const btn = $('d-run');
  btn.disabled = true;
  btn.innerHTML = '<span class="spin"></span>查询中';
  $('d-res').innerHTML = '';

  try {
    const r = await fetch('/api/feature', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: f.id, params: params }),
    });
    const j = await r.json();
    renderResult(j);
    S.runs += 1;
    localStorage.setItem('qc_runs', S.runs);
    bumpRuns();
  } catch (e) {
    $('d-res').innerHTML = `<div class="blk bad"><div class="bh"><span class="dot"></span>请求失败</div>
      <div class="note">${esc(e.message)}</div></div>`;
  } finally {
    btn.disabled = false;
    btn.textContent = '查询';
  }
}

function renderResult(j) {
  const box = $('d-res');
  if (!j.ok) {
    box.innerHTML = `<div class="blk bad"><div class="bh"><span class="dot"></span>执行出错</div>
      <div class="note">${esc(j.error || '未知错误')}</div></div>`;
    return;
  }
  let html = '';
  if (j.draw) html += `<canvas class="draw" id="cv"></canvas>`;

  (j.blocks || []).forEach(b => {
    const cls = b.state === true ? 'ok' : (b.state === false ? 'bad' : 'na');
    html += `<div class="blk ${cls}"><div class="bh"><span class="dot"></span>${esc(b.title)}</div>`;
    if (b.rows && b.rows.length) {
      html += '<table class="kv">' + b.rows.map(r =>
        `<tr><td class="k">${esc(r[0])}</td><td class="v">${esc(r[1])}</td></tr>`
      ).join('') + '</table>';
    }
    if (b.tags && b.tags.length) {
      html += '<div class="tags">' + b.tags.map(t =>
        `<span class="tag">${esc(t)}</span>`).join('') + '</div>';
    }
    if (b.note) html += `<div class="note">${esc(b.note)}</div>`;
    html += '</div>';
  });

  if (j.raw) {
    html += `<div class="blk na"><div class="bh"><span class="dot"></span>原始返回</div>
      <pre class="raw">${esc(j.raw)}</pre></div>`;
  }

  box.innerHTML = html;
  if (j.draw) drawCanvas(j.draw);
}

/* ============================================================
   Canvas 绘制
   ============================================================ */
function drawCanvas(d) {
  const cv = $('cv');
  if (!cv) return;
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const maxW = Math.max(240, (cv.parentElement.clientWidth || 340) - 24);

  if (d.type === 'idphoto') {
    const scale = Math.min(1, maxW / d.w);
    cv.width = d.w * dpr;
    cv.height = d.h * dpr;
    cv.style.width = (d.w * scale) + 'px';
    cv.style.height = (d.h * scale) + 'px';
    cv.style.margin = '0 auto 11px';
    const g = cv.getContext('2d');
    g.scale(dpr, dpr);
    g.fillStyle = d.bg;
    g.fillRect(0, 0, d.w, d.h);
    const cx = d.w / 2;
    g.fillStyle = 'rgba(150,150,158,.30)';
    g.beginPath(); g.arc(cx, d.h * 0.40, d.w * 0.155, 0, Math.PI * 2); g.fill();
    g.beginPath();
    g.ellipse(cx, d.h * 0.92, d.w * 0.33, d.h * 0.27, 0, 0, Math.PI * 2); g.fill();
    g.strokeStyle = 'rgba(120,120,128,.55)';
    g.lineWidth = 1.4;
    g.beginPath(); g.arc(cx, d.h * 0.40, d.w * 0.155, 0, Math.PI * 2); g.stroke();
    g.fillStyle = 'rgba(0,0,0,.22)';
    g.font = '11px sans-serif';
    g.fillText(d.label + ' · ' + d.w + '×' + d.h, 8, d.h - 8);
  } else if (d.type === 'idcard') {
    const W = Math.min(maxW / 2, 300), H = W * 0.66;
    cv.width = W * 2 * dpr;
    cv.height = H * dpr;
    cv.style.width = (W * 2) + 'px';
    cv.style.height = H + 'px';
    cv.style.margin = '0 auto 11px';
    const g = cv.getContext('2d');
    g.scale(dpr, dpr);
    cardFront(g, 0, 0, W, H, d);
    cardBack(g, W, 0, W, H, d);
  } else if (d.type === 'yyzz') {
    const W = Math.min(maxW, 340), H = W * 1.42;
    cv.width = W * dpr;
    cv.height = H * dpr;
    cv.style.width = W + 'px';
    cv.style.height = H + 'px';
    cv.style.margin = '0 auto 11px';
    const g = cv.getContext('2d');
    g.scale(dpr, dpr);
    licenseDraw(g, 0, 0, W, H, d);
  }
}

function cardFront(g, x, y, W, H, d) {
  g.save();
  g.translate(x, y);
  g.fillStyle = '#f7f8f6';
  g.fillRect(0, 0, W, H);
  g.strokeStyle = '#e2e2e2';
  g.strokeRect(.5, .5, W - 1, H - 1);
  g.fillStyle = '#2a4a7a';
  g.font = 'bold 7px sans-serif';
  g.fillText('中华人民共和国', 10, 15);
  g.font = 'bold 10px sans-serif';
  g.fillText('居民身份证', 10, 27);
  g.strokeStyle = '#cfcfcf';
  g.beginPath(); g.moveTo(10, 32); g.lineTo(W - 10, 32); g.stroke();

  g.fillStyle = '#e9e9e9';
  g.fillRect(W - 62, 40, 50, 62);
  g.strokeStyle = '#d4d4d4';
  g.strokeRect(W - 62, 40, 50, 62);
  g.fillStyle = '#bcbcbc';
  g.font = '6px sans-serif';
  g.textAlign = 'center';
  g.fillText('照片', W - 37, 74);
  g.textAlign = 'left';

  const gd = (d.gender || '男') === '女' ? '女' : '男';
  const rows = [['姓　名', '示 例 姓 名'],
                ['性　别', gd + '　　汉'],
                ['出　生', d.birth || ''],
                ['住　址', d.addr || '']];
  rows.forEach((r, i) => {
    const yy = 46 + i * 12;
    g.fillStyle = '#9a9a9a'; g.font = '6px sans-serif';
    g.fillText(r[0], 10, yy);
    g.fillStyle = '#222'; g.font = '7px sans-serif';
    const txt = r[1].length > 12 ? r[1].slice(0, 12) + '…' : r[1];
    g.fillText(txt, 38, yy);
  });
  g.fillStyle = '#9a9a9a'; g.font = '6px sans-serif';
  g.fillText('公民身份号码', 10, H - 15);
  g.fillStyle = '#111'; g.font = 'bold 9px monospace';
  g.fillText(d.no || '', 10, H - 5);
  g.fillStyle = 'rgba(0,0,0,.20)'; g.font = '5.5px sans-serif';
  g.fillText('图样演示', W - 38, 9);
  g.restore();
}

function cardBack(g, x, y, W, H) {
  g.save();
  g.translate(x, y);
  g.fillStyle = '#f7f8f6';
  g.fillRect(0, 0, W, H);
  g.strokeStyle = '#e2e2e2';
  g.strokeRect(.5, .5, W - 1, H - 1);
  g.fillStyle = '#2a4a7a';
  g.font = 'bold 8px sans-serif';
  g.fillText('中华人民共和国', 10, 18);
  g.fillText('居民身份证', 10, 30);
  g.strokeStyle = '#cfcfcf';
  g.beginPath(); g.moveTo(10, 36); g.lineTo(W - 10, 36); g.stroke();

  g.fillStyle = '#9a9a9a'; g.font = '6px sans-serif';
  g.fillText('签发机关', 10, H - 32);
  g.fillText('有效期限', 10, H - 16);
  g.fillStyle = '#222'; g.font = '7px sans-serif';
  const iss = d.issuer || '公安机关';
  g.fillText(iss.length > 12 ? iss.slice(0, 12) + '…' : iss, 52, H - 32);
  g.fillText(d.term || '—', 52, H - 16);
  g.fillStyle = 'rgba(0,0,0,.20)'; g.font = '5.5px sans-serif';
  g.fillText('图样演示', W - 38, 9);
  g.restore();
}

function licenseDraw(g, x, y, W, H, d) {
  g.save();
  g.fillStyle = '#fbfaf6';
  g.fillRect(0, 0, W, H);
  g.strokeStyle = '#d9d4c4';
  g.lineWidth = 2;
  g.strokeRect(6, 6, W - 12, H - 12);
  g.fillStyle = '#8a1f1f';
  g.font = 'bold 19px serif';
  g.textAlign = 'center';
  g.fillText('营 业 执 照', W / 2, 52);
  g.font = '7.5px sans-serif';
  g.fillStyle = '#9a9a9a';
  g.fillText('图样演示 · 无法律效力', W / 2, 66);
  g.textAlign = 'left';
  g.strokeStyle = '#e3ded0';
  g.lineWidth = 1;
  g.beginPath(); g.moveTo(20, 78); g.lineTo(W - 20, 78); g.stroke();

  const items = [
    ['名　　称', d.name || '—'],
    ['统一社会信用代码', d.code || '—'],
    ['类　　型', '有限责任公司'],
    ['法定代表人', '—'],
    ['经营范围', '（示例）技术开发、技术服务'],
    ['住　　所', '—'],
  ];
  items.forEach((it, i) => {
    const yy = 100 + i * 30;
    g.fillStyle = '#9a9a9a'; g.font = '7.5px sans-serif';
    g.fillText(it[0], 22, yy);
    g.fillStyle = '#2a2a2a'; g.font = '8px sans-serif';
    const txt = it[1].length > 20 ? it[1].slice(0, 20) + '…' : it[1];
    g.fillText(txt, 22, yy + 12);
  });

  g.strokeStyle = '#c9a3a3';
  g.beginPath(); g.arc(W - 56, H - 56, 28, 0, Math.PI * 2); g.stroke();
  g.fillStyle = '#b06565';
  g.font = '6.5px sans-serif';
  g.textAlign = 'center';
  g.fillText('登记机关', W - 56, H - 58);
  g.fillText('专用章', W - 56, H - 48);
  g.restore();
}

/* ============================================================
   我的 / 网关
   ============================================================ */
function fillGateway(g) {
  if ($('gw-base')) $('gw-base').value = g.base || '';
  if ($('gw-key')) $('gw-key').value = '';
  const st = $('gw-state');
  if (st) {
    const on = !!g.base;
    st.className = 'state ' + (on ? 'on' : 'off');
    st.textContent = on ? '已配置' : '未配置';
  }
  if (g.key_masked && $('gw-key')) {
    $('gw-key').placeholder = '已保存 ' + g.key_masked + '（重填可覆盖）';
  }
}

function renderMe() {
  const st = $('gw-state');
  if (st) {
    st.className = 'state ' + (S.gwReady ? 'on' : 'off');
    st.textContent = S.gwReady ? '已配置' : '未配置';
  }
}

async function saveGateway() {
  const body = {
    base: ($('gw-base').value || '').trim(),
    key: ($('gw-key').value || '').trim(),
  };
  try {
    const r = await fetch('/api/gateway', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    const j = await r.json();
    S.gwReady = !!j.ready;
    renderMe();
    $('gw-key').value = '';
    toast(j.ready ? '已保存，联网功能可用' : '已保存（base 为空，仍为未配置）');
  } catch (e) {
    toast('保存失败：' + e.message);
  }
}

async function clearKey() {
  try {
    await fetch('/api/gateway', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ clear_key: true }),
    });
    $('gw-key').value = '';
    $('gw-key').placeholder = '留空则不发送 key 参数';
    toast('密钥已清除');
  } catch (e) {
    toast('清除失败');
  }
}

async function importGateway() {
  const t = ($('gw-text').value || '').trim();
  if (!t) { toast('请先粘贴接口信息'); return; }
  try {
    const r = await fetch('/api/gateway', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: t }),
    });
    const j = await r.json();
    S.gwReady = !!j.ready;
    const c = await fetch('/api/gateway').then(r => r.json());
    fillGateway(c.gateway || {});
    renderMe();
    toast(j.ready ? '已识别并保存，联网功能可用' : '已保存，但未识别到地址，请检查粘贴内容');
  } catch (e) {
    toast('失败：' + e.message);
  }
}

function toast(msg) {
  const d = document.createElement('div');
  d.textContent = msg;
  d.style.cssText = 'position:fixed;left:50%;bottom:100px;transform:translateX(-50%);' +
    'background:#1c1c1e;color:#fff;padding:10px 20px;border-radius:22px;font-size:13px;' +
    'z-index:99;box-shadow:0 6px 24px rgba(0,0,0,.24);opacity:0;transition:opacity .2s;' +
    'max-width:80vw;text-align:center';
  document.body.appendChild(d);
  requestAnimationFrame(() => { d.style.opacity = '1'; });
  setTimeout(() => { d.style.opacity = '0'; setTimeout(() => d.remove(), 250); }, 1700);
}

/* ============================================================
   导航
   ============================================================ */
function go(page) {
  S.page = page;
  const P = { home: 'page-home', feat: 'page-feat', me: 'page-me', detail: 'page-detail' };
  Object.keys(P).forEach(k => {
    const el = $(P[k]);
    if (!el) return;
    el.classList.remove('hide-right', 'hide-left', 'hide-down');
    if (k !== page) el.classList.add(k === 'detail' ? 'hide-right' : 'hide-down');
  });
  document.querySelectorAll('.navbar .nb').forEach(el => {
    el.classList.toggle('on', el.dataset.go === page ||
      (page === 'detail' && el.dataset.go === 'feat'));
  });
  if (page === 'me') renderMe();
}

function bindNav() {
  document.querySelectorAll('.navbar .nb').forEach(el => {
    el.onclick = () => go(el.dataset.go);
  });
  $('back').onclick = () => go('feat');
  $('d-run').onclick = runDetail;
  $('gw-save').onclick = saveGateway;
  $('gw-clear').onclick = clearKey;
  $('gw-import').onclick = importGateway;
  document.addEventListener('keydown', e => {
    if (e.key === 'Enter' && S.page === 'detail' && e.target.tagName === 'INPUT') {
      e.preventDefault();
      runDetail();
    }
    if (e.key === 'Escape' && S.page === 'detail') go('feat');
  });
}

/* ============================================================
   工具
   ============================================================ */
function esc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function fmt(n) {
  return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

boot();
