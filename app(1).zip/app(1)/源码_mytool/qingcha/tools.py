# -*- coding: utf-8 -*-
"""通用工具：哈希、编解码、时间戳、文本统计。全部纯离线、无外部依赖。"""
from __future__ import annotations

import base64
import binascii
import datetime
import hashlib
import json
import time
import urllib.parse


def hash_all(text: str) -> dict:
    b = (text or '').encode('utf-8')
    return {
        'input_len_chars': len(text or ''),
        'input_len_bytes': len(b),
        'md5': hashlib.md5(b).hexdigest(),
        'sha1': hashlib.sha1(b).hexdigest(),
        'sha256': hashlib.sha256(b).hexdigest(),
        'sha512': hashlib.sha512(b).hexdigest(),
        'sha3_256': hashlib.sha3_256(b).hexdigest(),
        'blake2b': hashlib.blake2b(b).hexdigest(),
        'crc32': format(binascii.crc32(b) & 0xFFFFFFFF, '08x'),
    }


def b64(text: str, urlsafe: bool = False) -> dict:
    b = (text or '').encode('utf-8')
    enc = base64.urlsafe_b64encode(b) if urlsafe else base64.b64encode(b)
    out = {'encode': enc.decode('ascii')}
    try:
        dec = base64.urlsafe_b64decode(text + '=' * (-len(text) % 4)) if urlsafe \
            else base64.b64decode(text + '=' * (-len(text) % 4))
        out['decode'] = dec.decode('utf-8')
    except Exception as e:
        out['decode'] = ''
        out['decode_error'] = '%s: %s' % (type(e).__name__, e)
    return out


def url_code(text: str) -> dict:
    return {
        'quote': urllib.parse.quote(text or '', safe=''),
        'quote_plus': urllib.parse.quote_plus(text or ''),
        'unquote': urllib.parse.unquote(text or ''),
        'unquote_plus': urllib.parse.unquote_plus(text or ''),
    }


def hex_code(text: str) -> dict:
    b = (text or '').encode('utf-8')
    out = {'encode': b.hex(), 'encode_upper': b.hex().upper(),
           'encode_spaced': ' '.join('%02x' % c for c in b)}
    try:
        raw = bytes.fromhex((text or '').replace(' ', '').replace('0x', ''))
        out['decode'] = raw.decode('utf-8')
    except Exception as e:
        out['decode'] = ''
        out['decode_error'] = '%s: %s' % (type(e).__name__, e)
    return out


def ts(expr: str) -> dict:
    """时间戳与时间互转。expr 可以是 10/13 位数字，或 'YYYY-MM-DD HH:MM:SS'。"""
    s = (expr or '').strip()
    res = {'input': expr, 'now': int(time.time())}
    if not s:
        s = str(int(time.time()))
    # 纯数字 → 当时间戳
    if s.replace('.', '').isdigit():
        v = float(s)
        if v > 1e11:  # 毫秒
            sec = v / 1000.0
        else:
            sec = v
        try:
            dt = datetime.datetime.fromtimestamp(sec)
        except (OverflowError, OSError, ValueError) as e:
            res['error'] = '超出可表示范围：%s' % e
            return res
        res.update({
            'kind': '时间戳',
            'seconds': int(sec),
            'milliseconds': int(sec * 1000),
            'local': dt.strftime('%Y-%m-%d %H:%M:%S'),
            'utc': datetime.datetime.utcfromtimestamp(sec).strftime('%Y-%m-%d %H:%M:%S UTC'),
            'iso': dt.isoformat(),
            'weekday': '一二三四五六日'[dt.weekday()],
            'date': dt.strftime('%Y-%m-%d'),
        })
        return res

    # 当时间字符串解析
    fmts = ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M', '%Y-%m-%d',
            '%Y/%m/%d %H:%M:%S', '%Y/%m/%d', '%Y%m%d%H%M%S', '%Y%m%d')
    for f in fmts:
        try:
            dt = datetime.datetime.strptime(s, f)
        except ValueError:
            continue
        res.update({
            'kind': '时间字符串',
            'seconds': int(dt.timestamp()),
            'milliseconds': int(dt.timestamp() * 1000),
            'local': dt.strftime('%Y-%m-%d %H:%M:%S'),
            'iso': dt.isoformat(),
            'weekday': '一二三四五六日'[dt.weekday()],
            'date': dt.strftime('%Y-%m-%d'),
            'fmt_matched': f,
        })
        return res
    res['error'] = '既不是时间戳也不是可识别的时间格式'
    return res


def text_stats(text: str) -> dict:
    t = text or ''
    lines = t.splitlines() or ['']
    words = t.split()
    cjk = sum(1 for c in t if '\u4e00' <= c <= '\u9fff')
    return {
        'chars': len(t),
        'chars_no_space': len(t.replace(' ', '').replace('\n', '').replace('\t', '')),
        'bytes_utf8': len(t.encode('utf-8')),
        'bytes_gbk': len(t.encode('gbk', 'replace')),
        'lines': len(lines),
        'words_en': len(words),
        'cjk_chars': cjk,
        'unique_chars': len(set(t)),
    }


def json_fmt(text: str, indent: int = 2, sort: bool = False) -> dict:
    try:
        obj = json.loads(text)
    except Exception as e:
        return {'ok': False, 'error': '%s: %s' % (type(e).__name__, e)}
    return {
        'ok': True,
        'pretty': json.dumps(obj, ensure_ascii=False, indent=indent, sort_keys=sort),
        'compact': json.dumps(obj, ensure_ascii=False, separators=(',', ':'), sort_keys=sort),
    }


def dedupe(text: str, sort_result: bool = True) -> dict:
    seen, out = set(), []
    for line in (text or '').splitlines():
        k = line.strip()
        if k and k not in seen:
            seen.add(k)
            out.append(line)
    if sort_result:
        out.sort()
    return {'count': len(out), 'result': '\n'.join(out)}
