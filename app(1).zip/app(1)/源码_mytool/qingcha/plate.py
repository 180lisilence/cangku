# -*- coding: utf-8 -*-
"""车牌号解析，纯离线。

能确定性做到的：省份归属、号牌类型（普通/新能源/警用/使领馆/军牌/挂车/教练）、
新能源车能源类型（纯电/非纯电）、A 牌（省会）对应。
做不到的：所有发牌机关字母到地市的完整映射（各省自行分配，非国标公开全量），
因此非 A 牌只给「该省第 N 个发牌代号」，不臆造城市名。
"""
from __future__ import annotations

PROV = {
    '京': '北京市', '津': '天津市', '沪': '上海市', '渝': '重庆市',
    '冀': '河北省', '豫': '河南省', '云': '云南省', '辽': '辽宁省',
    '黑': '黑龙江省', '湘': '湖南省', '皖': '安徽省', '鲁': '山东省',
    '新': '新疆维吾尔自治区', '苏': '江苏省', '浙': '浙江省', '赣': '江西省',
    '鄂': '湖北省', '桂': '广西壮族自治区', '甘': '甘肃省', '晋': '山西省',
    '蒙': '内蒙古自治区', '陕': '陕西省', '吉': '吉林省', '闽': '福建省',
    '贵': '贵州省', '粤': '广东省', '青': '青海省', '藏': '西藏自治区',
    '川': '四川省', '宁': '宁夏回族自治区', '琼': '海南省',
}

# A 牌即省会/首府（直辖市 A 牌指市区），这一条是确定的
CAPITAL_A = {
    '京': '北京市区', '津': '天津市区', '沪': '上海市区', '渝': '重庆市区',
    '冀': '石家庄', '豫': '郑州', '云': '昆明', '辽': '沈阳', '黑': '哈尔滨',
    '湘': '长沙', '皖': '合肥', '鲁': '济南', '新': '乌鲁木齐', '苏': '南京',
    '浙': '杭州', '赣': '南昌', '鄂': '武汉', '桂': '南宁', '甘': '兰州',
    '晋': '太原', '蒙': '呼和浩特', '陕': '西安', '吉': '长春', '闽': '福州',
    '贵': '贵阳', '粤': '广州', '青': '西宁', '藏': '拉萨', '川': '成都',
    '宁': '银川', '琼': '海口',
}

# 号牌上的特殊尾字/关键字
SPECIAL = {
    '使': '使领馆车辆', '领': '领馆车辆', '警': '警用车辆',
    '学': '教练车', '挂': '挂车', '港': '粤港澳出入境车辆',
    '澳': '粤港澳出入境车辆', '试': '试验车', '超': '超限运输车',
}

# 军警号牌首字母（2012 式军车号牌为「汉字+字母+5 位」，与民用车牌外形相近）
MILITARY_LETTERS = set('VKHBSLJNGCEZ')
POLICE_HINTS = ('警',)


def parse(plate: str) -> dict:
    raw = (plate or '').strip().upper().replace(' ', '').replace('·', '').replace('.', '')
    res = {
        'input': plate, 'normalized': raw, 'valid': False, 'errors': [], 'warnings': [],
        'province': '', 'issuer': '', 'issuer_hint': '', 'kind': '',
        'energy': '', 'serial': '', 'is_special': False, 'source': 'offline:GA36',
    }
    if not raw:
        res['errors'].append('输入为空')
        return res

    first = raw[0]
    if first not in PROV:
        # 军牌可能是单一字母开头
        if raw[0].isalpha():
            res['kind'] = '可能是军车/特殊号牌（非民用）'
            res['warnings'].append('首位不是省级简称，无法按民用车牌 GA36 规则解析')
            res['valid'] = False
            return res
        res['errors'].append('首位「%s」不是有效的省级简称' % first)
        return res

    res['province'] = PROV[first]
    body = raw[1:]

    if len(body) < 2:
        res['errors'].append('号牌过短')
        return res
    if not body[0].isalpha():
        res['errors'].append('第 2 位必须是发牌机关字母，当前「%s」' % body[0])
        return res

    res['issuer'] = body[0]
    if body[0] == 'A':
        res['issuer_hint'] = CAPITAL_A.get(first, '') + '（省会/首府）'
    else:
        idx = ord(body[0]) - ord('A') + 1
        res['issuer_hint'] = '该省第 %d 个发牌机关代号（省份内非省会城市，具体对应需查当地交管）' % idx

    serial = body[1:]
    res['serial'] = serial
    tail = serial[-1] if serial else ''

    # 特殊号牌（关键字出现在任意位置）
    for k, v in SPECIAL.items():
        if k in raw:
            res['kind'] = v
            res['is_special'] = True
            break

    if not res['kind']:
        if len(raw) == 8:
            # 新能源：小型车序号首位为 D/A/B/C/E(纯电) 或 F/G/H/J/K(非纯电)
            #        大型车序号末位为 D(纯电) / F(非纯电)
            h = serial[0] if serial else ''
            if h in 'DABCE':
                res['kind'] = '新能源小型车'
                res['energy'] = '纯电动'
            elif h in 'FGHJK':
                res['kind'] = '新能源小型车'
                res['energy'] = '非纯电动（插混/增程/燃料电池）'
            elif tail in ('D', 'F'):
                res['kind'] = '新能源大型车'
                res['energy'] = '纯电动' if tail == 'D' else '非纯电动'
            else:
                res['kind'] = '8 位号牌（新能源格式）'
                res['energy'] = '未识别'
                res['warnings'].append('8 位但序号首/末位不符合新能源编码规则，可能是新能源专用号段的特殊编排')
        elif len(raw) == 7:
            res['kind'] = '普通号牌（蓝牌/黄牌，需看车身判定）'
        elif len(raw) == 6:
            res['kind'] = '早期/特殊格式'
            res['warnings'].append('6 位号牌多见于旧式或特殊用途')
        else:
            res['kind'] = '未知格式'
            res['warnings'].append('长度 %d 不常见（普通 7 位、新能源 8 位）' % len(raw))

    # 末位是字母时，普通号牌常见于郊区号段
    if len(raw) == 7 and tail.isalpha() and not res['is_special']:
        res['warnings'].append('末位为字母，通常是该市郊区/远郊号段')

    res['valid'] = bool(res['province'] and res['issuer']) and not res['errors']
    return res


def batch(text: str) -> list:
    out = []
    for line in (text or '').splitlines():
        line = line.strip()
        if line and not line.startswith('#'):
            out.append(parse(line))
    return out
