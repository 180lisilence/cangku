# -*- coding: utf-8 -*-
"""IP / CIDR 计算与归类，纯离线（归属地查询在 providers 里走联网）。"""
from __future__ import annotations

import ipaddress

# 特殊用途网段（RFC 或国内运营商惯例）
SPECIAL_NETS = [
    ('10.0.0.0/8', '私有地址（RFC1918）'),
    ('172.16.0.0/12', '私有地址（RFC1918）'),
    ('192.168.0.0/16', '私有地址（RFC1918）'),
    ('127.0.0.0/8', '本机回环'),
    ('169.254.0.0/16', '链路本地（APIPA）'),
    ('100.64.0.0/10', '运营商级 NAT（CGNAT）'),
    ('0.0.0.0/8', '本网络'),
    ('224.0.0.0/4', '组播'),
    ('240.0.0.0/4', '保留'),
    ('255.255.255.255/32', '广播'),
    ('198.18.0.0/15', '基准测试'),
    ('192.0.2.0/24', '文档示例'),
    ('198.51.100.0/24', '文档示例'),
    ('203.0.113.0/24', '文档示例'),
    ('fc00::/7', 'IPv6 唯一本地地址'),
    ('fe80::/10', 'IPv6 链路本地'),
    ('::1/128', 'IPv6 回环'),
    ('::/128', 'IPv6 未指定'),
]


def _special(ip) -> str:
    for cidr, desc in SPECIAL_NETS:
        try:
            if ip in ipaddress.ip_network(cidr, strict=False):
                return desc
        except (ValueError, TypeError):
            continue
    return ''


def parse(query: str) -> dict:
    q = (query or '').strip().strip('"')
    res = {
        'input': query, 'valid': False, 'errors': [], 'warnings': [],
        'version': '', 'ip': '', 'is_private': False, 'is_global': False,
        'special': '', 'binary': '', 'hex': '', 'decimal': '',
        'cidr': {}, 'type': '', 'source': 'offline:ipaddress',
    }
    if not q:
        res['errors'].append('输入为空')
        return res

    # 带前缀长度 → 按网段处理
    if '/' in q:
        try:
            net = ipaddress.ip_network(q, strict=False)
        except ValueError as e:
            res['errors'].append('网段格式错误：%s' % e)
            return res
        res['valid'] = True
        res['version'] = 'IPv%d' % net.version
        res['cidr'] = {
            'network': str(net.network_address),
            'broadcast': str(net.broadcast_address) if net.version == 4 else '',
            'netmask': str(net.netmask) if net.version == 4 else '',
            'hostmask': str(net.hostmask) if net.version == 4 else '',
            'prefixlen': net.prefixlen,
            'num_addresses': net.num_addresses,
            'usable_hosts': max(0, net.num_addresses - 2) if net.version == 4 and net.prefixlen < 31
                            else net.num_addresses,
            'first_host': str(net.network_address + 1) if net.num_addresses > 2 else '',
            'last_host': str(net.broadcast_address - 1) if net.num_addresses > 2 else '',
            'is_private': net.is_private,
            'strict_input': str(net) == q,
        }
        res['is_private'] = net.is_private
        res['special'] = _special(net.network_address)
        return res

    try:
        ip = ipaddress.ip_address(q)
    except ValueError as e:
        res['errors'].append('不是合法 IP：%s' % e)
        return res

    res['valid'] = True
    res['version'] = 'IPv%d' % ip.version
    res['ip'] = str(ip)
    res['is_private'] = ip.is_private
    res['is_global'] = ip.is_global
    res['special'] = _special(ip)
    res['binary'] = bin(int(ip))[2:].zfill(ip.max_prefixlen)
    res['hex'] = hex(int(ip))
    res['decimal'] = str(int(ip))

    if ip.version == 4:
        o = str(ip).split('.')
        res['octets'] = o
        res['type'] = {
            '0': 'A 类（保留）', '10': 'A 类（私有）',
        }.get(o[0], '')
        first = int(o[0])
        if not res['type']:
            if 1 <= first <= 126:
                res['type'] = 'A 类'
            elif first == 127:
                res['type'] = '回环'
            elif 128 <= first <= 191:
                res['type'] = 'B 类'
            elif 192 <= first <= 223:
                res['type'] = 'C 类'
            elif 224 <= first <= 239:
                res['type'] = 'D 类（组播）'
            elif 240 <= first <= 255:
                res['type'] = 'E 类（保留）'
        # 默认 /24 视图
        res['cidr'] = {
            'network': str(ipaddress.ip_network('%s/24' % ip, strict=False).network_address),
            'prefixlen': 24,
            'num_addresses': 256,
            'usable_hosts': 254,
        }
    else:
        res['type'] = 'IPv6'
        try:
            res['compressed'] = ip.compressed
            res['exploded'] = ip.exploded
        except AttributeError:
            pass
    return res


def int_to_ip(n) -> str:
    n = int(str(n).strip())
    if 0 <= n < 2 ** 32:
        return str(ipaddress.IPv4Address(n))
    if 0 <= n < 2 ** 128:
        return str(ipaddress.IPv6Address(n))
    raise ValueError('超出 IPv6 范围')


def batch(text: str) -> list:
    out = []
    for line in (text or '').splitlines():
        line = line.strip()
        if line and not line.startswith('#'):
            out.append(parse(line))
    return out
