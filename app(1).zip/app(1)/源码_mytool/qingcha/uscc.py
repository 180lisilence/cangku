# -*- coding: utf-8 -*-
"""统一社会信用代码（18 位）校验与解析，纯离线。

依据 GB 32100-2015：
  第 1 位    登记管理部门代码
  第 2 位    机构类别代码
  第 3-8 位  登记管理机关行政区划码
  第 9-17 位 主体标识码（组织机构代码）
  第 18 位   校验码
字符集 31 个：0123456789ABCDEFGHJKLMNPQRTUWXY（去掉了 I O S V Z）
"""
from __future__ import annotations

CHARSET = '0123456789ABCDEFGHJKLMNPQRTUWXY'
WEIGHTS = (1, 3, 9, 27, 19, 26, 16, 17, 20, 29, 25, 13, 8, 24, 10, 30, 28)

DEPT = {
    '1': '机构编制', '2': '外交', '3': '司法行政', '4': '文化',
    '5': '民政', '6': '旅游', '7': '宗教', '8': '工会',
    '9': '工商（市场监管）', 'A': '中央军委改革和编制办公室',
    'N': '农业', 'Y': '其他',
}

CATEGORY = {
    '1': '企业', '2': '个体工商户', '3': '农民专业合作社',
    '4': '事业单位', '5': '社会团体', '6': '民办非企业单位',
    '7': '基金会', '8': '宗教活动场所', '9': '其他',
    'A': '机关', 'B': '群团组织', 'C': '基层群众性自治组织',
    'D': '民办非企业单位（社会服务机构）', 'N': '社会组织',
}


def checksum(body17: str) -> str:
    if len(body17) != 17:
        raise ValueError('需要 17 位')
    s = 0
    for ch, w in zip(body17, WEIGHTS):
        i = CHARSET.find(ch)
        if i < 0:
            raise ValueError('第 %d 位字符 %s 不在允许字符集内' % (body17.find(ch) + 1, ch))
        s += i * w
    return CHARSET[(31 - s % 31) % 31]


def parse(code: str) -> dict:
    from . import idcard
    raw = (code or '').strip().upper().replace(' ', '')
    res = {
        'input': code, 'normalized': raw, 'valid': False, 'errors': [], 'warnings': [],
        'dept': '', 'category': '', 'region': {}, 'org_code': '',
        'check_given': '', 'check_expect': '', 'source': 'offline:GB32100',
    }
    if not raw:
        res['errors'].append('输入为空')
        return res
    if len(raw) != 18:
        res['errors'].append('长度必须是 18 位，当前 %d 位' % len(raw))
        return res

    bad = [(i + 1, c) for i, c in enumerate(raw) if c not in CHARSET]
    if bad:
        res['errors'].append('含非法字符：' + '、'.join('第%d位"%s"' % b for b in bad))
        return res

    res['dept'] = DEPT.get(raw[0], '未知(%s)' % raw[0])
    res['category'] = CATEGORY.get(raw[1], '未知(%s)' % raw[1])

    area6 = raw[2:8]
    reg = idcard._resolve_region(area6)
    res['region'] = reg
    if not reg['known']:
        res['warnings'].append('行政区划码 %s 不在现行区划表中' % area6)

    res['org_code'] = raw[8:17]
    expect = checksum(raw[:17])
    res['check_given'] = raw[17]
    res['check_expect'] = expect
    if raw[17] != expect:
        res['errors'].append('校验码不符：给的是 %s，应为 %s' % (raw[17], expect))

    res['valid'] = not res['errors']
    return res


def make(body17: str) -> str:
    b = (body17 or '').strip().upper()
    if len(b) != 17:
        raise ValueError('需要 17 位')
    return b + checksum(b)


def batch(text: str) -> list:
    out = []
    for line in (text or '').splitlines():
        line = line.strip()
        if line and not line.startswith('#'):
            out.append(parse(line))
    return out
