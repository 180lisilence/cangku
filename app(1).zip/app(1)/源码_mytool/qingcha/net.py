# -*- coding: utf-8 -*-
"""自管 HTTP 客户端。

设计要点（为什么不用 urllib）：
  1. urllib 会自动读取 HTTP_PROXY/HTTPS_PROXY 环境变量。若该代理对 TLS
     处理不完善，https 请求会抛 SSL: UNEXPECTED_EOF_WHILE_READING，且报错
     信息完全看不出是代理导致的（本机实测踩过）。
  2. 本模块默认【直连】，只有显式传入 proxy 或设置 MYTOOL_PROXY 才走代理。
  3. 不依赖第三方库，只用标准库 socket / ssl / http.client，便于 PyInstaller 打包。
"""
from __future__ import annotations

import gzip
import http.client
import os
import socket
import ssl
import time
import urllib.parse
import zlib

DEFAULT_UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
    '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
)

_CTX = None


def _ctx(insecure: bool = True) -> ssl.SSLContext:
    """宽松 SSL 上下文。默认不校验证书（大量小站证书链残缺），但仍然加密。"""
    global _CTX
    if _CTX is not None and insecure:
        return _CTX
    c = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    c.check_hostname = False
    c.verify_mode = ssl.CERT_NONE
    try:  # 提高兼容性，部分站点仍只支持 TLS1.2 且 ciphers 较老
        c.set_ciphers('DEFAULT@SECLEVEL=1')
    except Exception:
        pass
    if insecure:
        _CTX = c
    return c


class Resp:
    __slots__ = ('status', 'headers', 'body', 'url', 'elapsed')

    def __init__(self, status, headers, body, url, elapsed=0.0):
        self.status = status
        self.headers = headers
        self.body = body
        self.url = url
        self.elapsed = elapsed

    @property
    def text(self) -> str:
        raw = self.body or b''
        # 从 headers 或 body 里嗅探编码
        enc = 'utf-8'
        ct = ''
        for k, v in self.headers:
            if k.lower() == 'content-type':
                ct = v.lower()
                break
        if 'charset=' in ct:
            enc = ct.split('charset=', 1)[1].split(';')[0].strip()
        elif raw[:2] in (b'\xff\xfe', b'\xfe\xff'):
            enc = 'utf-16'
        try:
            return raw.decode(enc, 'replace')
        except LookupError:
            return raw.decode('utf-8', 'replace')

    def json(self):
        import json as _j
        return _j.loads(self.text)

    def __repr__(self):
        return '<Resp %s %s %db %.2fs>' % (self.status, self.url, len(self.body or b''), self.elapsed)


def _proxy_from_env() -> str | None:
    """只有在用户显式设置 MYTOOL_PROXY 时才启用代理；不碰 HTTP_PROXY。"""
    return os.environ.get('MYTOOL_PROXY') or None


def _decompress(body: bytes, encoding: str) -> bytes:
    encoding = (encoding or '').lower()
    if not body:
        return body
    try:
        if 'gzip' in encoding:
            return gzip.decompress(body)
        if 'deflate' in encoding:
            try:
                return zlib.decompress(body)
            except zlib.error:
                return zlib.decompress(body, -zlib.MAX_WBITS)
    except Exception:
        return body
    return body


def fetch(
    url: str,
    method: str = 'GET',
    data: bytes | str | None = None,
    headers: dict | None = None,
    timeout: float = 15.0,
    proxy: str | None = None,
    max_redirects: int = 5,
    insecure: bool = True,
) -> Resp:
    """发一个请求并返回 Resp。自动跟随重定向、自动解压。"""
    t0 = time.time()
    hdrs = {
        'User-Agent': DEFAULT_UA,
        'Accept': '*/*',
        'Accept-Encoding': 'gzip, deflate',
        'Connection': 'close',
    }
    if headers:
        for k, v in headers.items():
            hdrs[k] = v

    if isinstance(data, str):
        data = data.encode('utf-8')

    use_proxy = proxy if proxy is not None else _proxy_from_env()

    for _hop in range(max_redirects + 1):
        u = urllib.parse.urlsplit(url)
        if u.scheme not in ('http', 'https'):
            raise ValueError('不支持的协议: %s' % url)
        host = u.hostname
        port = u.port or (443 if u.scheme == 'https' else 80)
        path = u.path or '/'
        if u.query:
            path += '?' + u.query

        if u.scheme == 'https':
            if use_proxy:
                pu = urllib.parse.urlsplit(use_proxy if '://' in use_proxy else 'http://' + use_proxy)
                conn = http.client.HTTPSConnection(
                    pu.hostname, pu.port or 80, timeout=timeout, context=_ctx(insecure)
                )
                conn.set_tunnel(host, port, headers={'User-Agent': hdrs['User-Agent']})
            else:
                conn = http.client.HTTPSConnection(host, port, timeout=timeout, context=_ctx(insecure))
        else:
            if use_proxy:
                pu = urllib.parse.urlsplit(use_proxy if '://' in use_proxy else 'http://' + use_proxy)
                conn = http.client.HTTPConnection(pu.hostname, pu.port or 80, timeout=timeout)
                path = url  # 明文 http 走代理时要发绝对 URI
            else:
                conn = http.client.HTTPConnection(host, port, timeout=timeout)

        try:
            conn.request(method, path, body=data, headers=hdrs)
            r = conn.getresponse()
            body = r.read()
            hlist = r.getheaders()
            status = r.status
        finally:
            try:
                conn.close()
            except Exception:
                pass

        enc = ''
        for k, v in hlist:
            if k.lower() == 'content-encoding':
                enc = v
                break
        body = _decompress(body, enc)

        if status in (301, 302, 303, 307, 308):
            loc = ''
            for k, v in hlist:
                if k.lower() == 'location':
                    loc = v
                    break
            if loc:
                url = urllib.parse.urljoin(url, loc)
                if status == 303:
                    method, data = 'GET', None
                continue

        return Resp(status, hlist, body, url, time.time() - t0)

    raise RuntimeError('重定向次数超过 %d: %s' % (max_redirects, url))


def get(url, **kw) -> Resp:
    return fetch(url, 'GET', **kw)


def post(url, data=None, **kw) -> Resp:
    return fetch(url, 'POST', data=data, **kw)


def download(url: str, dest: str, timeout: float = 60.0, proxy=None) -> int:
    """下载到文件，返回字节数。"""
    r = fetch(url, timeout=timeout, proxy=proxy)
    if r.status != 200:
        raise RuntimeError('HTTP %s: %s' % (r.status, url))
    os.makedirs(os.path.dirname(os.path.abspath(dest)), exist_ok=True)
    tmp = dest + '.part'
    with open(tmp, 'wb') as f:
        f.write(r.body)
    if os.path.exists(dest):
        os.remove(dest)
    os.rename(tmp, dest)
    return len(r.body)


def probe(host: str, port: int = 443, timeout: float = 5.0) -> bool:
    try:
        s = socket.create_connection((host, port), timeout=timeout)
        s.close()
        return True
    except Exception:
        return False
