# -*- coding: utf-8 -*-
"""功能清单 + 分发。

设计要点：
  每个功能项与原 App 的接口形态 1:1 对齐（endpoint 与参数名都照搬），
  但数据源由用户自己提供。网关接入三种方式（写进 config/gateway.json）：
    1) 界面粘贴自动识别（apply_gateway_text，支持 base|key 或抓包 URL）
    2) 命令行 --gateway "base|key"
    3) 「我的 → 网关设置」手动填表
  没配置时，联网功能明确显示「未配置网关」，绝不伪造结果。

本地能算的部分（归属地 / 证件解析 / 校验码 / 生成类）始终可用，与网关无关。
"""
from __future__ import annotations

import json
import os
import re
import urllib.parse

from . import bankcard, idcard, net, netaddr, phone, plate, providers, tools, uscc


# ---------------------------------------------------------------- 网关配置

def gateway_path() -> str:
    from . import datas
    d = os.path.join(datas.writable_dir(), 'config')
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, 'gateway.json')


DEFAULT_GATEWAY = {
    '_说明': '已从欣社 APK 反编译提取并内置真实网关。base / key / appid 均为 apk 内置值，'
             '请求报文与 apk 原版一致（sgh.php?...&key=1764942045&appid=72）。'
             '若服务端提示密钥失效，在「我的 → 网关设置」把 key 换成你的有效密钥即可。',
    'base': 'http://api.xjsgk.com',
    'key': '1764942045',
    'appid': '72',
    'timeout': 15,
    'key_param': 'key',
    'paths': {},
}


def load_gateway() -> dict:
    p = gateway_path()
    if os.path.exists(p):
        try:
            with open(p, 'r', encoding='utf-8') as f:
                d = json.load(f)
            if isinstance(d, dict):
                cfg = dict(DEFAULT_GATEWAY)
                cfg.update(d)
                return cfg
        except Exception:
            pass
    save_gateway(DEFAULT_GATEWAY)
    return dict(DEFAULT_GATEWAY)


def save_gateway(cfg: dict) -> str:
    p = gateway_path()
    tmp = p + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    if os.path.exists(p):
        os.remove(p)
    os.rename(tmp, p)
    return p


def apply_gateway_text(text: str) -> dict:
    """从一段文本自动识别并保存网关配置，免去逐项手动填写。

    支持形态：
      1) base|key   或   base key   （竖线 / 空格分隔，整行只有这一组）
      2) 任意抓包 URL：自动把 域名 当作 base、URL 里的 key= 参数当作 key
    多行抓包可直接整段粘贴，会合并提取所有出现的 base 与 key（取首个）。
    """
    text = (text or '').strip()
    cfg = load_gateway()
    bases, keys = set(), set()
    # 1) base|key 或 base key（整行就一对）
    m = re.match(r'^(https?://\S+?)\s*\|{1}\s*(\S+)$', text)
    if not m:
        m = re.match(r'^(https?://\S+)\s+(\S+)$', text)
    if m:
        bases.add(m.group(1).rstrip('/'))
        keys.add(m.group(2))
    # 2) 任意 http(s) URL，提取域名作 base、key= 参数作 key
    for um in re.finditer(r'(https?://[^\s"\'<>]+)', text):
        u = um.group(1).rstrip('/')
        try:
            p = urllib.parse.urlparse(u)
            if p.netloc:
                bases.add('%s://%s' % (p.scheme, p.netloc))
            q = urllib.parse.parse_qs(p.query)
            if q.get('key'):
                keys.add(q['key'][0])
        except Exception:
            pass
    if bases:
        cfg['base'] = sorted(bases)[0]
    if keys:
        cfg['key'] = sorted(keys)[0]
    save_gateway(cfg)
    return cfg


def gateway_ready() -> bool:
    c = load_gateway()
    return bool((c.get('base') or '').strip())


# ---------------------------------------------------------------- 功能清单
# tab: free | pro | pro2
# kind: local(纯本地) | remote(需网关) | both(本地先给，再尝试网关) | gen(生成类)
# params: (键, 标签, 占位提示)

F = lambda **kw: kw

FEATURES = [
    # ---------------- Free 免费版 ----------------
    F(id='sgh', name='手机号开户', en='Phone Search', tab='free', kind='both',
      endpoint='sgh.php', params=[('sgh', '手机号', '11 位手机号')],
      desc='手机号反查机主信息', local='phone'),
    F(id='cx', name='通用开户', en='General Account', tab='free', kind='both',
      endpoint='cx.php', params=[('cx', '任意内容', '手机号 / 身份证 / 车牌 / QQ / 邮箱')],
      desc='自动识别类型后综合查询', local='auto'),
    F(id='xm', name='姓名开户', en='Name Query', tab='free', kind='remote',
      endpoint='xm.php', params=[('xm', '姓名', '2-20 位中文')],
      desc='姓名反查关联信息'),
    F(id='wzry', name='王者荣耀查询', en='Honor of Kings', tab='free', kind='remote',
      endpoint='王者荣耀.php', params=[('name', '游戏昵称', ''), ('select', '第几个', '1')],
      desc='按昵称查王者荣耀账号'),
    F(id='cph', name='车主查询', en='Vehicle Owner', tab='free', kind='both',
      endpoint='cph.php', params=[('cph', '车牌号', '如 京A12345')],
      desc='车牌反查车主', local='plate'),
    F(id='idphoto', name='开大头照', en='ID Photo', tab='free', kind='gen',
      params=[('style', '规格', '一寸'), ('bg', '底色', '白')],
      desc='生成证件照（本地绘制）'),
    F(id='idcardrand', name='随机身份证正反面', en='Random ID Card', tab='free', kind='gen',
      params=[('area', '地区码', '110101'), ('gender', '性别', '男')],
      desc='生成身份证正反面图样（仅演示排版）'),
    F(id='qb', name='Q绑开户', en='QQ Bind Search', tab='free', kind='both',
      endpoint='qb.php', params=[('qb', 'QQ 号', '5-11 位')],
      desc='QQ 号反查绑定信息', local='qq'),
    F(id='mirror', name='照妖镜', en='Mirror', tab='free', kind='both',
      endpoint='mghy.php', params=[('sfz', '身份证号', '18 位')],
      desc='证件真实性核验', local='idcard'),
    F(id='mghy', name='敏感核验', en='Sensitive Verify', tab='free', kind='both',
      endpoint='mghy.php', params=[('sfz', '身份证号', '18 位')],
      desc='敏感名单核验', local='idcard'),
    F(id='jhf', name='假火飞', en='JHF Query', tab='free', kind='both',
      endpoint='jhf.php', params=[('name', '姓名', ''), ('sfz', '身份证号', '')],
      desc='姓名 + 身份证交叉核验', local='id2'),
    F(id='d2', name='二要素查询', en='Two-Factor Free', tab='free', kind='both',
      endpoint='d2.php', params=[('name', '姓名', ''), ('sfz', '身份证号', '18 位')],
      desc='姓名与身份证一致性', local='id2'),
    F(id='3ys', name='三要素查询', en='Three-Factor Free', tab='free', kind='both',
      endpoint='3ys.php', params=[('name', '姓名', ''), ('sfz', '身份证号', ''), ('sjh', '手机号', '')],
      desc='姓名 + 身份证 + 手机一致性', local='id3'),
    F(id='yx', name='邮箱查询', en='Email Query', tab='free', kind='remote',
      endpoint='yx.php', params=[('yx', '邮箱', 'name@example.com')],
      desc='邮箱反查关联账号'),
    F(id='fr', name='法人查询', en='Legal Person', tab='free', kind='both',
      endpoint='fr.php', params=[('fr', '信用代码', '18 位')],
      desc='企业法人信息', local='uscc'),
    F(id='sfz', name='身份证查询', en='ID Card Query', tab='free', kind='both',
      endpoint='sfz.php', params=[('sfz', '身份证号', '18 位')],
      desc='身份证反查关联信息', local='idcard'),
    F(id='yhgs', name='银行卡归属地', en='Bank Card', tab='free', kind='both',
      endpoint='yhgs.php', params=[('yhk', '银行卡号', '')],
      desc='卡号查发卡行与归属地', local='bank'),
    F(id='sjhgsd', name='手机号归属地', en='Phone Area', tab='free', kind='local',
      endpoint='sjhgsd.php', params=[('sjh', '手机号', '11 位')],
      desc='省市区 + 区号 + 运营商（离线）', local='phone'),
    F(id='k3', name='银行卡三要素', en='Bank 3-Factor', tab='free', kind='both',
      endpoint='k3.php', params=[('name', '姓名', ''), ('sfz', '身份证号', ''), ('yhk', '银行卡号', '')],
      desc='姓名 + 身份证 + 卡号', local='bank'),
    F(id='k4', name='银行卡四要素', en='Bank 4-Factor', tab='free', kind='both',
      endpoint='k4.php', params=[('name', '姓名', ''), ('sfz', '身份证号', ''), ('sjh', '手机号', ''), ('yhk', '银行卡号', '')],
      desc='姓名 + 身份证 + 手机 + 卡号', local='bank'),
    F(id='lm', name='猎魔查询', en='Name Hunter', tab='free', kind='remote',
      endpoint='lm.php', params=[('xm', '姓名', ''), ('dq', '地区', '如 广东')],
      desc='姓名 + 地区定位'),
    F(id='cxd', name='模糊车小档', en='Plate Fuzzy', tab='free', kind='both',
      endpoint='cxd.php', params=[('cph', '车牌（可模糊）', '如 京A123')],
      desc='支持不完整车牌', local='plate'),
    F(id='hpyj', name='和平精英', en='PUBG Mobile', tab='free', kind='remote',
      endpoint='hpyj.php', params=[('nc', '游戏昵称', ''), ('select', '第几个', '1')],
      desc='按昵称查和平精英账号'),
    F(id='tyc', name='天眼查法人', en='Tianyancha', tab='free', kind='both',
      endpoint='tyc.php', params=[('xy', '信用代码', '18 位')],
      desc='企业工商信息', local='uscc'),
    F(id='jdz', name='全国头接口', en='Nationwide', tab='free', kind='both',
      endpoint='jdz.php', params=[('xm', '姓名', ''), ('sfz', '身份证号', '')],
      desc='姓名 + 身份证全国库', local='id2'),
    F(id='bu', name='号码跑线', en='Number Trace', tab='free', kind='remote',
      endpoint='bu.php', params=[('prefix', '前 3 位', '138'), ('suffix', '后 4 位', '0000')],
      desc='按前后缀补全号码段'),
    F(id='yyzz', name='营业执照生成', en='License Gen', tab='free', kind='gen',
      params=[('qyxy', '信用代码或企业名', '')],
      desc='生成营业执照图样（仅排版演示）'),

    # ---------------- Pro 高级版 ----------------
    F(id='p_namequery', name='姓名（独家）', en='Name Query Pro', tab='pro', kind='remote',
      endpoint='', max_param='namequery', params=[('xm', '姓名', '')], desc='Pro max 姓名通道'),
    F(id='p_exclusivename', name='独家姓名', en='Exclusive Name', tab='pro', kind='remote',
      endpoint='', max_param='exclusivename', params=[('xm', '姓名', '')], desc='独家姓名库'),
    F(id='p_exclusiveidcard', name='独家证查名', en='ID to Name', tab='pro', kind='both',
      endpoint='', max_param='exclusiveidcard', params=[('sfz', '身份证号', '')], desc='身份证反查姓名'),
    F(id='p_namehunter', name='垃圾名字猎魔', en='Name Hunter Pro', tab='pro', kind='remote',
      endpoint='', max_param='namehunter', params=[('xm', '姓名', '')], desc='低质量数据源扫描'),
    F(id='p_nameidcard', name='姓名 + 身份证', en='Name & ID', tab='pro', kind='both',
      endpoint='', max_param='nameidcard', params=[('xm', '姓名', ''), ('sfz', '身份证号', '')], desc='交叉一致性', local='id2'),
    F(id='p_verify', name='二要素验证', en='Two-Factor Pro', tab='pro', kind='both',
      endpoint='', max_param='verify', params=[('name', '姓名', ''), ('idcard', '身份证号', '')], desc='一致性核验', local='id2'),
    F(id='p_idcardgender', name='身份证 + 性别', en='ID & Gender', tab='pro', kind='both',
      endpoint='', max_param='idcardgender', params=[('sfz', '身份证号', '')], desc='校验性别是否相符', local='idcard'),
    F(id='p_creditcode', name='信用代码', en='Credit Code', tab='pro', kind='both',
      endpoint='', max_param='creditcode', params=[('xy', '信用代码', '18 位')], desc='代码解析与工商信息', local='uscc'),
    F(id='p_sgh', name='手机号归属地（Pro）', en='Phone Area Pro', tab='pro', kind='both',
      endpoint='', max_param='sgh', params=[('sjh', '手机号', '')], desc='归属地增强', local='phone'),
    F(id='p_phoneprefix', name='手机号前缀', en='Phone Prefix', tab='pro', kind='both',
      endpoint='', max_param='phoneprefix', params=[('sjh', '号段前 7 位', '1380013')], desc='号段反查', local='phone'),
    F(id='p_prefixquery', name='前缀通用', en='Prefix Query', tab='pro', kind='both',
      endpoint='', max_param='prefixquery', params=[('q', '前缀', '')], desc='任意前缀查询', local='auto'),
    F(id='p_cph', name='车牌（Pro）', en='Plate Pro', tab='pro', kind='both',
      endpoint='', max_param='cph', params=[('cph', '车牌', '')], desc='车牌反查增强', local='plate'),
    F(id='p_qqbind', name='Q 绑查询', en='QQ Bind', tab='pro', kind='both',
      endpoint='', max_param='qqbind', params=[('qb', 'QQ 号', '')], desc='QQ 绑定关系', local='qq'),
    F(id='p_qqassoc', name='QQ 号关联', en='QQ Associate', tab='pro', kind='both',
      endpoint='', max_param='qqassoc', params=[('qb', 'QQ 号', '')], desc='QQ 关联账号', local='qq'),
    F(id='p_wxid', name='微信 ID', en='WeChat ID', tab='pro', kind='remote',
      endpoint='', max_param='wxid', params=[('wx', '微信号或手机号', '')], desc='微信绑定查询'),
    F(id='p_general', name='综合自由文本', en='General Pro', tab='pro', kind='both',
      endpoint='', max_param='general', params=[('q', '任意内容', '')], desc='自由文本综合', local='auto'),
    F(id='p_keyword', name='关键词查询', en='Keyword', tab='pro', kind='remote',
      endpoint='', max_param='keyword', params=[('kw', '关键词', '')], desc='关键词检索'),
    F(id='p_miniappuin', name='小程序 UIN', en='MiniApp UIN', tab='pro', kind='remote',
      endpoint='', max_param='miniappuin', params=[('q', '小程序或链接', '')], desc='小程序主体反查'),
    F(id='p_sessionid', name='会话 ID', en='Session ID', tab='pro', kind='remote',
      endpoint='', max_param='sessionid', params=[('q', '会话 ID', '')], desc='会话归属查询'),
    F(id='p_sfcombo', name='顺丰·多条件组合', en='SF Combo', tab='pro', kind='remote',
      endpoint='', max_param='sfcombo', params=[('k1', '条件 1', ''), ('k2', '条件 2', ''), ('k3', '条件 3', '')],
      desc='顺丰数据多条件组合'),

    # ---------------- Pro 其他功能 ----------------
    F(id='p_sfname', name='顺丰·姓名', en='SF Name', tab='pro2', kind='remote',
      endpoint='', max_param='sfname', params=[('xm', '姓名', '')], desc='顺丰姓名检索'),
    F(id='p_sfphone', name='顺丰·电话', en='SF Phone', tab='pro2', kind='remote',
      endpoint='', max_param='sfphone', params=[('sjh', '手机号', '')], desc='顺丰电话检索'),
    F(id='p_sfaddress', name='顺丰·地址模糊', en='SF Address', tab='pro2', kind='remote',
      endpoint='', max_param='sfaddress', params=[('dz', '地址片段', '')], desc='模糊地址检索'),
    F(id='p_sfprovince', name='顺丰·省份', en='SF Province', tab='pro2', kind='remote',
      endpoint='', max_param='sfprovince', params=[('sf', '省份', '如 广东')], desc='按省检索'),
    F(id='p_sfcity', name='顺丰·城市', en='SF City', tab='pro2', kind='remote',
      endpoint='', max_param='sfcity', params=[('cs', '城市', '如 深圳')], desc='按市检索'),
    F(id='p_sfsearch', name='顺丰·综合', en='SF Search', tab='pro2', kind='remote',
      endpoint='', max_param='sfsearch', params=[('q', '任意内容', '')], desc='综合检索'),
    F(id='p_ip', name='IP 归属地', en='IP Lookup', tab='pro2', kind='local',
      endpoint='', max_param='ip', params=[('ip', 'IP 地址', '8.8.8.8')], desc='联网公开接口，无需网关', local='ip'),
    F(id='p_myip', name='查本机 IP', en='My IP', tab='pro2', kind='local',
      endpoint='', max_param='myip', params=[], desc='公网出口 IP（联网）', local='myip'),
    F(id='p_url', name='网页源码下载', en='URL Fetch', tab='pro2', kind='local',
      endpoint='', max_param='url', params=[('u', '网址', 'https://example.com')], desc='抓取页面源码', local='url'),
    F(id='p_wallpaper', name='随机壁纸', en='Wallpaper', tab='pro2', kind='remote',
      endpoint='', max_param='wallpaper', params=[('q', '关键词（可空）', '')], desc='随机高清壁纸'),
    F(id='p_music', name='音乐搜索', en='Music', tab='pro2', kind='remote',
      endpoint='', max_param='music', params=[('q', '歌名或歌手', '')], desc='音乐检索'),
    F(id='p_video', name='视频解析', en='Video Parse', tab='pro2', kind='remote',
      endpoint='', max_param='video', params=[('u', '视频链接', '')], desc='短视频去水印解析'),
    F(id='p_phone', name='短信验证码', en='SMS Code', tab='pro2', kind='remote',
      endpoint='', max_param='phone', params=[('sjh', '手机号', '')], desc='验证码接收（需网关）'),
    F(id='p_pressure', name='短信压测', en='SMS Pressure', tab='pro2', kind='remote',
      endpoint='', max_param='pressure', params=[('sjh', '手机号', '')], desc='压测（需网关）'),
    F(id='p_healthfee', name='健康费', en='Health Fee', tab='pro2', kind='remote',
      endpoint='', max_param='healthfee', params=[('q', '身份证或手机号', '')], desc='健康数据检索'),
    F(id='p_committee', name='居委', en='Committee', tab='pro2', kind='remote',
      endpoint='', max_param='committee', params=[('q', '地址或姓名', '')], desc='居委会归属查询'),
    F(id='p_tradevolume', name='交易量', en='Trade Volume', tab='pro2', kind='remote',
      endpoint='', max_param='tradevolume', params=[('q', '账号或链接', '')], desc='交易数据查询'),
    F(id='p_xgv1', name='XG V1 综合', en='XG V1', tab='pro2', kind='remote',
      endpoint='', max_param='xgv1', params=[('q', '任意内容', '')], desc='XG V1 综合通道'),

    # ---------------- 本地工具（额外补充，不占原版序号） ----------------
    F(id='t_idcard', name='身份证解析', en='ID Parser', tab='free', kind='local',
      endpoint='', params=[('q', '身份证号', '18 位或 15 位')], desc='离线全字段解析', local='idcard'),
    F(id='t_netaddr', name='IP / 网段计算', en='CIDR Calc', tab='free', kind='local',
      endpoint='', params=[('q', 'IP 或网段', '192.168.1.0/24')], desc='CIDR 全参数', local='netaddr'),
]

_BY_ID = {f['id']: f for f in FEATURES}


def feature_list() -> list:
    """给前端用的清单（去掉内部字段）。"""
    out = []
    for f in FEATURES:
        out.append({
            'id': f['id'], 'name': f['name'], 'en': f.get('en', ''),
            'tab': f['tab'], 'kind': f['kind'], 'desc': f.get('desc', ''),
            'params': [{'k': p[0], 'label': p[1], 'ph': p[2] if len(p) > 2 else ''}
                       for p in f.get('params', [])],
            'local': f.get('local', ''),
        })
    return out


def counts() -> dict:
    d = {'free': 0, 'pro': 0, 'pro2': 0}
    for f in FEATURES:
        d[f['tab']] = d.get(f['tab'], 0) + 1
    d['total'] = len(FEATURES)
    return d


# ---------------------------------------------------------------- 本地处理器

def _rows(kv) -> list:
    out = []
    for k, v in kv:
        if v is None or v == '' or v == [] or v == {}:
            continue
        if isinstance(v, bool):
            v = '是' if v else '否'
        if isinstance(v, (list, tuple)):
            v = ' / '.join(str(x) for x in v)
        out.append([k, str(v)])
    return out


def _blk(title, rows, state=None, note='', tags=None):
    return {'title': title, 'rows': rows, 'state': state, 'note': note, 'tags': tags or []}


def _local_phone(v) -> dict:
    r = phone.query(v)
    rows = _rows([
        ('号码', r['digits']), ('号段', r['seg7']),
        ('运营商', r['operator']), ('省份', r['province']),
        ('城市', r['city']), ('区号', r['area_code']), ('邮编', r['zip']),
    ])
    return _blk('离线查询结果', rows, True if r['valid'] else False,
                r['error'], r['tags'])


def _local_idcard(v) -> dict:
    r = idcard.parse(v)
    rows = []
    if r['region'].get('display'):
        rows.append(['归属地', r['region']['display']])
    rows += _rows([
        ('出生日期', r['birth']), ('性别', r['gender']),
        ('周岁', r['age']), ('虚岁', r['age_nominal']),
        ('生肖', r['zodiac']), ('星座', r['constellation']),
        ('校验位（给定）', r['check_given']), ('校验位（应为）', r['check_expect']),
        ('号码版本', r['version']),
    ])
    return _blk('离线解析结果', rows, r['valid'], '；'.join(r['errors']), r['warnings'])


def _local_plate(v) -> dict:
    r = plate.parse(v)
    rows = _rows([
        ('省份', r['province']), ('发牌机关', r['issuer']),
        ('机关说明', r['issuer_hint']), ('号牌类型', r['kind']),
        ('能源类型', r['energy']), ('序号', r['serial']),
    ])
    return _blk('离线解析结果', rows, r['valid'], '；'.join(r['errors']), r['warnings'])


def _local_bank(v) -> dict:
    r = bankcard.parse(v)
    rows = _rows([
        ('掩码号', r['masked']), ('卡组织', r['organization']),
        ('BIN', r['bin']), ('发卡行', r['bank']), ('卡种', r['card_type']),
        ('Luhn 校验', '通过' if r['valid_luhn'] else '不通过'),
    ])
    return _blk('离线校验结果', rows, r['valid'], '；'.join(r['errors']), r['warnings'])


def _local_uscc(v) -> dict:
    r = uscc.parse(v)
    rows = _rows([
        ('标准化', r['normalized']), ('登记部门', r['dept']),
        ('主体类型', r['category']),
        ('登记机关辖区', r['region'].get('display', '')),
        ('组织机构代码', r['org_code']),
        ('校验位（给定）', r['check_given']), ('校验位（应为）', r['check_expect']),
    ])
    return _blk('离线解析结果', rows, r['valid'], '；'.join(r['errors']), r['warnings'])


def _local_netaddr(v) -> dict:
    r = netaddr.parse(v)
    rows = []
    if r.get('cidr'):
        c = r['cidr']
        rows = _rows([('网络地址', c.get('network')), ('广播地址', c.get('broadcast')),
                      ('子网掩码', c.get('netmask')), ('前缀长度', c.get('prefixlen')),
                      ('地址总数', c.get('num_addresses')), ('可用主机', c.get('usable_hosts')),
                      ('首地址', c.get('first_host')), ('末地址', c.get('last_host'))])
    else:
        rows = _rows([('IP', r.get('ip')), ('版本', r.get('version')),
                      ('类别', r.get('type')), ('私有', r.get('is_private')),
                      ('二进制', r.get('binary')), ('十进制', r.get('decimal'))])
    return _blk('离线计算结果', rows, r['valid'], '；'.join(r['errors']), r['warnings'])


def _local_ip(v) -> dict:
    r = providers.builtin_ip(v)
    rows = _rows(list((r.get('geo') or {}).items()))
    return _blk('联网查询结果（ip-api.com）', rows, bool(r.get('ok')), r.get('error', ''))


def _local_myip() -> dict:
    r = net.get('http://ip-api.com/json/?lang=zh-CN&fields=status,country,regionName,city,isp,query',
                timeout=12)
    try:
        j = r.json()
    except Exception:
        return _blk('查询失败', [], False, '返回无法解析')
    if j.get('status') != 'success':
        return _blk('查询失败', [], False, str(j.get('message') or ''))
    rows = _rows([('公网 IP', j.get('query')), ('国家', j.get('country')),
                  ('省/州', j.get('regionName')), ('城市', j.get('city')),
                  ('运营商', j.get('isp'))])
    return _blk('本机公网出口', rows, True)


def _local_url(v) -> dict:
    """返回 (block, 源码文本)。两条返回路径必须都是二元组。"""
    if not v.startswith(('http://', 'https://')):
        return _blk('地址无效', [], False, '必须以 http:// 或 https:// 开头'), ''
    try:
        r = net.get(v, timeout=20)
    except Exception as e:
        return _blk('抓取失败', [], False, '%s: %s' % (type(e).__name__, e)), ''
    body = r.text
    rows = _rows([('HTTP 状态', r.status), ('内容长度', '%d 字符' % len(body)),
                  ('耗时', '%.2fs' % r.elapsed), ('Content-Type',
                   next((v2 for k2, v2 in r.headers if k2.lower() == 'content-type'), ''))])
    return _blk('抓取结果', rows, r.status == 200, ''), body[:3000]


def _local_qq(v) -> dict:
    s = str(v).strip()
    rows = [('QQ 号', s), ('位数', len(s))]
    if not s.isdigit():
        return _blk('离线校验', _rows(rows + [('格式', '不是纯数字')]), False, 'QQ 号应为纯数字')
    if s.startswith('0'):
        return _blk('离线校验', _rows(rows + [('格式', '不应以 0 开头')]), False, 'QQ 号不以 0 开头')
    ok = 5 <= len(s) <= 11
    rows.append(('格式', '合法' if ok else '位数异常（常见 5-11 位）'))
    rows.append(('离线可得', '仅格式校验；绑定关系需网关'))
    return _blk('离线校验', _rows(rows), ok, '' if ok else '位数不在常见范围')


PROV_CODES = {'11', '12', '13', '14', '15', '21', '22', '23', '31', '32', '33',
              '34', '35', '36', '37', '41', '42', '43', '44', '45', '46',
              '50', '51', '52', '53', '54', '61', '62', '63', '64', '65',
              '71', '81', '82'}


def _local_auto(v) -> dict:
    """通用识别：判断这是什么东西，然后给所有能离线拿到的信息。

    按优先级用 elif 链，避免一条输入被同时当成好几种东西。
    关键：身份证末位可以是 X，不能简单剔除字母后再判长度。
    """
    s = str(v).strip()
    su = s.upper().replace(' ', '')
    d = ''.join(c for c in s if c.isdigit())
    blocks = []
    hit = []

    is_id18 = (len(su) == 18 and su[:17].isdigit()
               and (su[17].isdigit() or su[17] == 'X')
               and su[:2] in PROV_CODES)

    if is_id18:
        hit.append(('识别为', '身份证号'))
        blocks.append(_local_idcard(su))
    elif len(su) == 17 and su.isdigit() and su[:2] in PROV_CODES:
        hit.append(('识别为', '身份证号（17 位，缺校验位）'))
        blocks.append(_local_idcard(su))
    elif len(d) == 11 and d == s and d.startswith('1') and d[1] in '3456789':
        hit.append(('识别为', '手机号'))
        blocks.append(_local_phone(d))
    elif su and su[0] in plate.PROV and len(su) in (7, 8):
        hit.append(('识别为', '车牌'))
        blocks.append(_local_plate(su))
    elif '@' in s and '.' in s.rsplit('@', 1)[-1]:
        hit.append(('识别为', '邮箱'))
        local, domain = s.rsplit('@', 1)
        blocks.append(_blk('离线解析', _rows([
            ('邮箱', s), ('用户名', local), ('域名', domain), ('格式', '合法'),
        ]), True))
    elif len(su) == 18 and su[0] in '159YABCDE' and not su.isdigit():
        hit.append(('识别为', '统一社会信用代码'))
        blocks.append(_local_uscc(su))
    elif 15 <= len(d) <= 19 and d == s:
        bc = bankcard.parse(d)
        if bc['organization'] != '未知':
            hit.append(('识别为', '银行卡号'))
            blocks.append(_local_bank(d))
        else:
            hit.append(('识别为', '可能的卡号 / 长数字'))
            blocks.append(_local_bank(d))
    elif 5 <= len(d) <= 11 and d == s and not d.startswith('0'):
        hit.append(('识别为', '可能是 QQ 号'))
        blocks.append(_local_qq(d))
    else:
        try:
            loc = netaddr.parse(s)
            if loc.get('valid'):
                hit.append(('识别为', 'IP / 网段'))
                blocks.append(_local_netaddr(s))
        except Exception:
            pass

    if not blocks:
        blocks.append(_blk('未能识别', [['输入', s]], False,
                           '无法判断类型。可尝试手机号、身份证、车牌、银行卡、邮箱、QQ、IP'))
    return {'blocks': blocks, 'hits': hit}


# ---------------------------------------------------------------- 生成类

def _gen_idphoto(p: dict) -> dict:
    """证件照：按规格给出可绘制的参数，前端 canvas 出图。返回绘图指令。"""
    spec = p.get('style') or '一寸'
    bg = p.get('bg') or '白'
    sizes = {'一寸': (295, 413), '二寸': (413, 579), '小一寸': (260, 378),
             '大一寸': (390, 567), '小二寸': (413, 531), '五寸': (1050, 1499)}
    w, h = sizes.get(spec, (295, 413))
    colors = {'白': '#ffffff', '蓝': '#438edb', '红': '#d93a3a', '灰': '#d8d8d8'}
    return {
        'blocks': [_blk('生成参数', _rows([
            ('规格', spec), ('像素', '%d × %d' % (w, h)),
            ('折算', '%.0f × %.0f mm（300dpi）' % (w / 300 * 25.4, h / 300 * 25.4)),
            ('底色', bg), ('说明', '本地绘制，不上传任何照片'),
        ]), True)],
        'draw': {'type': 'idphoto', 'w': w, 'h': h, 'bg': colors.get(bg, '#fff'), 'label': spec},
    }


def _gen_idcardrand(p: dict) -> dict:
    area = (p.get('area') or '110101').strip() or '110101'
    gender = p.get('gender') or '男'
    try:
        no = idcard.random_one(area, gender)
    except Exception as e:
        return {'blocks': [_blk('生成失败', [], False, '%s: %s' % (type(e).__name__, e))], 'draw': None}
    r = idcard.parse(no)
    # 签发机关与有效期按归属地/出生年份推导，避免图样全是同一套写死值
    city = (r['region'].get('city') or '').strip()
    prov = (r['region'].get('province') or '').strip()
    if city and city not in ('市辖区', '县'):
        issuer = city + '公安局'
    elif prov:
        issuer = prov + '公安厅'
    else:
        issuer = '公安机关'
    try:
        by = int((r['birth'] or '1990')[:4])
        term = '%d.%02d.%02d-%d.%02d.%02d' % (by + 20, 1, 1, by + 40, 1, 1)
    except Exception:
        term = '—'
    return {
        'blocks': [_blk('生成的号码', _rows([
            ('身份证号', no), ('归属地', r['region'].get('display', '')),
            ('出生', r['birth']), ('性别', r['gender']),
            ('说明', '号码合法，但图样仅演示排版，不可用于任何用途'),
        ]), True)],
        'draw': {'type': 'idcard', 'no': no, 'name': '示例姓名',
                 'addr': (r['region'].get('display') or '').replace(' / ', ''),
                 'birth': (r['birth'] or '').replace('-', '.'),
                 'gender': r['gender'], 'issuer': issuer, 'term': term},
    }


def _gen_yyzz(p: dict) -> dict:
    v = (p.get('qyxy') or '').strip()
    name = v
    code = ''
    if v.upper()[:1] in '159YABCDE' and len(v) == 18:
        r = uscc.parse(v.upper())
        code = v.upper()
        name = '（按代码解析）' + r['region'].get('display', '')
    return {
        'blocks': [_blk('生成参数', _rows([
            ('名称', name), ('信用代码', code or '未提供'),
            ('说明', '图样仅用于排版演示，不具备任何法律效力'),
        ]), True)],
        'draw': {'type': 'yyzz', 'name': name, 'code': code or '—'},
    }


# ---------------------------------------------------------------- 网关调用

def _call_gateway(f: dict, params: dict) -> dict:
    cfg = load_gateway()
    base = (cfg.get('base') or '').strip().rstrip('/')
    if not base:
        return _blk('未配置网关', [['状态', '联网功能需要先在「我的 → 网关设置」里填写接口地址']],
                    None, '未配置网关，无法发起查询')

    key = (cfg.get('key') or '').strip()
    if f.get('max_param'):
        path = 'x.php'
        q = {'max': f['max_param']}
    else:
        path = f.get('endpoint') or (f['id'] + '.php')
        q = {}
    q.update({k: val for k, val in params.items() if val != ''})
    appid = (cfg.get('appid') or '').strip()
    if appid:
        q['appid'] = appid
    if key:
        q[cfg.get('key_param') or 'key'] = key

    pathes = cfg.get('paths') or {}
    path = pathes.get(f['id'], path)
    url = '%s/%s?%s' % (base, urllib.parse.quote(path), urllib.parse.urlencode(q))

    try:
        r = net.get(url, timeout=float(cfg.get('timeout') or 15))
    except Exception as e:
        return _blk('请求失败', [['地址', url]], False, '%s: %s' % (type(e).__name__, e))

    text = r.text.strip()
    rows = [('HTTP 状态', str(r.status)), ('耗时', '%.2fs' % r.elapsed),
            ('返回字节', str(len(r.body or b'')))]
    note = ''
    state = r.status == 200
    body_block = text[:4000]
    if text.startswith('{'):
        try:
            j = json.loads(text)
            note = str(j.get('message') or j.get('msg') or '')
            if j.get('code') not in (None, 200, 0, '200', '0'):
                state = False
        except Exception:
            pass
    return _blk('接口返回', rows, state, note), body_block


# ---------------------------------------------------------------- 统一入口

def run(fid: str, params: dict) -> dict:
    f = _BY_ID.get(fid)
    if not f:
        return {'ok': False, 'error': '未知功能：%s' % fid}

    params = {k: (v or '').strip() if isinstance(v, str) else v
              for k, v in (params or {}).items()}
    blocks = []
    text_out = ''
    draw = None

    local = f.get('local') or ''
    kind = f['kind']
    first = next(iter(params.values()), '') if params else ''

    try:
        # 1) 本地部分
        if kind in ('local', 'both') and local:
            if local == 'phone':
                blocks.append(_local_phone(first))
            elif local == 'idcard':
                blocks.append(_local_idcard(first))
            elif local == 'plate':
                blocks.append(_local_plate(first))
            elif local == 'bank':
                blocks.append(_local_bank(params.get('yhk') or first))
            elif local == 'uscc':
                blocks.append(_local_uscc(first))
            elif local == 'netaddr':
                blocks.append(_local_netaddr(first))
            elif local == 'ip':
                blocks.append(_local_ip(first))
            elif local == 'myip':
                blocks.append(_local_myip())
            elif local == 'url':
                blk, text_out = _local_url(first)
                blocks.append(blk)
            elif local == 'qq':
                blocks.append(_local_qq(first))
            elif local == 'auto':
                a = _local_auto(first)
                blocks.extend(a['blocks'])
                if a['hits']:
                    blocks.insert(0, _blk('类型识别', _rows(a['hits']), True))
            elif local == 'id2':
                q2 = _local_idcard(params.get('sfz') or params.get('idcard') or '')
                q2['title'] = '身份证本地校验（一致性需网关）'
                blocks.append(q2)
            elif local == 'id3':
                q2 = _local_idcard(params.get('sfz') or '')
                q2['title'] = '身份证本地校验（三要素一致性需网关）'
                blocks.append(q2)
                if params.get('sjh'):
                    blocks.append(_local_phone(params['sjh']))

        # 2) 生成类
        if kind == 'gen':
            if fid == 'idphoto':
                g = _gen_idphoto(params); blocks += g['blocks']; draw = g['draw']
            elif fid == 'idcardrand':
                g = _gen_idcardrand(params); blocks += g['blocks']; draw = g['draw']
            elif fid == 'yyzz':
                g = _gen_yyzz(params); blocks += g['blocks']; draw = g['draw']

        # 3) 网关部分
        if kind in ('remote', 'both'):
            gw = _call_gateway(f, params)
            if isinstance(gw, tuple):
                blocks.append(gw[0]); text_out = gw[1]
            else:
                blocks.append(gw)

    except Exception as e:
        import traceback
        return {'ok': False, 'error': '%s: %s' % (type(e).__name__, e),
                'trace': traceback.format_exc()[-1200:]}

    return {
        'ok': True,
        'id': fid, 'name': f['name'], 'en': f.get('en', ''),
        'blocks': blocks, 'raw': text_out, 'draw': draw,
        'gateway_ready': gateway_ready(),
    }
