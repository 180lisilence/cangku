# -*- coding: utf-8 -*-
"""身份证号解析 / 校验 / 生成，纯离线。

依据 GB 11643-1999《公民身份号码》。
    18 位：6 位地址码 + 8 位出生日期(YYYYMMDD) + 3 位顺序码 + 1 位校验码
    15 位（旧）：6 位地址码 + 6 位出生日期(YYMMDD) + 3 位顺序码，无校验位
顺序码奇数为男、偶数为女。
"""
from __future__ import annotations

import datetime
import random

WEIGHTS = (7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2)
CHECK_CODES = '10X98765432'

ZODIAC = '鼠牛虎兔龙蛇马羊猴鸡狗猪'

# 星座按 [起始月日, 名称]，右开区间
_CONSTELLATION = [
    ((1, 20), '水瓶座'), ((2, 19), '双鱼座'), ((3, 21), '白羊座'),
    ((4, 20), '金牛座'), ((5, 21), '双子座'), ((6, 22), '巨蟹座'),
    ((7, 23), '狮子座'), ((8, 23), '处女座'), ((9, 23), '天秤座'),
    ((10, 24), '天蝎座'), ((11, 23), '射手座'), ((12, 22), '摩羯座'),
]

# 这些市级名称没有信息量，展示时跳过
SKIP_CITY = {'市辖区', '县', '省直辖县级行政区划', '自治区直辖县级行政区划'}

AREA_ALIAS = {
    '11': '北京', '12': '天津', '31': '上海', '50': '重庆',
    '71': '台湾', '81': '香港', '82': '澳门',
}


def checksum(first17: str) -> str:
    """算第 18 位校验码。"""
    if len(first17) != 17 or not first17.isdigit():
        raise ValueError('需要 17 位数字')
    s = sum(int(c) * w for c, w in zip(first17, WEIGHTS))
    return CHECK_CODES[s % 11]


def constellation(month: int, day: int) -> str:
    name = '摩羯座'
    for (m, d), n in _CONSTELLATION:
        if (month, day) >= (m, d):
            name = n
        else:
            break
    return name


def _resolve_region(code6: str):
    from . import datas
    reg = datas.region()
    prov = reg.get(code6[:2], '')
    city = reg.get(code6[:4], '')
    county = reg.get(code6[:6], '')
    parts = []
    if prov:
        parts.append(prov)
    if city and city not in SKIP_CITY:
        parts.append(city)
    if county and county not in (city, prov):
        parts.append(county)
    display = ' / '.join(parts) if parts else ''
    known = bool(prov)
    return {
        'province': prov, 'city': city, 'county': county,
        'display': display, 'known': known,
        'code6': code6,
    }


def _age(birth: datetime.date, today: datetime.date):
    y = today.year - birth.year
    if (today.month, today.day) < (birth.month, birth.day):
        y -= 1
    return y


def parse(idno: str, today: datetime.date | None = None) -> dict:
    """解析身份证号，返回完整字段。不抛异常，问题写进 errors/valid。"""
    raw = (idno or '').strip().replace(' ', '')
    up = raw.upper()
    res = {
        'input': raw, 'normalized': up, 'valid': False, 'version': '',
        'errors': [], 'warnings': [],
        'region': {}, 'birth': '', 'age': None, 'age_nominal': None,
        'gender': '', 'gender_code': '', 'zodiac': '', 'constellation': '',
        'check_given': '', 'check_expect': '', 'seq': '',
        'source': 'offline:GB11643',
    }

    if not up:
        res['errors'].append('输入为空')
        return res
    if not up[:17].isdigit() and len(up) >= 17:
        res['errors'].append('前 17 位必须是数字')
        return res

    if len(up) == 18:
        res['version'] = '18 位（1999 标准）'
        body, given = up[:17], up[17]
        if not body.isdigit():
            res['errors'].append('前 17 位必须是数字')
            return res
    elif len(up) == 15:
        res['version'] = '15 位（旧版，无校验位）'
        res['warnings'].append('15 位旧号已停止使用，建议升为 18 位')
        # 15 -> 18：插 '19'，补校验位
        body = up[:6] + '19' + up[6:15]
        given = checksum(body)
        res['normalized'] = body + given
    else:
        res['errors'].append('长度必须是 18 位或 15 位，当前 %d 位' % len(up))
        return res

    # 行政区划
    reg = _resolve_region(body[:6])
    res['region'] = reg
    if not reg['known']:
        res['errors'].append('前 6 位地址码 %s 不在现行行政区划表中' % body[:6])
    elif not reg['county']:
        res['warnings'].append('地址码 %s 只匹配到%s级，区县码未登记'
                               % (body[:6], '市' if reg['city'] else '省'))

    # 出生日期
    try:
        birth = datetime.date(int(body[6:10]), int(body[10:12]), int(body[12:14]))
    except ValueError as e:
        res['errors'].append('出生日期 %s 非法（%s）' % (body[6:14], e))
        birth = None
    if birth:
        td = today or datetime.date.today()
        if birth > td:
            res['errors'].append('出生日期 %s 晚于今天' % birth.isoformat())
        if birth.year < 1900:
            res['warnings'].append('出生年份早于 1900，可能是历史号或脏数据')
        res['birth'] = birth.isoformat()
        res['age'] = _age(birth, td)
        res['age_nominal'] = td.year - birth.year + 1
        res['zodiac'] = ZODIAC[(birth.year - 4) % 12]
        res['constellation'] = constellation(birth.month, birth.day)
        res['weekday'] = '一二三四五六日'[birth.weekday()]

    # 性别
    seq = body[14:17]
    res['seq'] = seq
    res['gender_code'] = seq[-1]
    res['gender'] = '男' if int(seq[-1]) % 2 == 1 else '女'

    # 校验位
    expect = checksum(body)
    res['check_given'] = given
    res['check_expect'] = expect
    if given != expect:
        res['errors'].append('校验位不符：给的是 %s，应为 %s' % (given, expect))

    res['valid'] = not res['errors']
    return res


def to18(id15: str) -> str:
    s = (id15 or '').strip().upper()
    if len(s) != 15 or not s.isdigit():
        raise ValueError('15 位号码必须是纯数字')
    body = s[:6] + '19' + s[6:]
    return body + checksum(body)


def verify(idno: str) -> bool:
    return parse(idno)['valid']


def make(area6: str, birth: str, gender: str = '男', seq: int | None = None) -> str:
    """按条件生成一个合法身份证号（测试数据用）。

    area6: 6 位地址码；birth: 'YYYYMMDD' 或 'YYYY-MM-DD'；
    gender: '男'/'女'；seq: 顺序码序号(1-999)，不传则随机。
    """
    a = ''.join(c for c in area6 if c.isdigit())
    if len(a) != 6:
        raise ValueError('地址码必须是 6 位数字')
    b = ''.join(c for c in birth if c.isdigit())
    if len(b) != 8:
        raise ValueError('出生日期必须是 YYYYMMDD')
    datetime.date(int(b[:4]), int(b[4:6]), int(b[6:8]))  # 合法性校验

    if seq is None:
        seq = random.randint(1, 499)
    seq = max(1, min(999, int(seq)))
    # 调整末位奇偶以匹配性别
    if (gender or '男') == '男' and seq % 2 == 0:
        seq = seq + 1 if seq < 999 else seq - 1
    if (gender or '男') == '女' and seq % 2 == 1:
        seq = seq + 1 if seq < 999 else seq - 1
    body = a + b + '%03d' % seq
    return body + checksum(body)


def random_one(area6: str | None = None, gender: str = '男',
               year_from: int = 1960, year_to: int = 2005) -> str:
    from . import datas
    if not area6:
        reg = datas.region()
        counties = [k for k in reg if len(k) == 6 and not k.endswith('00')]
        area6 = random.choice(counties) if counties else '110101'
    y = random.randint(year_from, year_to)
    m = random.randint(1, 12)
    d = random.randint(1, 28)
    return make(area6, '%04d%02d%02d' % (y, m, d), gender)


def batch(text: str) -> list:
    out = []
    for line in (text or '').splitlines():
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        out.append(parse(line))
    return out
