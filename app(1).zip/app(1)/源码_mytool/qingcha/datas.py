# -*- coding: utf-8 -*-
"""数据资源定位与懒加载。

打包成 exe 后资源在 sys._MEIPASS，源码运行时在项目根目录，两者统一。
"""
from __future__ import annotations

import json
import os
import sys
import threading

_LOCK = threading.Lock()
_cache: dict = {}


def base_dir() -> str:
    """只读资源根目录（兼容 PyInstaller onefile / onedir）。"""
    if getattr(sys, 'frozen', False):
        # onefile 解包到 _MEIPASS；onedir 时资源与 exe 同级
        return getattr(sys, '_MEIPASS', os.path.dirname(sys.executable))
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def writable_dir() -> str:
    """用户可写目录（配置持久化用）。

    onefile 的 _MEIPASS 是每次运行重建的临时目录，写到那里重启即丢，
    所以 frozen 时固定用 exe 所在目录；源码运行时即项目根目录。
    """
    if getattr(sys, 'frozen', False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def data_dir() -> str:
    return os.path.join(base_dir(), 'data')


def path_of(name: str) -> str:
    return os.path.join(data_dir(), name)


def region() -> dict:
    """行政区划表 { '11': '北京市', '1101': '市辖区', '110101': '东城区', ... }"""
    with _LOCK:
        if 'region' not in _cache:
            p = path_of('region.json')
            if os.path.exists(p):
                with open(p, 'r', encoding='utf-8') as f:
                    _cache['region'] = json.load(f)
            else:
                _cache['region'] = {}
        return _cache['region']


def phone_db():
    """手机号段库（懒加载 4.6MB 二进制）。"""
    with _LOCK:
        if 'phone' not in _cache:
            from .phone import PhoneDB
            p = path_of('phone.dat')
            _cache['phone'] = PhoneDB(p) if os.path.exists(p) else None
        return _cache['phone']


def stats() -> dict:
    """数据资产自检信息，供 UI 展示。"""
    out = {}
    for name, desc in (('region.json', '行政区划'), ('phone.dat', '手机号段')):
        p = path_of(name)
        out[name] = {
            'desc': desc,
            'exists': os.path.exists(p),
            'size': os.path.getsize(p) if os.path.exists(p) else 0,
        }
    r = region()
    out['region_count'] = len(r)
    db = phone_db()
    out['phone_count'] = db.count if db else 0
    return out
