# -*- coding: utf-8 -*-
"""手机号解析：号段归属地 + 运营商，纯离线。

号段库格式（phone.dat，社区通用格式）：
    头 8 字节：前 4 字节版本标记，4~8 字节为索引区偏移 offset(int32 LE)
    记录区：offset 之后每条 9 字节
        [0:4]  号段前 7 位数字 (int32 LE)
        [4:8]  归属地字符串偏移 (int32 LE)
        [8]    运营商类型 (uint8)
    字符串区：'省|市|邮编|区号'，以 0x00 结尾

注意：不少开源实现按 '\n'(0x0a) 截断，本库实际是 0x00，按 0x0a 会读到整段脏数据。
"""
from __future__ import annotations

import os

OPS = {
    0: '异常号段',
    1: '中国移动',
    2: '中国联通',
    3: '中国电信',
    4: '电信虚拟运营商',
    5: '联通虚拟运营商',
    6: '移动虚拟运营商',
    7: '虚拟运营商 / 其他',
}

# 独立于号段库的前缀判定，作为交叉校验（号段库缺失时兜底）
PREFIX_OP = [
    ('中国广电', ('192',)),
    ('中国移动', ('134', '135', '136', '137', '138', '139', '147', '148',
                  '150', '151', '152', '157', '158', '159',
                  '172', '178', '182', '183', '184', '187', '188',
                  '195', '197', '198')),
    ('中国联通', ('130', '131', '132', '145', '146', '155', '156',
                  '166', '167', '171', '175', '176', '185', '186', '196')),
    ('中国电信', ('133', '149', '153', '173', '177', '180', '181',
                  '189', '190', '191', '193', '199')),
    ('虚拟运营商', ('162', '165', '170')),
]

# 常见号段语义（用于给结果加人话注解）
TAG = {
    '170': '虚拟运营商（京东/阿里/分享等）',
    '171': '虚拟运营商（蜗牛移动等）',
    '165': '移动虚商',
    '167': '联通虚商',
    '162': '电信虚商',
    '192': '中国广电',
    '1740': '卫星通信（天通）',
    '1749': '卫星通信',
    '1349': '卫星通信（海事）',
    '1410': '物联网',
    '1064': '物联网（短信）',
    '1440': '物联网',
}


def prefix_operator(p: str) -> str:
    p = (p or '').strip()
    if len(p) < 3:
        return ''
    for name, pre in PREFIX_OP:
        if p[:3] in pre:
            return name
    return ''


class PhoneDB:
    def __init__(self, path: str):
        with open(path, 'rb') as f:
            self.buf = f.read()
        self.index_offset = int.from_bytes(self.buf[4:8], 'little', signed=True)
        self.count = max(0, (len(self.buf) - self.index_offset) // 9)
        self._str_cache: dict[int, str] = {}

    def _read_info(self, off: int) -> str:
        if off in self._str_cache:
            return self._str_cache[off]
        end = self.buf.find(b'\x00', off)
        if end < 0:
            end = min(off + 200, len(self.buf))
        s = self.buf[off:end].decode('utf-8', 'replace')
        if len(self._str_cache) < 20000:
            self._str_cache[off] = s
        return s

    def _lookup(self, seg7: int):
        lo, hi = 0, self.count - 1
        while lo <= hi:
            mid = (lo + hi) // 2
            o = self.index_offset + mid * 9
            v = int.from_bytes(self.buf[o:o + 4], 'little', signed=True)
            if v == seg7:
                ioff = int.from_bytes(self.buf[o + 4:o + 8], 'little', signed=True)
                op = self.buf[o + 8]
                return self._read_info(ioff), op
            if v < seg7:
                lo = mid + 1
            else:
                hi = mid - 1
        return None, 0

    def query(self, phone: str) -> dict:
        digits = ''.join(ch for ch in phone if ch.isdigit())
        n = len(digits)
        res = {
            'input': phone,
            'digits': digits,
            'valid_format': False,
            'valid': False,
            'seg7': '',
            'province': '',
            'city': '',
            'zip': '',
            'area_code': '',
            'operator': '',
            'operator_prefix': '',
            'tags': [],
            'error': '',
            'source': 'offline:phone.dat',
        }
        if n != 11:
            res['error'] = '长度必须是 11 位，当前 %d 位' % n
            return res
        if not digits.isdigit():
            res['error'] = '含非数字字符'
            return res
        if not digits.startswith('1'):
            res['error'] = '手机号必须以 1 开头'
            return res
        if digits[1] not in '3456789':
            res['error'] = '第二位必须是 3-9（当前 %s）' % digits[1]
            return res
        res['valid_format'] = True

        seg7 = int(digits[:7])
        res['seg7'] = digits[:7]
        res['operator_prefix'] = prefix_operator(digits)

        info, op = self._lookup(seg7)
        db_op = OPS.get(op, '未知(%d)' % op)
        if info:
            parts = info.split('|')
            while len(parts) < 4:
                parts.append('')
            res['province'], res['city'], res['zip'], res['area_code'] = parts[:4]
            res['valid'] = True
        else:
            res['error'] = '号段 %s 未在离线库中收录（库内 %d 条）' % (digits[:7], self.count)

        # 运营商归属，三级取值：
        #  1. 库给了虚商细分(op 4/5/6) → 用库的，比前缀规则更精确
        #  2. 虚商段(170/171/162/165/167)或广电(192) → 用前缀规则。
        #     库对这些段只做粗分（例如 1701234 记成 op=3「电信」），直接用会误导
        #  3. 其余 → 用库的结论
        pre = res['operator_prefix']
        SPECIFIC = ('170', '171', '162', '165', '167', '192')
        if info and op in (4, 5, 6):
            res['operator'] = db_op
        elif digits[:3] in SPECIFIC and pre:
            res['operator'] = pre
            if info and db_op != pre:
                res['tags'].append('号段库记为「%s」，已按前缀规则纠正' % db_op)
        else:
            res['operator'] = db_op if info else (pre or '未收录')

        # 标签：先按 7 位再按 4 位再按 3 位匹配
        for k in (digits[:7], digits[:4], digits[:3]):
            if k in TAG:
                res['tags'].append(TAG[k])
        if digits[:3] not in SPECIFIC and pre and info and db_op != pre:
            res['tags'].append('号段库判「%s」，前缀规则判「%s」，两者不一致' % (db_op, pre))
        return res


def query(phone: str) -> dict:
    from . import datas
    db = datas.phone_db()
    if db is None:
        digits = ''.join(c for c in str(phone) if c.isdigit())
        return {
            'input': phone, 'digits': digits, 'valid': False, 'valid_format': len(digits) == 11,
            'operator': prefix_operator(digits), 'province': '', 'city': '',
            'error': '缺少号段库 data/phone.dat', 'tags': [], 'source': 'offline:缺库',
        }
    return db.query(phone)


def batch(text: str) -> list:
    out = []
    for line in (text or '').splitlines():
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        out.append(query(line))
    return out
