# -*- coding: utf-8 -*-
"""自查工具箱（qingcha）—— 不依赖任何第三方服务的数据解析 / 查询工具。

模块：
    net       自管 HTTP 客户端（默认直连，规避代理导致的 TLS 失败）
    datas     数据资源定位
    idcard    身份证解析
    phone     手机号归属地
    bankcard  银行卡校验
    uscc      统一社会信用代码
    plate     车牌解析
    netaddr   IP / CIDR
    tools     哈希 / 编解码 / 时间戳
    providers 可插拔数据源
    registry  能力注册表
    server    本地 Web 服务
"""

__version__ = '1.0.0'
__all__ = ['net', 'datas', 'idcard', 'phone', 'bankcard', 'uscc',
           'plate', 'netaddr', 'tools', 'providers', 'registry']
