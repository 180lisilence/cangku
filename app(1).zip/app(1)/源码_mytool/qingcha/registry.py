# -*- coding: utf-8 -*-
"""能力注册表：把各模块统一成 {cap, items[]} 结构，供 CLI 与 Web 共用。

前端不需要为每个能力写界面 —— 拿到 items 里的 rows(key/value) 与 state
就能通用渲染。
"""
from __future__ import annotations

from . import bankcard, datas, idcard, netaddr, phone, plate, providers, tools, uscc


# 字段名 -> 中文标签
FIELD_CN = {
    'normalized': '标准化号码', 'birth': '出生日期', 'age': '周岁',
    'age_nominal': '虚岁', 'gender': '性别', 'zodiac': '生肖',
    'constellation': '星座', 'weekday': '出生星期', 'seq': '顺序码',
    'check_given': '校验位（给定）', 'check_expect': '校验位（应为）',
    'version': '号码版本', 'is_special': '特殊号牌',
    'digits': '号码', 'seg7': '号段（前 7 位）', 'operator': '运营商',
    'operator_prefix': '运营商（前缀规则）', 'province': '省份', 'city': '城市',
    'area_code': '区号', 'zip': '邮编',
    'organization': '卡组织', 'bin': 'BIN', 'bank': '发卡行',
    'card_type': '卡种', 'length': '长度', 'masked': '掩码号',
    'dept': '登记管理部门', 'category': '主体类型', 'org_code': '组织机构代码',
    'issuer': '发牌机关', 'issuer_hint': '发牌机关说明',
    'kind': '号牌类型', 'energy': '能源类型', 'serial': '序号',
    'network': '网络地址', 'broadcast': '广播地址', 'netmask': '子网掩码',
    'hostmask': '反掩码', 'prefixlen': '前缀长度', 'num_addresses': '地址总数',
    'usable_hosts': '可用主机数', 'first_host': '首个可用地址',
    'last_host': '末个可用地址', 'ip': 'IP 地址', 'type': '地址类别',
    'binary': '二进制', 'hex': '十六进制', 'decimal': '十进制整数',
    'compressed': 'IPv6 压缩形式', 'exploded': 'IPv6 完整形式',
    'version_label': '版本',
    # 编解码
    'encode': '编码结果', 'decode': '解码结果', 'encode_upper': '大写形式',
    'encode_spaced': '空格分隔', 'decode_error': '解码失败',
    'quote': 'URL 编码', 'quote_plus': 'URL 编码（空格转 +）',
    'unquote': 'URL 解码', 'unquote_plus': 'URL 解码（+ 转空格）',
    # 文本统计
    'chars': '字符数', 'chars_no_space': '字符数（不含空白）',
    'bytes_utf8': 'UTF-8 字节数', 'bytes_gbk': 'GBK 字节数', 'lines': '行数',
    'words_en': '词数（空白分隔）', 'cjk_chars': '汉字数',
    'unique_chars': '去重字符数',
}


def cn(k: str) -> str:
    return FIELD_CN.get(k, k)


def _rows(d: dict, keys) -> list:
    out = []
    for k in keys:
        v = d.get(k)
        if v is None or v == '' or v == [] or v == {}:
            continue
        if isinstance(v, bool):
            v = '是' if v else '否'
        if isinstance(v, (list, tuple)):
            v = ' / '.join(str(x) for x in v)
        elif isinstance(v, dict):
            v = ', '.join('%s=%s' % (a, b) for a, b in v.items())
        out.append([cn(k), str(v)])
    return out


def _item(valid, title, rows, tags=None, note='') -> dict:
    return {'valid': valid, 'title': title, 'rows': rows, 'tags': tags or [], 'note': note}


# ---------------------------------------------------------------- 各能力实现

def _idcard(text, opts):
    out = []
    for s in _lines(text):
        r = idcard.parse(s)
        rows = []
        if r['region'].get('display'):
            rows.append(['归属地', r['region']['display']])
        if r['region'].get('code6'):
            rows.append(['地址码', r['region']['code6']])
        rows += _rows(r, ['birth', 'age', 'gender', 'zodiac', 'constellation',
                          'weekday', 'seq', 'version', 'check_given', 'check_expect'])
        out.append(_item(r['valid'], r['normalized'] or s, rows,
                         list(r['warnings']), '；'.join(r['errors'])))
    return out


def _phone(text, opts):
    out = []
    for s in _lines(text):
        r = phone.query(s)
        rows = _rows(r, ['seg7', 'operator', 'operator_prefix', 'province',
                         'city', 'area_code', 'zip'])
        tags = list(r['tags'])
        if r['valid']:
            loc = r['province'] if r['province'] == r['city'] \
                else (r['province'] + r['city'])
            title = '%s · %s' % (r['digits'], loc)
        else:
            title = r['digits'] or s
        out.append(_item(bool(r['valid']), title, rows, tags, r['error']))
    return out


def _bankcard(text, opts):
    out = []
    for s in _lines(text):
        r = bankcard.parse(s)
        rows = _rows(r, ['masked', 'organization', 'bin', 'bank', 'card_type', 'length'])
        rows.append(['Luhn 校验', '通过' if r['valid_luhn'] else '不通过'])
        out.append(_item(r['valid'], r['masked'] or s, rows, r['warnings'],
                         '；'.join(r['errors'])))
    return out


def _uscc(text, opts):
    out = []
    for s in _lines(text):
        r = uscc.parse(s)
        rows = _rows(r, ['normalized', 'dept', 'category', 'org_code',
                         'check_given', 'check_expect'])
        if r['region'].get('display'):
            rows.insert(2, ['登记机关辖区', r['region']['display']])
        out.append(_item(r['valid'], r['normalized'] or s, rows, r['warnings'],
                         '；'.join(r['errors'])))
    return out


def _plate(text, opts):
    out = []
    for s in _lines(text):
        r = plate.parse(s)
        rows = _rows(r, ['normalized', 'province', 'issuer', 'issuer_hint',
                         'kind', 'energy', 'serial'])
        out.append(_item(r['valid'], s, rows, r['warnings'], '；'.join(r['errors'])))
    return out


def _netaddr(text, opts):
    out = []
    for s in _lines(text):
        r = netaddr.parse(s)
        rows = []
        if r.get('cidr'):
            c = r['cidr']
            rows = _rows(c, ['network', 'broadcast', 'netmask', 'hostmask', 'prefixlen',
                             'num_addresses', 'usable_hosts', 'first_host', 'last_host'])
        else:
            rows = _rows(r, ['ip', 'version', 'type', 'binary', 'hex', 'decimal',
                             'compressed', 'exploded'])
            rows.append(['私有地址', '是' if r.get('is_private') else '否'])
            rows.append(['公网可路由', '是' if r.get('is_global') else '否'])
        if r.get('special'):
            rows.append(['特殊用途', r['special']])
        out.append(_item(r['valid'], s, rows, r['warnings'], '；'.join(r['errors'])))
    return out


def _ipgeo(text, opts):
    out = []
    for s in _lines(text):
        r = providers.builtin_ip(s)
        rows = []
        if r.get('geo'):
            rows = [[k, str(v)] for k, v in r['geo'].items() if v not in (None, '')]
        loc = r.get('offline') or {}
        if loc.get('valid'):
            rows.insert(0, ['IP 合法性', '合法 · %s' % loc.get('version', '')])
            if loc.get('special'):
                rows.append(['特殊用途', loc['special']])
        out.append(_item(bool(r.get('ok')), s, rows, [], r.get('error', '')))
    return out


def _hash(text, opts):
    r = tools.hash_all(text)
    rows = [[k.upper(), v] for k, v in r.items() if k not in ('input_len_chars', 'input_len_bytes')]
    rows.insert(0, ['输入长度', '%d 字符 / %d 字节' % (r['input_len_chars'], r['input_len_bytes'])])
    return [_item(None, '哈希与摘要', rows)]


def _b64(text, opts):
    r = tools.b64(text, bool(opts.get('urlsafe')))
    rows = [['编码结果', r['encode']]]
    if r.get('decode'):
        rows.append(['解码结果', r['decode']])
    elif r.get('decode_error'):
        rows.append(['解码失败', r['decode_error']])
    return [_item(None, 'Base64', rows)]


def _urlc(text, opts):
    r = tools.url_code(text)
    return [_item(None, 'URL 编解码', [[cn(k), v] for k, v in r.items()])]


def _hexc(text, opts):
    r = tools.hex_code(text)
    return [_item(None, 'Hex', [[cn(k), v] for k, v in r.items()])]


_TS_CN = {
    'kind': '输入类型', 'seconds': '秒级时间戳', 'milliseconds': '毫秒级时间戳',
    'local': '本地时间', 'utc': 'UTC 时间', 'iso': 'ISO 8601',
    'weekday': '星期', 'date': '日期', 'now': '当前时间戳',
    'fmt_matched': '匹配的格式',
}


def _ts(text, opts):
    r = tools.ts(text)
    rows = [[_TS_CN.get(k, k), str(v)]
            for k, v in r.items() if k not in ('input', 'error')]
    return [_item(None if 'error' not in r else False, r.get('input') or '当前时间',
                  rows, [], r.get('error', ''))]


def _json(text, opts):
    r = tools.json_fmt(text, int(opts.get('indent') or 2), bool(opts.get('sort')))
    if not r['ok']:
        return [_item(False, 'JSON', [], [], r['error'])]
    return [_item(True, 'JSON 合法', [['格式化', r['pretty']], ['压缩', r['compact']]])]


def _stats(text, opts):
    r = tools.text_stats(text)
    return [_item(None, '文本统计', [[cn(k), str(v)] for k, v in r.items()])]


def _dedupe(text, opts):
    r = tools.dedupe(text, True)
    return [_item(None, '去重后 %d 行' % r['count'], [['结果', r['result']]])]


def _idgen(text, opts):
    """参数：area(6位) gender(男/女) birth(YYYYMMDD) count"""
    n = max(1, min(200, int(opts.get('count') or 5)))
    area = (opts.get('area') or '').strip()
    gender = opts.get('gender') or '男'
    birth = (opts.get('birth') or '').strip()
    out = []
    for _ in range(n):
        try:
            if birth:
                no = idcard.make(area or '110101', birth, gender)
            else:
                no = idcard.random_one(area or None, gender)
        except Exception as e:
            return [_item(False, '生成失败', [], [], '%s: %s' % (type(e).__name__, e))]
        p = idcard.parse(no)
        out.append(_item(True, no, _rows(p, ['birth', 'gender', 'age', 'zodiac', 'constellation'])))
    return out


def _usccgen(text, opts):
    body = (text or '').strip().upper()
    try:
        full = uscc.make(body)
    except Exception as e:
        return [_item(False, body, [], [], '%s: %s' % (type(e).__name__, e))]
    return _uscc(full, opts)


def _custom(text, opts):
    pid = opts.get('provider')
    if not pid:
        return [_item(False, '未选择数据源', [], [], '请先在下拉框选择自定义数据源')]
    out = []
    for s in _lines(text):
        r = providers.run_custom(pid, s, opts.get('vars') or None)
        rows = [[k, str(v)] for k, v in (r.get('fields') or {}).items()]
        if r.get('url'):
            rows.append(['请求地址', r['url']])
        if r.get('elapsed') is not None:
            rows.append(['耗时', '%.3fs' % r['elapsed']])
        out.append(_item(bool(r.get('ok')), s, rows, [], r.get('error', '')))
    return out


def _lines(text):
    out = []
    for line in (text or '').splitlines():
        line = line.strip()
        if line and not line.startswith('#'):
            out.append(line)
    if not out and (text or '').strip():
        out = [(text or '').strip()]
    return out


# ---------------------------------------------------------------- 注册

CAPS = [
    {'id': 'idcard', 'name': '身份证解析', 'cat': '证件', 'fn': _idcard,
     'hint': '18 位或 15 位，支持每行一个批量解析', 'multi': True,
     'desc': '归属地/出生日期/性别/周岁/生肖/星座/校验位，含旧号转新号'},
    {'id': 'phone', 'name': '手机号归属地', 'cat': '号码', 'fn': _phone,
     'hint': '11 位手机号，每行一个', 'multi': True,
     'desc': '省市区 + 邮编 + 区号 + 运营商（内置 51.7 万条号段，离线）'},
    {'id': 'bankcard', 'name': '银行卡校验', 'cat': '号码', 'fn': _bankcard,
     'hint': '银行卡号，每行一个', 'multi': True,
     'desc': 'Luhn 校验 + 卡组织 + 常见 BIN 归属'},
    {'id': 'uscc', 'name': '统一社会信用代码', 'cat': '证件', 'fn': _uscc,
     'hint': '18 位信用代码', 'multi': True,
     'desc': 'GB32100 校验 + 登记部门/主体类型/辖区'},
    {'id': 'plate', 'name': '车牌解析', 'cat': '号码', 'fn': _plate,
     'hint': '如 京A12345 / 粤B12345D', 'multi': True,
     'desc': '省份、号牌类型、新能源能源类型、特殊号牌'},
    {'id': 'netaddr', 'name': 'IP / 网段计算', 'cat': '网络', 'fn': _netaddr,
     'hint': '1.2.3.4 或 192.168.1.0/24', 'multi': True,
     'desc': 'CIDR 各项参数、私网/公网判定、二进制/十六进制'},
    {'id': 'ipgeo', 'name': 'IP 归属地（联网）', 'cat': '网络', 'fn': _ipgeo,
     'hint': '公网 IP，每行一个', 'multi': True,
     'desc': '走 ip-api.com，限 45 次/分钟'},
    {'id': 'hash', 'name': '哈希摘要', 'cat': '工具', 'fn': _hash,
     'hint': '任意文本', 'multi': False, 'desc': 'MD5/SHA1/SHA256/SHA512/SHA3/CRC32'},
    {'id': 'b64', 'name': 'Base64', 'cat': '工具', 'fn': _b64,
     'hint': '文本或 Base64 串', 'multi': False, 'desc': '自动判断编码/解码',
     'opts': [{'k': 'urlsafe', 'label': 'URL 安全变体', 'type': 'bool'}]},
    {'id': 'urlc', 'name': 'URL 编解码', 'cat': '工具', 'fn': _urlc,
     'hint': '任意文本', 'multi': False, 'desc': 'quote / unquote / quote_plus'},
    {'id': 'hexc', 'name': 'Hex 编解码', 'cat': '工具', 'fn': _hexc,
     'hint': '文本或十六进制串', 'multi': False, 'desc': '文本 ↔ Hex'},
    {'id': 'ts', 'name': '时间戳转换', 'cat': '工具', 'fn': _ts,
     'hint': '留空取当前时间；支持 10/13 位或 2024-01-01 12:00:00', 'multi': False,
     'desc': '时间戳 ↔ 本地/UTC/ISO/星期'},
    {'id': 'json', 'name': 'JSON 格式化', 'cat': '工具', 'fn': _json,
     'hint': '粘贴 JSON', 'multi': False, 'desc': '格式化与压缩，校验合法性',
     'opts': [{'k': 'indent', 'label': '缩进空格', 'type': 'int', 'default': 2},
              {'k': 'sort', 'label': '键排序', 'type': 'bool'}]},
    {'id': 'stats', 'name': '文本统计', 'cat': '工具', 'fn': _stats,
     'hint': '任意文本', 'multi': False, 'desc': '字符/字节/行/词/汉字数'},
    {'id': 'dedupe', 'name': '去重排序', 'cat': '工具', 'fn': _dedupe,
     'hint': '每行一条', 'multi': False, 'desc': '按行去重并排序'},
    {'id': 'idgen', 'name': '身份证生成', 'cat': '生成', 'fn': _idgen,
     'hint': '不需要输入内容，用上方参数', 'multi': False,
     'desc': '按地区码/生日/性别生成合法测试号（仅用于测试数据）',
     'opts': [{'k': 'area', 'label': '地区码(6位)', 'type': 'text', 'default': '110101'},
              {'k': 'birth', 'label': '生日 YYYYMMDD（留空随机）', 'type': 'text', 'default': ''},
              {'k': 'gender', 'label': '性别', 'type': 'select', 'options': ['男', '女']},
              {'k': 'count', 'label': '数量', 'type': 'int', 'default': 5}]},
    {'id': 'usccgen', 'name': '信用代码补校验位', 'cat': '生成', 'fn': _usccgen,
     'hint': '输入前 17 位', 'multi': True, 'desc': '算出第 18 位并校验'},
    {'id': 'custom', 'name': '自定义数据源', 'cat': '联网', 'fn': _custom,
     'hint': '要查询的内容，每行一个', 'multi': True,
     'desc': '调用 config/providers.json 里你自己配置的接口'},
]

_BY_ID = {c['id']: c for c in CAPS}


def cap_list() -> list:
    out = []
    for c in CAPS:
        d = {k: v for k, v in c.items() if k != 'fn'}
        out.append(d)
    return out


def run(cap: str, text: str, opts: dict | None = None) -> dict:
    c = _BY_ID.get(cap)
    if not c:
        return {'ok': False, 'error': '未知能力: %s' % cap, 'items': []}
    opts = opts or {}
    try:
        items = c['fn'](text, opts)
    except Exception as e:
        import traceback
        return {'ok': False, 'error': '%s: %s' % (type(e).__name__, e),
                'trace': traceback.format_exc()[-1500:], 'items': []}
    bad = sum(1 for i in items if i['valid'] is False)
    return {
        'ok': True,
        'cap': cap,
        'name': c['name'],
        'items': items,
        'count': len(items),
        'failed': bad,
    }
