# -*- coding: utf-8 -*-
"""本地 Web 服务：只监听 127.0.0.1，不对外网暴露。"""
from __future__ import annotations

import json
import mimetypes
import os
import socket
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from . import datas, features, providers, registry

WEB_DIR = None


def web_dir() -> str:
    global WEB_DIR
    if WEB_DIR is None:
        WEB_DIR = os.path.join(datas.base_dir(), 'web')
    return WEB_DIR


class Handler(BaseHTTPRequestHandler):
    server_version = 'qingcha/1.0'

    def log_message(self, fmt, *args):
        # 静默：不在控制台刷请求日志
        pass

    # ---------------------------------------------------------- helpers
    def _send(self, code: int, body: bytes, ctype: str):
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj, ensure_ascii=False).encode('utf-8'),
                   'application/json; charset=utf-8')

    def _read_json(self):
        n = int(self.headers.get('Content-Length') or 0)
        if n <= 0:
            return {}
        raw = self.rfile.read(n)
        try:
            return json.loads(raw.decode('utf-8'))
        except Exception:
            return {}

    # ---------------------------------------------------------- routes
    def do_GET(self):
        path = self.path.split('?')[0]
        if path in ('/', '/index.html'):
            return self._static('index.html')
        if path == '/api/caps':
            return self._json({'ok': True, 'caps': registry.cap_list()})
        if path == '/api/features':
            return self._json({
                'ok': True,
                'features': features.feature_list(),
                'counts': features.counts(),
                'gateway_ready': features.gateway_ready(),
            })
        if path == '/api/gateway':
            cfg = features.load_gateway()
            safe = dict(cfg)
            if safe.get('key'):
                k = safe['key']
                safe['key_masked'] = k[:3] + '****' + k[-2:] if len(k) > 6 else '****'
                safe['key'] = ''
            return self._json({'ok': True, 'gateway': safe,
                               'ready': features.gateway_ready()})
        if path == '/api/stats':
            return self._json({'ok': True, 'stats': datas.stats()})
        if path == '/api/providers':
            return self._json({'ok': True, **providers.list_all()})
        if path.startswith('/static/') or path.startswith('/web/'):
            return self._static(path.split('/', 2)[-1])
        return self._send(404, b'not found', 'text/plain; charset=utf-8')

    def do_POST(self):
        path = self.path.split('?')[0]
        if path == '/api/run':
            body = self._read_json()
            cap = body.get('cap') or ''
            text = body.get('text') or ''
            opts = body.get('opts') or {}
            return self._json(registry.run(cap, text, opts))
        if path == '/api/feature':
            body = self._read_json()
            return self._json(features.run(body.get('id') or '',
                                           body.get('params') or {}))
        if path == '/api/gateway':
            body = self._read_json()
            cfg = features.load_gateway()
            if body.get('text'):
                features.apply_gateway_text(body['text'])
                cfg = features.load_gateway()
            for k in ('base', 'key_param', 'paths'):
                if k in body:
                    cfg[k] = body[k]
            if 'key' in body and body['key'] != '':
                cfg['key'] = body['key']
            if 'timeout' in body and body['timeout']:
                cfg['timeout'] = body['timeout']
            if body.get('clear_key'):
                cfg['key'] = ''
            p = features.save_gateway(cfg)
            return self._json({'ok': True, 'path': p,
                               'ready': features.gateway_ready()})
        if path == '/api/providers':
            body = self._read_json()
            cfg = providers.load_config()
            if 'custom' in body and isinstance(body['custom'], list):
                cfg['custom'] = body['custom']
            p = providers.save_config(cfg)
            return self._json({'ok': True, 'path': p})
        return self._send(404, b'not found', 'text/plain; charset=utf-8')

    def _static(self, rel: str):
        base = os.path.abspath(web_dir())
        target = os.path.abspath(os.path.join(base, rel))
        if not target.startswith(base) or not os.path.isfile(target):
            return self._send(404, b'not found', 'text/plain; charset=utf-8')
        ctype = mimetypes.guess_type(target)[0] or 'application/octet-stream'
        if ctype.startswith('text/') or ctype in ('application/javascript', 'application/json'):
            ctype += '; charset=utf-8'
        with open(target, 'rb') as f:
            self._send(200, f.read(), ctype)


def pick_port(start: int = 8765, tries: int = 30) -> int:
    for p in range(start, start + tries):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind(('127.0.0.1', p))
                return p
            except OSError:
                continue
    raise RuntimeError('从 %d 起 %d 个端口都被占用' % (start, tries))


def serve(port: int | None = None, open_browser: bool = True, quiet: bool = False):
    port = port or pick_port()
    srv = ThreadingHTTPServer(('127.0.0.1', port), Handler)
    srv.daemon_threads = True
    url = 'http://127.0.0.1:%d/' % port
    if not quiet:
        print('')
        print('  自查工具箱 v1.0')
        print('  ------------------------------------------')
        print('  已启动：%s' % url)
        st = datas.stats()
        print('  区划 %d 条 · 号段 %d 条' % (st['region_count'], st['phone_count']))
        print('  关闭窗口即停止服务（Ctrl+C）')
        print('')
    if open_browser:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        if not quiet:
            print('\n已停止')
    finally:
        srv.server_close()
    return url


if __name__ == '__main__':
    serve()
