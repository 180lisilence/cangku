# -*- coding: utf-8 -*-
"""可插拔数据源。

两类：
  1. builtin  —— 内置的公开接口（当前离线环境实测可用的只有 IP 归属地）
  2. custom   —— 用户自己在 config/providers.json 里定义的任意 HTTP 接口

custom 定义格式（模板变量用 {名字} 占位，运行时自动 URL 编码）：

    {
      "id": "my_api",
      "name": "我的接口",
      "method": "GET",
      "url": "http://api.example.com/query?key=xxx&q={q}",
      "headers": {"X-Token": "abc"},
      "body": null,
      "timeout": 15,
      "result_type": "json",          // json | text | jsonp
      "pick": "data.result",          // 点号路径，从响应里取出目标节点
      "map": {"姓名": "name", "手机": "phone"}   // 展示名 -> 字段路径
    }

调用时把 q 传给 {q}，其余变量用 vars 传。
"""
from __future__ import annotations

import json
import os
import re

from . import net

CONFIG_DIR = None  # 由 datas.base_dir() 决定


def _config_path() -> str:
    from . import datas
    d = os.path.join(datas.writable_dir(), 'config')
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, 'providers.json')


DEFAULT_CONFIG = {
    'custom': [],
    'builtin': {
        'ip': True,
    },
}

# 内置 IP 归属地：ip-api.com 免费版 45 次/分钟，HTTP 明文，无需 key
IP_APIS = [
    'http://ip-api.com/json/{q}?lang=zh-CN&fields=status,message,country,regionName,city,isp,org,as,query',
    'http://ip-api.com/json/{q}?lang=en&fields=status,message,country,regionName,city,isp,org,as,query',
]


def load_config() -> dict:
    p = _config_path()
    if os.path.exists(p):
        try:
            with open(p, 'r', encoding='utf-8') as f:
                cfg = json.load(f)
            if isinstance(cfg, dict):
                cfg.setdefault('custom', [])
                cfg.setdefault('builtin', {'ip': True})
                return cfg
        except Exception:
            pass
    cfg = json.loads(json.dumps(DEFAULT_CONFIG))
    save_config(cfg)
    return cfg


def save_config(cfg: dict) -> str:
    p = _config_path()
    tmp = p + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    if os.path.exists(p):
        os.remove(p)
    os.rename(tmp, p)
    return p


_VAR = re.compile(r'\{(\w+)\}')


def render(tpl: str, variables: dict) -> str:
    """替换 {name}，值做 URL 编码；未提供的变量保持原样。"""
    import urllib.parse

    def rep(m):
        k = m.group(1)
        if k in variables and variables[k] is not None:
            return urllib.parse.quote(str(variables[k]), safe='')
        return m.group(0)

    return _VAR.sub(rep, tpl or '')


def dig(obj, path: str):
    """按 'a.b.0.c' 取值。"""
    if not path:
        return obj
    cur = obj
    for seg in str(path).split('.'):
        if cur is None:
            return None
        if isinstance(cur, list):
            try:
                cur = cur[int(seg)]
            except (ValueError, IndexError):
                return None
        elif isinstance(cur, dict):
            cur = cur.get(seg)
        else:
            return None
    return cur


def _parse_body(text: str, result_type: str):
    rt = (result_type or 'json').lower()
    if rt == 'text':
        return text
    s = text.strip()
    if rt == 'jsonp' or (s and not s.startswith(('{', '['))):
        m = re.search(r'^[\w$.]+\s*\(', s)
        if m:
            s = s[m.end():].rstrip(');\n ')
    try:
        return json.loads(s)
    except Exception:
        return {'_raw': text}


def builtin_ip(q: str, timeout: float = 12.0) -> dict:
    from . import netaddr
    loc = netaddr.parse(q)
    out = {'provider': 'ip-api.com', 'query': q, 'ok': False,
           'offline': loc, 'geo': {}, 'error': ''}
    if loc.get('valid') and loc.get('is_private'):
        out['ok'] = True
        out['geo'] = {'note': '私有地址，无公网归属地'}
        return out
    last = ''
    for tpl in IP_APIS:
        url = tpl.replace('{q}', q)
        try:
            r = net.get(url, timeout=timeout)
            if r.status != 200:
                last = 'HTTP %s' % r.status
                continue
            j = r.json()
            if j.get('status') != 'success':
                last = '接口返回 %s' % j.get('message') or j.get('status')
                continue
            out['ok'] = True
            out['geo'] = {
                '国家': j.get('country', ''),
                '省/州': j.get('regionName', ''),
                '城市': j.get('city', ''),
                '运营商': j.get('isp', ''),
                '机构': j.get('org', ''),
                'AS': j.get('as', ''),
                'IP': j.get('query', ''),
            }
            out['raw'] = j
            return out
        except Exception as e:
            last = '%s: %s' % (type(e).__name__, e)
    out['error'] = '全部内置线路失败：%s' % last
    return out


def run_custom(pid: str, q: str, extra: dict | None = None,
               timeout: float | None = None) -> dict:
    cfg = load_config()
    prov = None
    for p in cfg.get('custom') or []:
        if p.get('id') == pid:
            prov = p
            break
    if prov is None:
        return {'ok': False, 'error': '找不到数据源 %s' % pid}

    variables = {'q': q}
    if extra:
        variables.update(extra)

    url = render(prov.get('url', ''), variables)
    method = (prov.get('method') or 'GET').upper()
    body = prov.get('body')
    if body:
        body = render(str(body), variables)

    try:
        r = net.fetch(url, method=method, data=body,
                      headers=prov.get('headers') or {},
                      timeout=timeout or float(prov.get('timeout') or 15))
    except Exception as e:
        return {'ok': False, 'error': '%s: %s' % (type(e).__name__, e), 'url': url}

    text = r.text
    parsed = _parse_body(text, prov.get('result_type', 'json'))
    node = dig(parsed, prov.get('pick') or '')

    fields = {}
    mapping = prov.get('map') or {}
    if mapping and isinstance(node, (dict, list)):
        for label, path in mapping.items():
            fields[label] = dig(node, path)
    elif isinstance(node, dict):
        fields = dict(node)
    else:
        fields = {'结果': node if node is not None else text[:2000]}

    return {
        'ok': r.status == 200,
        'status': r.status,
        'provider': prov.get('name') or pid,
        'url': url,
        'elapsed': round(r.elapsed, 3),
        'fields': fields,
        'node': node,
        'raw': text[:4000],
        'error': '' if r.status == 200 else 'HTTP %s' % r.status,
    }


def list_all() -> dict:
    cfg = load_config()
    return {
        'builtin': [
            {'id': 'ip', 'name': 'IP 归属地（ip-api.com）', 'kind': 'builtin',
             'desc': '公网 IP → 国家/省/市/运营商/AS。免费版限 45 次/分钟'},
        ],
        'custom': [{'id': p.get('id'), 'name': p.get('name') or p.get('id'),
                    'kind': 'custom', 'method': p.get('method', 'GET'),
                    'url': p.get('url', '')} for p in (cfg.get('custom') or [])],
        'config_path': _config_path(),
    }


DEFAULT_CUSTOM_EXAMPLE = {
    'id': 'demo',
    'name': '示例接口（照这个改）',
    'method': 'GET',
    'url': 'http://api.example.com/query?key=你的密钥&q={q}',
    'headers': {},
    'body': None,
    'timeout': 15,
    'result_type': 'json',
    'pick': 'data',
    'map': {'姓名': 'name', '手机': 'phone', '地址': 'addr'},
}
