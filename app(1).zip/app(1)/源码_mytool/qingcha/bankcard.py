# -*- coding: utf-8 -*-
"""银行卡号校验与归属推断，纯离线。

能确定性做到的：
  - Luhn（模 10）校验
  - 发卡组织判定（按 ISO/IEC 7812 前导数字，规则确定）
  - 长度是否合法
  - 常见 BIN 归属（内置表，覆盖主流银行常用段）
做不到的：任意 BIN 的精确归属需要完整 BIN 库（几十万条），本工具不内置全量。
"""
from __future__ import annotations

# (前缀, 长度上限判断由组织规则决定) —— 按前导数字判定发卡组织
ORG_RULES = [
    # (名称, 判定函数, 合法长度)
    ('Visa', lambda d: d[:1] == '4', (13, 16, 19)),
    ('MasterCard', lambda d: (len(d) >= 2 and 51 <= int(d[:2]) <= 55) or
                             (len(d) >= 4 and 2221 <= int(d[:4]) <= 2720), (16,)),
    ('American Express', lambda d: d[:2] in ('34', '37'), (15,)),
    # 银联必须排在 JCB 之前：356 段在国内实际按银联处理
    ('银联 UnionPay', lambda d: d[:2] == '62' or d[:3] == '356', (16, 17, 18, 19)),
    ('JCB', lambda d: d[:2] == '35', (16, 17, 18, 19)),
    ('Discover', lambda d: d[:2] in ('60', '64', '65') or d[:4] == '6011', (16, 19)),
    ('Diners Club', lambda d: d[:2] in ('30', '36', '38', '39'), (14, 16)),
    ('Maestro', lambda d: d[:2] in ('50', '56', '57', '58', '63', '67'), (12, 13, 16, 18, 19)),
]

# 常见 BIN（6 位）→ (银行, 卡种)。覆盖主流银行的高频段，非全量。
BIN = {
    '622200': ('中国工商银行', '借记卡'), '622202': ('中国工商银行', '借记卡'),
    '622203': ('中国工商银行', '借记卡'), '622208': ('中国工商银行', '借记卡'),
    '621226': ('中国工商银行', '借记卡'), '621225': ('中国工商银行', '借记卡'),
    '955880': ('中国工商银行', '借记卡'), '621723': ('中国工商银行', '借记卡'),
    '622230': ('中国工商银行', '信用卡'), '622210': ('中国工商银行', '信用卡'),
    '621700': ('中国建设银行', '借记卡'), '621081': ('中国建设银行', '借记卡'),
    '436742': ('中国建设银行', '借记卡'), '622280': ('中国建设银行', '借记卡'),
    '622700': ('中国建设银行', '借记卡'), '621466': ('中国建设银行', '信用卡'),
    '622848': ('中国农业银行', '借记卡'), '622845': ('中国农业银行', '借记卡'),
    '622846': ('中国农业银行', '借记卡'), '622828': ('中国农业银行', '借记卡'),
    '955998': ('中国农业银行', '借记卡'), '622836': ('中国农业银行', '信用卡'),
    '621661': ('中国银行', '借记卡'), '621660': ('中国银行', '借记卡'),
    '601382': ('中国银行', '借记卡'), '622760': ('中国银行', '借记卡'),
    '456351': ('中国银行', '信用卡'), '622588': ('招商银行', '借记卡'),
    '621286': ('招商银行', '借记卡'), '622575': ('招商银行', '信用卡'),
    '621799': ('中国邮政储蓄银行', '借记卡'), '622188': ('中国邮政储蓄银行', '借记卡'),
    '621096': ('中国邮政储蓄银行', '借记卡'), '622150': ('中国邮政储蓄银行', '借记卡'),
    '622260': ('交通银行', '借记卡'), '622262': ('交通银行', '借记卡'),
    '621069': ('交通银行', '信用卡'), '622690': ('中信银行', '借记卡'),
    '622691': ('中信银行', '信用卡'), '622521': ('上海浦东发展银行', '借记卡'),
    '622522': ('上海浦东发展银行', '信用卡'), '622622': ('中国民生银行', '借记卡'),
    '622623': ('中国民生银行', '信用卡'), '622909': ('兴业银行', '借记卡'),
    '622908': ('兴业银行', '信用卡'), '622660': ('中国光大银行', '借记卡'),
    '622150': ('中国邮政储蓄银行', '借记卡'), '622630': ('华夏银行', '借记卡'),
    '622568': ('广发银行', '借记卡'), '622155': ('平安银行', '借记卡'),
    '622156': ('平安银行', '信用卡'), '621792': ('上海银行', '借记卡'),
    '622468': ('北京银行', '借记卡'), '621030': ('北京银行', '借记卡'),
    '622315': ('宁波银行', '借记卡'), '622888': ('江苏银行', '借记卡'),
}

# 卡种/性质的前缀补充判断（仅在 BIN 表未命中时兜底）
DEBIT_HINT = ('621', '622', '623', '9558', '9559', '6013', '6205')


def luhn(digits: str) -> bool:
    """Luhn 校验：从右往左，偶数位（1-based 的偶数位）乘 2。"""
    s = 0
    alt = False
    for ch in reversed(digits):
        n = ord(ch) - 48
        if alt:
            n *= 2
            if n > 9:
                n -= 9
        s += n
        alt = not alt
    return s % 10 == 0


def luhn_check_digit(body: str) -> str:
    """给不含校验位的号，算出末尾校验位。"""
    s = 0
    alt = True  # 补一位后，原最后一位变成第二位
    for ch in reversed(body):
        n = ord(ch) - 48
        if alt:
            n *= 2
            if n > 9:
                n -= 9
        s += n
        alt = not alt
    return str((10 - s % 10) % 10)


def organization(d: str) -> str:
    for name, fn, _lens in ORG_RULES:
        try:
            if fn(d):
                return name
        except (ValueError, IndexError):
            continue
    return '未知'


def parse(cardno: str) -> dict:
    digits = ''.join(c for c in str(cardno) if c.isdigit())
    res = {
        'input': cardno, 'digits': digits, 'length': len(digits),
        'valid_luhn': False, 'valid': False, 'errors': [], 'warnings': [],
        'organization': '', 'bin': '', 'bank': '', 'card_type': '',
        'masked': '', 'source': 'offline:Luhn+ISO7812',
    }
    if not digits:
        res['errors'].append('输入为空')
        return res

    res['organization'] = organization(digits)
    res['bin'] = digits[:6]

    lens = (13, 16, 19)
    for name, _fn, ls in ORG_RULES:
        if name == res['organization']:
            lens = ls
            break
    if len(digits) not in lens:
        res['warnings'].append('长度 %d 对 %s 不常规（常见 %s）'
                               % (len(digits), res['organization'],
                                  '/'.join(str(x) for x in lens)))

    res['valid_luhn'] = luhn(digits)

    hit = BIN.get(digits[:6]) or BIN.get(digits[:5]) or BIN.get(digits[:4])
    if hit:
        res['bank'], res['card_type'] = hit
    else:
        res['warnings'].append('BIN %s 不在内置表（%d 条）中，银行归属未知'
                               % (digits[:6], len(BIN)))

    if not res['card_type']:
        for h in DEBIT_HINT:
            if digits.startswith(h):
                res['card_type'] = '借记卡（按前缀推断）'
                break

    if len(digits) >= 10:
        res['masked'] = digits[:6] + '*' * (len(digits) - 10) + digits[-4:]
    else:
        res['masked'] = digits

    res['valid'] = res['valid_luhn'] and res['organization'] != '未知'
    if not res['valid_luhn']:
        res['errors'].append('Luhn 校验不通过（该号不可能是有效卡号）')
    if res['organization'] == '未知':
        res['errors'].append('前导数字不符合任何已知卡组织规则')
    return res


def batch(text: str) -> list:
    out = []
    for line in (text or '').splitlines():
        line = line.strip()
        if line and not line.startswith('#'):
            out.append(parse(line))
    return out
