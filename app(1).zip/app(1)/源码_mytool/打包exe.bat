@echo off
chcp 65001 >nul
cd /d "%~dp0"
title 打包 自查工具箱

where python >nul 2>nul && (set PY=python) || (set PY=py)

%PY% -m PyInstaller --noconfirm --clean --onefile ^
  --name qingcha ^
  --add-data "data;data" ^
  --add-data "web;web" ^
  run.py

echo.
echo 完成：dist\qingcha.exe
pause
