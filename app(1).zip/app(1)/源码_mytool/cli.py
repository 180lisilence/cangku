# -*- coding: utf-8 -*-
"""命令行用法。

    python cli.py list
    python cli.py idcard 11010119900307451X
    python cli.py phone 13800138000 13912345678
    python cli.py ip 8.8.8.8
    python cli.py hash "hello"
    python cli.py --json idcard 11010119900307451X
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from qingcha import registry

ALIAS = {
    'id': 'idcard', 'sfz': 'idcard', '身份证': 'idcard',
    'sjh': 'phone', '手机': 'phone', '手机号': 'phone',
    'bank': 'bankcard', '卡': 'bankcard', '银行卡': 'bankcard',
    'uscc': 'uscc', '信用代码': 'uscc',
    'car': 'plate', '车牌': 'plate',
    'cidr': 'netaddr', '网段': 'netaddr',
    'ip': 'ipgeo', '归属地': 'ipgeo',
    'md5': 'hash', 'sha': 'hash', '哈希': 'hash',
    'b64': 'b64', 'base64': 'b64',
    'url': 'urlc', 'hex': 'hexc',
    'time': 'ts', '时间': 'ts', '时间戳': 'ts',
    'stats': 'stats', '文本': 'stats',
}


def usage():
    print(__doc__)
    print('可用能力：')
    for c in registry.cap_list():
        print('  %-10s %-14s %s' % (c['id'], c['name'], c.get('desc', '')))
    print()
    print('批量：一次传多个参数，或从管道读（每行一条）')
    print('  cat list.txt | python cli.py idcard')


def main():
    argv = sys.argv[1:]
    as_json = False
    if '--json' in argv:
        as_json = True
        argv = [a for a in argv if a != '--json']

    if not argv or argv[0] in ('-h', '--help', 'help'):
        usage()
        return 0
    if argv[0] in ('list', 'ls'):
        for c in registry.cap_list():
            print('%-10s %-14s %s' % (c['id'], c['name'], c.get('desc', '')))
        return 0

    cap = ALIAS.get(argv[0], argv[0])
    vals = argv[1:]
    if not vals and not sys.stdin.isatty():
        vals = [l.strip() for l in sys.stdin.read().splitlines() if l.strip()]
    if not vals and cap != 'ts':
        if cap == 'idgen':
            vals = ['']
        else:
            print('缺少输入内容', file=sys.stderr)
            return 2

    text = '\n'.join(vals)
    res = registry.run(cap, text, {})

    if as_json:
        print(json.dumps(res, ensure_ascii=False, indent=2))
        return 0 if res.get('ok') else 1

    if not res.get('ok'):
        print('出错：%s' % res.get('error'), file=sys.stderr)
        return 1

    for it in res['items']:
        flag = '✓' if it['valid'] is True else ('✗' if it['valid'] is False else '·')
        print('%s %s' % (flag, it['title']))
        for k, v in it['rows']:
            for i, line in enumerate(str(v).splitlines() or ['']):
                print('    %s%s' % ((k + ': ').ljust(18) if i == 0 else ' ' * 18, line))
        for t in it['tags']:
            print('    ! %s' % t)
        if it['note']:
            print('    错误: %s' % it['note'])
        print()
    return 0


if __name__ == '__main__':
    sys.exit(main())
