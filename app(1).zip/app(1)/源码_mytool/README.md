# 自查工具箱 v2.0

界面按「欣社」功能页 1:1 复刻，功能项与原版逐条对齐（**67 项**）。
但底层完全自建：**不调用 xjsgk 任何接口，不需要卡密，不登录**。

核心取舍一句话：**接口形态照搬，数据源你自己给。** 本地能算的全部本机算完；需要数据的走「网关」，你没配网关它就老实说没配，绝不编造结果。

---

## 快速开始

| 方式 | 操作 |
|---|---|
| 免 Python | 双击 `dist\qingcha.exe` |
| 有 Python | 双击 `启动.bat` |
| 命令行 | `python cli.py idcard 110101199003074514` |

启动后自动打开浏览器，居中显示为手机屏。关掉黑窗口即停止。

---

## 界面

三页：**首页**（数据资产概览）、**功能**（原版同款列表）、**我的**（网关设置）。

功能页沿用原版三分类：

- **Free-免费版** — 29 项
- **Pro-高级版** — 20 项
- **Pro-其他功能** — 18 项

每项右侧标一枚小徽章：

- `本地` — 本机就能算出结果，**不需要任何配置**，断网可用
- `需网关` — 必须连你自己的接口

---

## 两类功能，分清楚

### 一、本地能力（24 项，开箱即用）

| 功能 | 说明 |
|---|---|
| 手机号归属地 | 省 + 市 + 区号 + 邮编 + 运营商，内置 **517,259 条号段** |
| 身份证解析 | 归属地精确到区县、生日、性别、周岁/虚岁、生肖、星座、校验位，15 位自动升 18 位 |
| 通用开户 | 自动判断输入是手机号/身份证/车牌/银行卡/邮箱/QQ/信用代码/IP，再给对应的离线解析 |
| 车主查询 / 模糊车小档 | 车牌省份、号牌类型、新能源纯电/非纯电、警用/使领馆/教练/挂车识别 |
| 银行卡归属地 / 三要素 / 四要素 | Luhn 校验、卡组织、内置常见 BIN 归属 |
| 法人查询 / 天眼查法人 | 统一社会信用代码 GB32100 校验 + 登记部门 + 主体类型 + 辖区 |
| 二要素 / 三要素 / 假火飞 / 全国头接口 | 本地做证件与手机号格式校验（一致性核验需网关） |
| 照妖镜 / 敏感核验 / 身份证查询 | 本地证件解析 |
| Q 绑开户 / QQ 关联 | 本地格式校验（绑定关系需网关） |
| 开大头照 | 证件照生成：一寸/二寸/小一寸/大一寸/小二寸/五寸，白蓝红灰底，Canvas 出图 |
| 随机身份证正反面 | 生成合法号码 + 绘制正反面图样，签发机关与有效期随归属地变化 |
| 营业执照生成 | 按信用代码绘制营业执照图样 |
| IP 归属地 / 查本机 IP | 走公开接口 ip-api.com，无需网关 |
| 网页源码下载 | 抓取任意网页源码 |
| IP / 网段计算 | CIDR 全参数 |

> 所有图片均为**排版演示**，图上标注了「图样演示」，不具备任何法律效力。

### 二、需网关（43 项）

姓名开户、王者荣耀、和平精英、猎魔、顺丰系列 7 项、独家系列、微信 ID、短信类、音乐/壁纸/视频解析等。

---

## 网关怎么配

三种方式，任选其一，配一次永久生效（写在 `config/gateway.json`）：

**方式 1：粘贴自动识别（推荐）**
「我的」→ 网关设置 → 最下方粘贴框，把接口信息整段贴进去 → 点「一键识别并保存」。
支持两种格式，会自动提取地址与密钥：

```
http://your-gateway.com|xxxxxxxx          ← base|key
http://api.xxx.com/sgh.php?sgh=138..&key=xx  ← 直接贴一条抓包链接也行
```

**方式 2：命令行注入（启动时带参数）**

```
qingcha.exe --gateway "http://your-gateway.com|xxxxxxxx"
python run.py --gateway http://your-gateway.com xxxxxxxx
```

**方式 3：手动填表**
「我的」→ 网关设置，填两个值：

```
网关地址    http://your-gateway.com     ← base，末尾不带 /
接口密钥    xxxxxxxx                    ← 作为 key 参数发送
```

配置文件在 `config/gateway.json`，也可以直接改：

```json
{
  "base": "http://your-gateway.com",
  "key": "你的密钥",
  "timeout": 15,
  "key_param": "key",
  "paths": {}
}
```

**路径与参数名已按原版对齐**，不需要你重新映射：

| 功能 | 实际请求 |
|---|---|
| 手机号开户 | `GET {base}/sgh.php?sgh=13800138000&key=xxx` |
| 姓名开户 | `GET {base}/xm.php?xm=张三&key=xxx` |
| 三要素 | `GET {base}/3ys.php?name=..&sfz=..&sjh=..&key=xxx` |
| Pro 系列 | `GET {base}/x.php?max=namequery&xm=..&key=xxx` |

个别路径不一样的话，用 `paths` 覆盖：

```json
{ "paths": { "sgh": "v2/phone.php" } }
```

---

## 命令行

```bash
python cli.py list                          # 所有能力
python cli.py idcard 110101199003074514
python cli.py phone 13800138000 13912345678
cat 号码.txt | python cli.py phone          # 批量
python cli.py --json idcard 110101199003074514
```

简写可用：`id`/`sfz`/`身份证`、`sjh`/`手机`、`bank`、`car`/`车牌`、`ip`、`md5`、`b64`、`time`……

---

## URL 直达

浏览器里可以直接跳到某个功能，带参数会自动执行，可存成书签：

```
http://127.0.0.1:8765/#/f/sjhgsd?q=13800138000
http://127.0.0.1:8765/#/f/idcardrand?q=330106
http://127.0.0.1:8765/#/me
```

---

## 数据来源

| 文件 | 内容 | 来源 | 许可 |
|---|---|---|---|
| `data/region.json` | 省/市/区县 3,351 条 | china-division v2.7.0 | MIT |
| `data/phone.dat` | 手机号段 517,259 条 | phone2region 0.0.3 | MIT |

`scripts/build_region.py` 可重新生成区划表。

---

## 目录

```
mytool/
├─ 启动.bat             双击启动
├─ 打包exe.bat          重新打包
├─ run.py               Web 入口
├─ cli.py               命令行
├─ qingcha/
│  ├─ features.py       ★ 67 项功能清单 + 分发
│  ├─ idcard.py         身份证
│  ├─ phone.py          手机号
│  ├─ bankcard.py       银行卡
│  ├─ uscc.py           信用代码
│  ├─ plate.py          车牌
│  ├─ netaddr.py        IP / CIDR
│  ├─ tools.py          哈希 / 编解码
│  ├─ providers.py      可插拔数据源（旧版接口，仍可用）
│  ├─ registry.py       能力注册表（CLI 用）
│  ├─ net.py            自管 HTTP 客户端
│  ├─ datas.py          数据定位
│  └─ server.py         本地服务
├─ data/                离线数据
├─ web/                 前端（浅色 App 风格）
├─ config/              gateway.json / providers.json
└─ dist/qingcha.exe     成品
```

---

## 自检

```bash
python scripts/smoke_features.py   # 67 项全跑一遍
python scripts/smoke.py            # 底层引擎
```

当前结果：**67 项 → 24 项出真实结果 / 43 项未配置网关提示 / 0 问题**。

---

## 三个坑（改代码前必看）

**1. Python 的 `urllib` 会偷读 `HTTP_PROXY`。**
本机装了沙箱代理后，所有 HTTPS 报 `SSL: UNEXPECTED_EOF_WHILE_READING`，而 `curl` 同一地址正常——报错完全看不出是代理的锅。所以 `net.py` 用 `http.client` 自实现，**默认直连**，只有 `MYTOOL_PROXY` 显式设置才走代理。

**2. `phone.dat` 的字符串以 `0x00` 结尾，不是 `0x0a`。**
多数开源实现按 `0x0a` 找结束符，照抄会一次读进整段脏数据。正确的是 `buf.find(b'\x00', offset)`。另外该库对虚商段只做粗分（`1701234` 记为 `op=3` 电信），所以 `phone.py` 对 `170/171/162/165/167/192` 让前缀规则优先。

**3. 身份证末位可以是 `X`，别把字母剔掉再判长度。**
早期版本先 `''.join(c for c in s if c.isdigit())` 再判 18 位，导致 `11010119900307451X` 被误判成「17 位缺校验位」。现在 `features.py::_local_auto` 用原始字符串判长度，并加地区码白名单区分信用代码。

---

## 环境

Python 3.8+（exe 不需要），零第三方依赖，只监听 `127.0.0.1`。
