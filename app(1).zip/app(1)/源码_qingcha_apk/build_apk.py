# -*- coding: utf-8 -*-
"""手工链路构建 qingcha APK（免 Gradle）。"""
import os, glob, subprocess, zipfile, shutil, sys

ROOT = os.path.dirname(os.path.abspath(__file__))
SDK = "D:/Android/Sdk"
BT = os.path.join(SDK, "build-tools", "34.0.0")
ANDROID_JAR = os.path.join(SDK, "platforms", "android-34", "android.jar")
AAPT2 = os.path.join(BT, "aapt2.exe")
ZIPALIGN = os.path.join(BT, "zipalign.exe")
APKSIGNER = os.path.join(BT, "apksigner.bat")
R8JAR = os.path.join(SDK, "cmdline-tools", "latest", "lib", "r8.jar")
JAVAC = "D:/TOOL/jdk/bin/javac.exe"
KEYTOOL = "D:/TOOL/jdk/bin/keytool.exe"
KEYSTORE = os.path.join(ROOT, "debug.keystore")

BUILD = os.path.join(ROOT, "build")
DIST = os.path.join(ROOT, "dist")
COMPILED = os.path.join(BUILD, "compiled.zip")
BASE_APK = os.path.join(BUILD, "base.apk")
GEN = os.path.join(BUILD, "gen")
CLASSES = os.path.join(BUILD, "classes")
DEXDIR = os.path.join(BUILD, "dex")
UNSIGNED = os.path.join(BUILD, "unsigned.apk")
ALIGNED = os.path.join(BUILD, "aligned.apk")
OUT_APK = os.path.join(DIST, "qingcha.apk")


def run(cmd, **kw):
    print(">>", " ".join(cmd) if isinstance(cmd, list) else cmd)
    r = subprocess.run(cmd, shell=kw.get("shell", False), capture_output=True, text=True)
    if r.stdout:
        print(r.stdout)
    if r.returncode != 0:
        print("!! STDERR:", r.stderr)
        sys.exit(1)
    return r


def main():
    os.makedirs(BUILD, exist_ok=True)
    os.makedirs(DIST, exist_ok=True)
    if os.path.exists(COMPILED): os.remove(COMPILED)
    if os.path.exists(BASE_APK): os.remove(BASE_APK)
    shutil.rmtree(GEN, ignore_errors=True)
    shutil.rmtree(CLASSES, ignore_errors=True)
    shutil.rmtree(DEXDIR, ignore_errors=True)
    os.makedirs(GEN, exist_ok=True)
    os.makedirs(CLASSES, exist_ok=True)
    os.makedirs(DEXDIR, exist_ok=True)

    # 1. compile resources
    run([AAPT2, "compile", "--dir", os.path.join(ROOT, "app", "res"), "-o", COMPILED])

    # 2. link + package assets
    run([AAPT2, "link", "-o", BASE_APK, "-I", ANDROID_JAR,
         "--manifest", os.path.join(ROOT, "app", "AndroidManifest.xml"),
         "--java", GEN, "--min-sdk-version", "23", "--target-sdk-version", "34",
         "-A", os.path.join(ROOT, "assets"), COMPILED])

    # 3. javac
    java_files = glob.glob(os.path.join(ROOT, "app", "src", "com", "qingcha", "*.java"))
    rjava = glob.glob(os.path.join(GEN, "**", "R.java"), recursive=True)
    run([JAVAC, "-encoding", "UTF-8", "-source", "8", "-target", "8",
         "-classpath", ANDROID_JAR, "-Xlint:-options", "-d", CLASSES] + java_files + rjava)

    # 4. d8 via r8.jar
    class_files = glob.glob(os.path.join(CLASSES, "**", "*.class"), recursive=True)
    run(["java", "-cp", R8JAR, "com.android.tools.r8.D8", "--release",
         "--min-api", "23", "--lib", ANDROID_JAR, "--output", DEXDIR] + class_files)

    # 5. add dex into base.apk
    dex = os.path.join(DEXDIR, "classes.dex")
    with zipfile.ZipFile(BASE_APK, "a") as z:
        z.write(dex, "classes.dex")
    shutil.copy(BASE_APK, UNSIGNED)

    # 6. zipalign
    run([ZIPALIGN, "-f", "-p", "4", UNSIGNED, ALIGNED])

    # keystore
    if not os.path.exists(KEYSTORE):
        run([KEYTOOL, "-genkeypair", "-v", "-keystore", KEYSTORE, "-alias", "qingcha",
             "-keyalg", "RSA", "-keysize", "2048", "-validity", "10000",
             "-storepass", "android", "-keypass", "android",
             "-dname", "CN=qingcha,O=QC"], shell=False)

    # 7. sign
    run([APKSIGNER, "sign", "--ks", KEYSTORE, "--ks-key-alias", "qingcha",
         "--ks-pass", "pass:android", "--key-pass", "pass:android",
         "--v1-signing-enabled", "true", "--v2-signing-enabled", "true",
         "--out", OUT_APK, ALIGNED], shell=True)

    print("BUILD OK ->", OUT_APK, os.path.getsize(OUT_APK), "bytes")


if __name__ == "__main__":
    main()
