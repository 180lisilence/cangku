package com.qingcha;

import android.content.Context;
import android.webkit.JavascriptInterface;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;

public class JsBridge {
    private final Context ctx;

    public JsBridge(Context c) {
        ctx = c;
    }

    @JavascriptInterface
    public String gwGet(String url) {
        try {
            URL u = new URL(url);
            HttpURLConnection c = (HttpURLConnection) u.openConnection();
            c.setRequestMethod("GET");
            c.setConnectTimeout(15000);
            c.setReadTimeout(15000);
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36");
            int code = c.getResponseCode();
            InputStream in = (code >= 200 && code < 400) ? c.getInputStream() : c.getErrorStream();
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) {
                bos.write(buf, 0, n);
            }
            in.close();
            String body = bos.toString("UTF-8");
            JSONObject j = new JSONObject();
            j.put("status", code);
            j.put("body", body);
            j.put("error", "");
            return j.toString();
        } catch (Exception e) {
            try {
                JSONObject j = new JSONObject();
                j.put("status", 0);
                j.put("body", "");
                j.put("error", e.toString());
                return j.toString();
            } catch (Exception ex) {
                return "{\"status\":0,\"body\":\"\",\"error\":\"err\"}";
            }
        }
    }
}
