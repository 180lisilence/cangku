/* 自查工具箱 APK 前端：功能表内置真实网关，本地算法离线可用 */
(function () {
  'use strict';

  // 从欣社 APK 反编译提取并内置的真实网关
  var GW = {
    base: 'http://api.xjsgk.com',
    key: '1764942045',
    appid: '72',
    key_param: 'key'
  };

  // 功能表（由桌面版 features.py 抽取，67 条）
  var FEATURES = [
 {
  "id": "sgh",
  "name": "手机号开户",
  "en": "Phone Search",
  "tab": "free",
  "kind": "both",
  "local": "phone",
  "endpoint": "sgh.php",
  "max_param": "",
  "desc": "手机号反查机主信息",
  "params": [
   [
    "sgh",
    "手机号",
    "11 位手机号"
   ]
  ]
 },
 {
  "id": "cx",
  "name": "通用开户",
  "en": "General Account",
  "tab": "free",
  "kind": "both",
  "local": "auto",
  "endpoint": "cx.php",
  "max_param": "",
  "desc": "自动识别类型后综合查询",
  "params": [
   [
    "cx",
    "任意内容",
    "手机号 / 身份证 / 车牌 / QQ / 邮箱"
   ]
  ]
 },
 {
  "id": "xm",
  "name": "姓名开户",
  "en": "Name Query",
  "tab": "free",
  "kind": "remote",
  "local": "",
  "endpoint": "xm.php",
  "max_param": "",
  "desc": "姓名反查关联信息",
  "params": [
   [
    "xm",
    "姓名",
    "2-20 位中文"
   ]
  ]
 },
 {
  "id": "wzry",
  "name": "王者荣耀查询",
  "en": "Honor of Kings",
  "tab": "free",
  "kind": "remote",
  "local": "",
  "endpoint": "王者荣耀.php",
  "max_param": "",
  "desc": "按昵称查王者荣耀账号",
  "params": [
   [
    "name",
    "游戏昵称",
    ""
   ],
   [
    "select",
    "第几个",
    "1"
   ]
  ]
 },
 {
  "id": "cph",
  "name": "车主查询",
  "en": "Vehicle Owner",
  "tab": "free",
  "kind": "both",
  "local": "plate",
  "endpoint": "cph.php",
  "max_param": "",
  "desc": "车牌反查车主",
  "params": [
   [
    "cph",
    "车牌号",
    "如 京A12345"
   ]
  ]
 },
 {
  "id": "idphoto",
  "name": "开大头照",
  "en": "ID Photo",
  "tab": "free",
  "kind": "gen",
  "local": "",
  "endpoint": "",
  "max_param": "",
  "desc": "生成证件照（本地绘制）",
  "params": [
   [
    "style",
    "规格",
    "一寸"
   ],
   [
    "bg",
    "底色",
    "白"
   ]
  ]
 },
 {
  "id": "idcardrand",
  "name": "随机身份证正反面",
  "en": "Random ID Card",
  "tab": "free",
  "kind": "gen",
  "local": "",
  "endpoint": "",
  "max_param": "",
  "desc": "生成身份证正反面图样（仅演示排版）",
  "params": [
   [
    "area",
    "地区码",
    "110101"
   ],
   [
    "gender",
    "性别",
    "男"
   ]
  ]
 },
 {
  "id": "qb",
  "name": "Q绑开户",
  "en": "QQ Bind Search",
  "tab": "free",
  "kind": "both",
  "local": "qq",
  "endpoint": "qb.php",
  "max_param": "",
  "desc": "QQ 号反查绑定信息",
  "params": [
   [
    "qb",
    "QQ 号",
    "5-11 位"
   ]
  ]
 },
 {
  "id": "mirror",
  "name": "照妖镜",
  "en": "Mirror",
  "tab": "free",
  "kind": "both",
  "local": "idcard",
  "endpoint": "mghy.php",
  "max_param": "",
  "desc": "证件真实性核验",
  "params": [
   [
    "sfz",
    "身份证号",
    "18 位"
   ]
  ]
 },
 {
  "id": "mghy",
  "name": "敏感核验",
  "en": "Sensitive Verify",
  "tab": "free",
  "kind": "both",
  "local": "idcard",
  "endpoint": "mghy.php",
  "max_param": "",
  "desc": "敏感名单核验",
  "params": [
   [
    "sfz",
    "身份证号",
    "18 位"
   ]
  ]
 },
 {
  "id": "jhf",
  "name": "假火飞",
  "en": "JHF Query",
  "tab": "free",
  "kind": "both",
  "local": "id2",
  "endpoint": "jhf.php",
  "max_param": "",
  "desc": "姓名 + 身份证交叉核验",
  "params": [
   [
    "name",
    "姓名",
    ""
   ],
   [
    "sfz",
    "身份证号",
    ""
   ]
  ]
 },
 {
  "id": "d2",
  "name": "二要素查询",
  "en": "Two-Factor Free",
  "tab": "free",
  "kind": "both",
  "local": "id2",
  "endpoint": "d2.php",
  "max_param": "",
  "desc": "姓名与身份证一致性",
  "params": [
   [
    "name",
    "姓名",
    ""
   ],
   [
    "sfz",
    "身份证号",
    "18 位"
   ]
  ]
 },
 {
  "id": "3ys",
  "name": "三要素查询",
  "en": "Three-Factor Free",
  "tab": "free",
  "kind": "both",
  "local": "id3",
  "endpoint": "3ys.php",
  "max_param": "",
  "desc": "姓名 + 身份证 + 手机一致性",
  "params": [
   [
    "name",
    "姓名",
    ""
   ],
   [
    "sfz",
    "身份证号",
    ""
   ],
   [
    "sjh",
    "手机号",
    ""
   ]
  ]
 },
 {
  "id": "yx",
  "name": "邮箱查询",
  "en": "Email Query",
  "tab": "free",
  "kind": "remote",
  "local": "",
  "endpoint": "yx.php",
  "max_param": "",
  "desc": "邮箱反查关联账号",
  "params": [
   [
    "yx",
    "邮箱",
    "name@example.com"
   ]
  ]
 },
 {
  "id": "fr",
  "name": "法人查询",
  "en": "Legal Person",
  "tab": "free",
  "kind": "both",
  "local": "uscc",
  "endpoint": "fr.php",
  "max_param": "",
  "desc": "企业法人信息",
  "params": [
   [
    "fr",
    "信用代码",
    "18 位"
   ]
  ]
 },
 {
  "id": "sfz",
  "name": "身份证查询",
  "en": "ID Card Query",
  "tab": "free",
  "kind": "both",
  "local": "idcard",
  "endpoint": "sfz.php",
  "max_param": "",
  "desc": "身份证反查关联信息",
  "params": [
   [
    "sfz",
    "身份证号",
    "18 位"
   ]
  ]
 },
 {
  "id": "yhgs",
  "name": "银行卡归属地",
  "en": "Bank Card",
  "tab": "free",
  "kind": "both",
  "local": "bank",
  "endpoint": "yhgs.php",
  "max_param": "",
  "desc": "卡号查发卡行与归属地",
  "params": [
   [
    "yhk",
    "银行卡号",
    ""
   ]
  ]
 },
 {
  "id": "sjhgsd",
  "name": "手机号归属地",
  "en": "Phone Area",
  "tab": "free",
  "kind": "local",
  "local": "phone",
  "endpoint": "sjhgsd.php",
  "max_param": "",
  "desc": "省市区 + 区号 + 运营商（离线）",
  "params": [
   [
    "sjh",
    "手机号",
    "11 位"
   ]
  ]
 },
 {
  "id": "k3",
  "name": "银行卡三要素",
  "en": "Bank 3-Factor",
  "tab": "free",
  "kind": "both",
  "local": "bank",
  "endpoint": "k3.php",
  "max_param": "",
  "desc": "姓名 + 身份证 + 卡号",
  "params": [
   [
    "name",
    "姓名",
    ""
   ],
   [
    "sfz",
    "身份证号",
    ""
   ],
   [
    "yhk",
    "银行卡号",
    ""
   ]
  ]
 },
 {
  "id": "k4",
  "name": "银行卡四要素",
  "en": "Bank 4-Factor",
  "tab": "free",
  "kind": "both",
  "local": "bank",
  "endpoint": "k4.php",
  "max_param": "",
  "desc": "姓名 + 身份证 + 手机 + 卡号",
  "params": [
   [
    "name",
    "姓名",
    ""
   ],
   [
    "sfz",
    "身份证号",
    ""
   ],
   [
    "sjh",
    "手机号",
    ""
   ],
   [
    "yhk",
    "银行卡号",
    ""
   ]
  ]
 },
 {
  "id": "lm",
  "name": "猎魔查询",
  "en": "Name Hunter",
  "tab": "free",
  "kind": "remote",
  "local": "",
  "endpoint": "lm.php",
  "max_param": "",
  "desc": "姓名 + 地区定位",
  "params": [
   [
    "xm",
    "姓名",
    ""
   ],
   [
    "dq",
    "地区",
    "如 广东"
   ]
  ]
 },
 {
  "id": "cxd",
  "name": "模糊车小档",
  "en": "Plate Fuzzy",
  "tab": "free",
  "kind": "both",
  "local": "plate",
  "endpoint": "cxd.php",
  "max_param": "",
  "desc": "支持不完整车牌",
  "params": [
   [
    "cph",
    "车牌（可模糊）",
    "如 京A123"
   ]
  ]
 },
 {
  "id": "hpyj",
  "name": "和平精英",
  "en": "PUBG Mobile",
  "tab": "free",
  "kind": "remote",
  "local": "",
  "endpoint": "hpyj.php",
  "max_param": "",
  "desc": "按昵称查和平精英账号",
  "params": [
   [
    "nc",
    "游戏昵称",
    ""
   ],
   [
    "select",
    "第几个",
    "1"
   ]
  ]
 },
 {
  "id": "tyc",
  "name": "天眼查法人",
  "en": "Tianyancha",
  "tab": "free",
  "kind": "both",
  "local": "uscc",
  "endpoint": "tyc.php",
  "max_param": "",
  "desc": "企业工商信息",
  "params": [
   [
    "xy",
    "信用代码",
    "18 位"
   ]
  ]
 },
 {
  "id": "jdz",
  "name": "全国头接口",
  "en": "Nationwide",
  "tab": "free",
  "kind": "both",
  "local": "id2",
  "endpoint": "jdz.php",
  "max_param": "",
  "desc": "姓名 + 身份证全国库",
  "params": [
   [
    "xm",
    "姓名",
    ""
   ],
   [
    "sfz",
    "身份证号",
    ""
   ]
  ]
 },
 {
  "id": "bu",
  "name": "号码跑线",
  "en": "Number Trace",
  "tab": "free",
  "kind": "remote",
  "local": "",
  "endpoint": "bu.php",
  "max_param": "",
  "desc": "按前后缀补全号码段",
  "params": [
   [
    "prefix",
    "前 3 位",
    "138"
   ],
   [
    "suffix",
    "后 4 位",
    "0000"
   ]
  ]
 },
 {
  "id": "yyzz",
  "name": "营业执照生成",
  "en": "License Gen",
  "tab": "free",
  "kind": "gen",
  "local": "",
  "endpoint": "",
  "max_param": "",
  "desc": "生成营业执照图样（仅排版演示）",
  "params": [
   [
    "qyxy",
    "信用代码或企业名",
    ""
   ]
  ]
 },
 {
  "id": "p_namequery",
  "name": "姓名（独家）",
  "en": "Name Query Pro",
  "tab": "pro",
  "kind": "remote",
  "local": "",
  "endpoint": "",
  "max_param": "namequery",
  "desc": "Pro max 姓名通道",
  "params": [
   [
    "xm",
    "姓名",
    ""
   ]
  ]
 },
 {
  "id": "p_exclusivename",
  "name": "独家姓名",
  "en": "Exclusive Name",
  "tab": "pro",
  "kind": "remote",
  "local": "",
  "endpoint": "",
  "max_param": "exclusivename",
  "desc": "独家姓名库",
  "params": [
   [
    "xm",
    "姓名",
    ""
   ]
  ]
 },
 {
  "id": "p_exclusiveidcard",
  "name": "独家证查名",
  "en": "ID to Name",
  "tab": "pro",
  "kind": "both",
  "local": "",
  "endpoint": "",
  "max_param": "exclusiveidcard",
  "desc": "身份证反查姓名",
  "params": [
   [
    "sfz",
    "身份证号",
    ""
   ]
  ]
 },
 {
  "id": "p_namehunter",
  "name": "垃圾名字猎魔",
  "en": "Name Hunter Pro",
  "tab": "pro",
  "kind": "remote",
  "local": "",
  "endpoint": "",
  "max_param": "namehunter",
  "desc": "低质量数据源扫描",
  "params": [
   [
    "xm",
    "姓名",
    ""
   ]
  ]
 },
 {
  "id": "p_nameidcard",
  "name": "姓名 + 身份证",
  "en": "Name & ID",
  "tab": "pro",
  "kind": "both",
  "local": "id2",
  "endpoint": "",
  "max_param": "nameidcard",
  "desc": "交叉一致性",
  "params": [
   [
    "xm",
    "姓名",
    ""
   ],
   [
    "sfz",
    "身份证号",
    ""
   ]
  ]
 },
 {
  "id": "p_verify",
  "name": "二要素验证",
  "en": "Two-Factor Pro",
  "tab": "pro",
  "kind": "both",
  "local": "id2",
  "endpoint": "",
  "max_param": "verify",
  "desc": "一致性核验",
  "params": [
   [
    "name",
    "姓名",
    ""
   ],
   [
    "idcard",
    "身份证号",
    ""
   ]
  ]
 },
 {
  "id": "p_idcardgender",
  "name": "身份证 + 性别",
  "en": "ID & Gender",
  "tab": "pro",
  "kind": "both",
  "local": "idcard",
  "endpoint": "",
  "max_param": "idcardgender",
  "desc": "校验性别是否相符",
  "params": [
   [
    "sfz",
    "身份证号",
    ""
   ]
  ]
 },
 {
  "id": "p_creditcode",
  "name": "信用代码",
  "en": "Credit Code",
  "tab": "pro",
  "kind": "both",
  "local": "uscc",
  "endpoint": "",
  "max_param": "creditcode",
  "desc": "代码解析与工商信息",
  "params": [
   [
    "xy",
    "信用代码",
    "18 位"
   ]
  ]
 },
 {
  "id": "p_sgh",
  "name": "手机号归属地（Pro）",
  "en": "Phone Area Pro",
  "tab": "pro",
  "kind": "both",
  "local": "phone",
  "endpoint": "",
  "max_param": "sgh",
  "desc": "归属地增强",
  "params": [
   [
    "sjh",
    "手机号",
    ""
   ]
  ]
 },
 {
  "id": "p_phoneprefix",
  "name": "手机号前缀",
  "en": "Phone Prefix",
  "tab": "pro",
  "kind": "both",
  "local": "phone",
  "endpoint": "",
  "max_param": "phoneprefix",
  "desc": "号段反查",
  "params": [
   [
    "sjh",
    "号段前 7 位",
    "1380013"
   ]
  ]
 },
 {
  "id": "p_prefixquery",
  "name": "前缀通用",
  "en": "Prefix Query",
  "tab": "pro",
  "kind": "both",
  "local": "auto",
  "endpoint": "",
  "max_param": "prefixquery",
  "desc": "任意前缀查询",
  "params": [
   [
    "q",
    "前缀",
    ""
   ]
  ]
 },
 {
  "id": "p_cph",
  "name": "车牌（Pro）",
  "en": "Plate Pro",
  "tab": "pro",
  "kind": "both",
  "local": "plate",
  "endpoint": "",
  "max_param": "cph",
  "desc": "车牌反查增强",
  "params": [
   [
    "cph",
    "车牌",
    ""
   ]
  ]
 },
 {
  "id": "p_qqbind",
  "name": "Q 绑查询",
  "en": "QQ Bind",
  "tab": "pro",
  "kind": "both",
  "local": "qq",
  "endpoint": "",
  "max_param": "qqbind",
  "desc": "QQ 绑定关系",
  "params": [
   [
    "qb",
    "QQ 号",
    ""
   ]
  ]
 },
 {
  "id": "p_qqassoc",
  "name": "QQ 号关联",
  "en": "QQ Associate",
  "tab": "pro",
  "kind": "both",
  "local": "qq",
  "endpoint": "",
  "max_param": "qqassoc",
  "desc": "QQ 关联账号",
  "params": [
   [
    "qb",
    "QQ 号",
    ""
   ]
  ]
 },
 {
  "id": "p_wxid",
  "name": "微信 ID",
  "en": "WeChat ID",
  "tab": "pro",
  "kind": "remote",
  "local": "",
  "endpoint": "",
  "max_param": "wxid",
  "desc": "微信绑定查询",
  "params": [
   [
    "wx",
    "微信号或手机号",
    ""
   ]
  ]
 },
 {
  "id": "p_general",
  "name": "综合自由文本",
  "en": "General Pro",
  "tab": "pro",
  "kind": "both",
  "local": "auto",
  "endpoint": "",
  "max_param": "general",
  "desc": "自由文本综合",
  "params": [
   [
    "q",
    "任意内容",
    ""
   ]
  ]
 },
 {
  "id": "p_keyword",
  "name": "关键词查询",
  "en": "Keyword",
  "tab": "pro",
  "kind": "remote",
  "local": "",
  "endpoint": "",
  "max_param": "keyword",
  "desc": "关键词检索",
  "params": [
   [
    "kw",
    "关键词",
    ""
   ]
  ]
 },
 {
  "id": "p_miniappuin",
  "name": "小程序 UIN",
  "en": "MiniApp UIN",
  "tab": "pro",
  "kind": "remote",
  "local": "",
  "endpoint": "",
  "max_param": "miniappuin",
  "desc": "小程序主体反查",
  "params": [
   [
    "q",
    "小程序或链接",
    ""
   ]
  ]
 },
 {
  "id": "p_sessionid",
  "name": "会话 ID",
  "en": "Session ID",
  "tab": "pro",
  "kind": "remote",
  "local": "",
  "endpoint": "",
  "max_param": "sessionid",
  "desc": "会话归属查询",
  "params": [
   [
    "q",
    "会话 ID",
    ""
   ]
  ]
 },
 {
  "id": "p_sfcombo",
  "name": "顺丰·多条件组合",
  "en": "SF Combo",
  "tab": "pro",
  "kind": "remote",
  "local": "",
  "endpoint": "",
  "max_param": "sfcombo",
  "desc": "顺丰数据多条件组合",
  "params": [
   [
    "k1",
    "条件 1",
    ""
   ],
   [
    "k2",
    "条件 2",
    ""
   ],
   [
    "k3",
    "条件 3",
    ""
   ]
  ]
 },
 {
  "id": "p_sfname",
  "name": "顺丰·姓名",
  "en": "SF Name",
  "tab": "pro2",
  "kind": "remote",
  "local": "",
  "endpoint": "",
  "max_param": "sfname",
  "desc": "顺丰姓名检索",
  "params": [
   [
    "xm",
    "姓名",
    ""
   ]
  ]
 },
 {
  "id": "p_sfphone",
  "name": "顺丰·电话",
  "en": "SF Phone",
  "tab": "pro2",
  "kind": "remote",
  "local": "",
  "endpoint": "",
  "max_param": "sfphone",
  "desc": "顺丰电话检索",
  "params": [
   [
    "sjh",
    "手机号",
    ""
   ]
  ]
 },
 {
  "id": "p_sfaddress",
  "name": "顺丰·地址模糊",
  "en": "SF Address",
  "tab": "pro2",
  "kind": "remote",
  "local": "",
  "endpoint": "",
  "max_param": "sfaddress",
  "desc": "模糊地址检索",
  "params": [
   [
    "dz",
    "地址片段",
    ""
   ]
  ]
 },
 {
  "id": "p_sfprovince",
  "name": "顺丰·省份",
  "en": "SF Province",
  "tab": "pro2",
  "kind": "remote",
  "local": "",
  "endpoint": "",
  "max_param": "sfprovince",
  "desc": "按省检索",
  "params": [
   [
    "sf",
    "省份",
    "如 广东"
   ]
  ]
 },
 {
  "id": "p_sfcity",
  "name": "顺丰·城市",
  "en": "SF City",
  "tab": "pro2",
  "kind": "remote",
  "local": "",
  "endpoint": "",
  "max_param": "sfcity",
  "desc": "按市检索",
  "params": [
   [
    "cs",
    "城市",
    "如 深圳"
   ]
  ]
 },
 {
  "id": "p_sfsearch",
  "name": "顺丰·综合",
  "en": "SF Search",
  "tab": "pro2",
  "kind": "remote",
  "local": "",
  "endpoint": "",
  "max_param": "sfsearch",
  "desc": "综合检索",
  "params": [
   [
    "q",
    "任意内容",
    ""
   ]
  ]
 },
 {
  "id": "p_ip",
  "name": "IP 归属地",
  "en": "IP Lookup",
  "tab": "pro2",
  "kind": "local",
  "local": "ip",
  "endpoint": "",
  "max_param": "ip",
  "desc": "联网公开接口，无需网关",
  "params": [
   [
    "ip",
    "IP 地址",
    "8.8.8.8"
   ]
  ]
 },
 {
  "id": "p_myip",
  "name": "查本机 IP",
  "en": "My IP",
  "tab": "pro2",
  "kind": "local",
  "local": "myip",
  "endpoint": "",
  "max_param": "myip",
  "desc": "公网出口 IP（联网）",
  "params": []
 },
 {
  "id": "p_url",
  "name": "网页源码下载",
  "en": "URL Fetch",
  "tab": "pro2",
  "kind": "local",
  "local": "url",
  "endpoint": "",
  "max_param": "url",
  "desc": "抓取页面源码",
  "params": [
   [
    "u",
    "网址",
    "https://example.com"
   ]
  ]
 },
 {
  "id": "p_wallpaper",
  "name": "随机壁纸",
  "en": "Wallpaper",
  "tab": "pro2",
  "kind": "remote",
  "local": "",
  "endpoint": "",
  "max_param": "wallpaper",
  "desc": "随机高清壁纸",
  "params": [
   [
    "q",
    "关键词（可空）",
    ""
   ]
  ]
 },
 {
  "id": "p_music",
  "name": "音乐搜索",
  "en": "Music",
  "tab": "pro2",
  "kind": "remote",
  "local": "",
  "endpoint": "",
  "max_param": "music",
  "desc": "音乐检索",
  "params": [
   [
    "q",
    "歌名或歌手",
    ""
   ]
  ]
 },
 {
  "id": "p_video",
  "name": "视频解析",
  "en": "Video Parse",
  "tab": "pro2",
  "kind": "remote",
  "local": "",
  "endpoint": "",
  "max_param": "video",
  "desc": "短视频去水印解析",
  "params": [
   [
    "u",
    "视频链接",
    ""
   ]
  ]
 },
 {
  "id": "p_phone",
  "name": "短信验证码",
  "en": "SMS Code",
  "tab": "pro2",
  "kind": "remote",
  "local": "",
  "endpoint": "",
  "max_param": "phone",
  "desc": "验证码接收（需网关）",
  "params": [
   [
    "sjh",
    "手机号",
    ""
   ]
  ]
 },
 {
  "id": "p_pressure",
  "name": "短信压测",
  "en": "SMS Pressure",
  "tab": "pro2",
  "kind": "remote",
  "local": "",
  "endpoint": "",
  "max_param": "pressure",
  "desc": "压测（需网关）",
  "params": [
   [
    "sjh",
    "手机号",
    ""
   ]
  ]
 },
 {
  "id": "p_healthfee",
  "name": "健康费",
  "en": "Health Fee",
  "tab": "pro2",
  "kind": "remote",
  "local": "",
  "endpoint": "",
  "max_param": "healthfee",
  "desc": "健康数据检索",
  "params": [
   [
    "q",
    "身份证或手机号",
    ""
   ]
  ]
 },
 {
  "id": "p_committee",
  "name": "居委",
  "en": "Committee",
  "tab": "pro2",
  "kind": "remote",
  "local": "",
  "endpoint": "",
  "max_param": "committee",
  "desc": "居委会归属查询",
  "params": [
   [
    "q",
    "地址或姓名",
    ""
   ]
  ]
 },
 {
  "id": "p_tradevolume",
  "name": "交易量",
  "en": "Trade Volume",
  "tab": "pro2",
  "kind": "remote",
  "local": "",
  "endpoint": "",
  "max_param": "tradevolume",
  "desc": "交易数据查询",
  "params": [
   [
    "q",
    "账号或链接",
    ""
   ]
  ]
 },
 {
  "id": "p_xgv1",
  "name": "XG V1 综合",
  "en": "XG V1",
  "tab": "pro2",
  "kind": "remote",
  "local": "",
  "endpoint": "",
  "max_param": "xgv1",
  "desc": "XG V1 综合通道",
  "params": [
   [
    "q",
    "任意内容",
    ""
   ]
  ]
 },
 {
  "id": "t_idcard",
  "name": "身份证解析",
  "en": "ID Parser",
  "tab": "free",
  "kind": "local",
  "local": "idcard",
  "endpoint": "",
  "max_param": "",
  "desc": "离线全字段解析",
  "params": [
   [
    "q",
    "身份证号",
    "18 位或 15 位"
   ]
  ]
 },
 {
  "id": "t_netaddr",
  "name": "IP / 网段计算",
  "en": "CIDR Calc",
  "tab": "free",
  "kind": "local",
  "local": "netaddr",
  "endpoint": "",
  "max_param": "",
  "desc": "CIDR 全参数",
  "params": [
   [
    "q",
    "IP 或网段",
    "192.168.1.0/24"
   ]
  ]
 }
];

  var TAB_NAMES = { free: '免费版', pro: 'Pro', pro2: 'Pro2' };
  var current = null;

  function $(s) { return document.querySelector(s); }
  function h(tag, cls, txt) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (txt !== undefined && txt !== null) e.textContent = txt;
    return e;
  }
  function pad2(n) { return n < 10 ? '0' + n : '' + n; }

  // ---------------- 本地算法 ----------------
  function idcardParse(raw) {
    var id = (raw || '').trim().toUpperCase();
    var errors = [], warnings = [];
    var valid = true, given, expect, birth = '', gender = '', age = '', zodiac = '', constellation = '', version = '';
    var w = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2];
    var codes = '10X98765432';
    if (/^\d{15}$/.test(id)) {
      version = '15 位（已升 18 位）';
      var yy = id.substr(6, 2), mm = id.substr(8, 2), dd = id.substr(10, 2);
      var s = id.substr(0, 6) + '19' + yy + mm + dd + id.substr(12, 3);
      var sum15 = 0;
      for (var i = 0; i < 17; i++) sum15 += (+s[i]) * w[i];
      id = s + codes[sum15 % 11];
    }
    if (!/^\d{17}[0-9X]$/.test(id)) {
      return { valid: false, errors: ['号码格式不正确（应为 18 位）'], given: '', expect: '', birth: '', gender: '', age: '', zodiac: '', constellation: '', version: '' };
    }
    version = version || '18 位';
    var sum = 0;
    for (var i = 0; i < 17; i++) sum += (+id[i]) * w[i];
    expect = codes[sum % 11];
    given = id[17];
    if (expect !== given) { valid = false; errors.push('校验位错误（应为 ' + expect + '）'); }
    var y = +id.substr(6, 4), m = +id.substr(10, 2), d = +id.substr(12, 2);
    birth = y + '-' + pad2(m) + '-' + pad2(d);
    gender = (+id[16] % 2 === 1) ? '男' : '女';
    age = ageFrom(y, m, d);
    zodiac = zodiacOf(y);
    constellation = constellationOf(m, d);
    return { valid: valid, errors: errors, warnings: warnings, given: given, expect: expect, birth: birth, gender: gender, age: age, zodiac: zodiac, constellation: constellation, version: version };
  }

  function ageFrom(y, m, d) {
    var now = new Date();
    var a = now.getFullYear() - y;
    if (now.getMonth() + 1 < m || (now.getMonth() + 1 === m && now.getDate() < d)) a--;
    return a >= 0 && a < 150 ? a : '—';
  }
  function zodiacOf(y) {
    var z = ['鼠', '牛', '虎', '兔', '龙', '蛇', '马', '羊', '猴', '鸡', '狗', '猪'];
    return z[(y - 4) % 12];
  }
  function constellationOf(m, d) {
    var c = [[1, 20, '水瓶'], [2, 19, '双鱼'], [3, 21, '白羊'], [4, 20, '金牛'], [5, 21, '双子'], [6, 22, '巨蟹'], [7, 23, '狮子'], [8, 23, '处女'], [9, 23, '天秤'], [10, 24, '天蝎'], [11, 23, '射手'], [12, 22, '摩羯'], [12, 32, '摩羯']];
    for (var i = 0; i < c.length; i++) { if (m === c[i][0] && d >= c[i][1]) return c[i][2]; if (m < c[i][0]) return c[i - 1] ? c[i - 1][2] : '摩羯'; }
    return '摩羯';
  }

  function netaddrParse(s) {
    s = (s || '').trim();
    var m = s.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})(\/(\d{1,2}))?$/);
    if (!m) return { valid: false, errors: ['不是合法 IPv4 地址'], cidr: null };
    var ip = [+m[1], +m[2], +m[3], +m[4]];
    if (ip.some(function (o) { return o > 255; })) return { valid: false, errors: ['八位组超出 0-255'], cidr: null };
    var prefix = m[6] ? +m[6] : 32;
    if (prefix < 0 || prefix > 32) return { valid: false, errors: ['前缀长度非法'], cidr: null };
    function ip2int(a) { return ((a[0] * 256 + a[1]) * 256 + a[2]) * 256 + a[3]; }
    function int2ip(n) { return [(n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255].join('.'); }
    var ipInt = ip2int(ip);
    var mask = prefix === 0 ? 0 : ((0xFFFFFFFF << (32 - prefix)) >>> 0);
    var netInt = (ipInt & mask) >>> 0;
    var bcastInt = prefix === 0 ? 0xFFFFFFFF : (netInt | (~mask >>> 0)) >>> 0;
    var num = prefix === 32 ? 1 : (prefix === 0 ? 4294967296 : Math.pow(2, 32 - prefix));
    var usable = prefix >= 31 ? num : num - 2;
    var first = prefix >= 31 ? netInt : (netInt + 1) >>> 0;
    var last = prefix >= 31 ? bcastInt : (bcastInt - 1) >>> 0;
    return {
      valid: true, errors: [], cidr: {
        network: int2ip(netInt), broadcast: int2ip(bcastInt), netmask: int2ip(mask),
        prefixlen: prefix, num_addresses: num, usable_hosts: usable,
        first_host: int2ip(first), last_host: int2ip(last)
      }
    };
  }

  var PLATE_PROV = '京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领港澳台';
  function plateParse(p) {
    p = (p || '').trim().toUpperCase();
    var errors = [], valid = true;
    if (PLATE_PROV.indexOf(p[0]) < 0) { valid = false; errors.push('省份简称不合法'); }
    var re = /^[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领A-Z][A-Z][A-Z0-9]{4,5}[A-Z0-9挂学警港澳领]$/;
    if (!re.test(p)) { valid = false; errors.push('车牌格式不合法'); }
    var energy = /[DF]$/.test(p) ? '新能源' : '普通燃油';
    return { valid: valid, errors: errors, province: p[0] || '', energy: energy };
  }

  var USCC_MAP = '0123456789ABCDEFGHJKLMNPQRTUWXY';
  var USCC_W = [1, 3, 9, 27, 19, 26, 16, 17, 20, 29, 25, 13, 8, 24, 10, 30, 28];
  var USCC_DEPT = { '1': '工商', '2': '民政', '3': '机构编制', '4': '卫健', '5': '宗教', '6': '工会', '7': '司法行政', '8': '其他', '9': '农业合作社' };
  function usccParse(code) {
    code = (code || '').trim().toUpperCase();
    var errors = [], valid = true;
    if (code.length !== 18) { valid = false; errors.push('应为 18 位统一社会信用代码'); }
    var sum = 0;
    for (var i = 0; i < 17; i++) {
      var v = USCC_MAP.indexOf(code[i]);
      if (v < 0) { valid = false; errors.push('第 ' + (i + 1) + ' 位含非法字符'); break; }
      sum += v * USCC_W[i];
    }
    var c = (31 - (sum % 31)) % 31;
    var expect = USCC_MAP[c];
    var given = code[17];
    if (expect !== given) { valid = false; errors.push('校验位错误（应为 ' + expect + '）'); }
    return { valid: valid, errors: errors, normalized: code, dept: USCC_DEPT[code[0]] || '?', category: '—', check_given: given, check_expect: expect };
  }

  function luhn(num) {
    var s = 0, alt = false;
    for (var i = num.length - 1; i >= 0; i--) {
      var d = +num[i];
      if (isNaN(d)) return false;
      if (alt) { d *= 2; if (d > 9) d -= 9; }
      s += d; alt = !alt;
    }
    return s % 10 === 0;
  }
  function maskCard(v) { return v.length > 8 ? v.substr(0, 6) + '****' + v.substr(-4) : v; }
  function bankParse(v) {
    v = (v || '').replace(/\s/g, '');
    var errors = [], valid = true;
    if (!/^\d{12,19}$/.test(v)) { valid = false; errors.push('卡号位数异常'); }
    var ok = luhn(v);
    if (!ok) { valid = false; errors.push('Luhn 校验不通过'); }
    var org = '未知';
    if (v[0] === '4') org = 'Visa';
    else if (v[0] === '5' || (v[0] === '2' && +v.substr(0, 2) >= 22 && +v.substr(0, 2) <= 27)) org = 'MasterCard';
    else if (v[0] === '6') org = 'UnionPay';
    else if (v[0] === '3' && (v[1] === '4' || v[1] === '7')) org = 'Amex';
    else if (v[0] === '3') org = 'Diners/JCB';
    return { valid: valid, errors: errors, masked: maskCard(v), organization: org, luhn: ok };
  }

  var PHONE_OP = {
    '130': '联通', '131': '联通', '132': '联通', '155': '联通', '156': '联通', '185': '联通', '186': '联通', '145': '联通', '176': '联通',
    '133': '电信', '153': '电信', '180': '电信', '181': '电信', '189': '电信', '177': '电信', '173': '电信', '199': '电信',
    '134': '移动', '135': '移动', '136': '移动', '137': '移动', '138': '移动', '139': '移动', '150': '移动', '151': '移动', '152': '移动',
    '157': '移动', '158': '移动', '159': '移动', '182': '移动', '183': '移动', '184': '移动', '187': '移动', '188': '移动', '178': '移动', '198': '移动'
  };
  function phoneParse(v) {
    v = (v || '').trim();
    var errors = [], valid = /^1\d{10}$/.test(v);
    if (!valid) errors.push('不是 11 位手机号');
    var seg = v.substr(0, 3);
    var op = PHONE_OP[seg] || (v[0] === '1' ? '未知运营商' : '—');
    return { valid: valid, errors: errors, seg7: v.substr(0, 7), operator: op };
  }
  function qqParse(v) {
    v = (v || '').trim();
    var valid = /^\d{5,11}$/.test(v);
    return { valid: valid, errors: valid ? [] : ['QQ 号应为 5-11 位数字'] };
  }

  function runLocal(type, params, f) {
    var blocks = [];
    var first = firstVal(params);
    function blk(title, rows, state, note) { blocks.push({ title: title, rows: rows, state: state, note: note || '' }); }

    if (type === 'idcard' || type === 'id2' || type === 'id3') {
      var r = idcardParse(first);
      var rows = [];
      if (r.birth) rows.push(['出生日期', r.birth]);
      rows.push(['性别', r.gender]);
      if (r.age !== '') rows.push(['周岁', r.age]);
      if (r.zodiac) rows.push(['生肖', r.zodiac]);
      if (r.constellation) rows.push(['星座', r.constellation]);
      rows.push(['校验位(给定)', r.given]);
      rows.push(['校验位(应为)', r.expect]);
      if (r.version) rows.push(['号码版本', r.version]);
      blk((f && f.local === 'id2') ? '身份证本地校验' : '离线解析结果', rows, r.valid, r.errors.join('；'));
      if (type === 'id3' && params.sjh) {
        var pr = phoneParse(params.sjh);
        blk('手机号本地校验', [['手机号', params.sjh], ['运营商', pr.operator]], pr.valid, pr.errors.join('；'));
      }
      return blocks;
    }
    if (type === 'netaddr') {
      var n = netaddrParse(first);
      if (!n.valid) { blk('离线计算结果', [], false, n.errors.join('；')); return blocks; }
      var c = n.cidr;
      blk('离线计算结果', [
        ['网络地址', c.network], ['广播地址', c.broadcast], ['子网掩码', c.netmask],
        ['前缀长度', '/' + c.prefixlen], ['地址总数', c.num_addresses],
        ['可用主机', c.usable_hosts], ['首地址', c.first_host], ['末地址', c.last_host]
      ], true);
      return blocks;
    }
    if (type === 'plate') {
      var p = plateParse(first);
      blk('离线解析结果', [['省份', p.province], ['能源类型', p.energy]], p.valid, p.errors.join('；'));
      return blocks;
    }
    if (type === 'uscc') {
      var u = usccParse(first);
      blk('离线解析结果', [
        ['标准化', u.normalized], ['登记部门', u.dept], ['校验位(给定)', u.check_given], ['校验位(应为)', u.check_expect]
      ], u.valid, u.errors.join('；'));
      return blocks;
    }
    if (type === 'bank') {
      var b = bankParse(params.yhk || params.yhk === '' ? params.yhk : first);
      blk('离线校验结果', [
        ['掩码号', b.masked], ['卡组织', b.organization], ['Luhn 校验', b.luhn ? '通过' : '不通过']
      ], b.valid, b.errors.join('；'));
      return blocks;
    }
    if (type === 'phone') {
      var ph = phoneParse(first);
      blk('离线查询结果', [['号码', first], ['号段', ph.seg7], ['运营商', ph.operator]], ph.valid, ph.errors.join('；'));
      return blocks;
    }
    if (type === 'qq') {
      var q = qqParse(first);
      blk('离线结果', [['QQ 号', first], ['位数', first.length]], q.valid, q.errors.join('；'));
      return blocks;
    }
    if (type === 'auto') {
      if (/^1\d{10}$/.test(first)) { var pa = phoneParse(first); blk('自动识别：手机号', [['运营商', pa.operator]], pa.valid); }
      else if (/^\d{17}[0-9X]$/.test(first) || /^\d{15}$/.test(first)) { var ia = idcardParse(first); blk('自动识别：身份证', [['出生', ia.birth], ['性别', ia.gender]], ia.valid); }
      else if (PLATE_PROV.indexOf(first[0]) >= 0) { var pla = plateParse(first); blk('自动识别：车牌', [['省份', pla.province]], pla.valid); }
      else if (/^\d{5,11}$/.test(first)) { blk('自动识别：QQ', [['位数', first.length]], true); }
      else if (first.indexOf('@') >= 0) { blk('自动识别：邮箱', [], true); }
      else { blk('自动识别', [['内容', first]], true, '未能识别具体类型，将走网关综合查询'); }
      return blocks;
    }
    if (type === 'ip' || type === 'myip') {
      var url = 'http://ip-api.com/json/' + (type === 'myip' ? '' : encodeURIComponent(first)) + '?lang=zh-CN&fields=status,country,regionName,city,isp,query';
      var res = JSON.parse(QC.gwGet(url));
      var j = safeJson(res.body);
      if (res.status === 200 && j && j.status === 'success') {
        blk('联网查询结果', [['IP', j.query], ['国家', j.country], ['省/州', j.regionName], ['城市', j.city], ['运营商', j.isp]], true);
      } else {
        blk('联网查询失败', [], false, (j && j.message) || ('HTTP ' + res.status) || res.error);
      }
      return blocks;
    }
    if (type === 'url') {
      var r2 = JSON.parse(QC.gwGet(first));
      blk('抓取结果', [['HTTP 状态', r2.status], ['Content-Type', ''], ['返回长度', (r2.body || '').length + ' 字符']], r2.status === 200, r2.error);
      return blocks;
    }
    return blocks;
  }

  function safeJson(s) { try { return JSON.parse(s); } catch (e) { return null; } }
  function firstVal(p) { for (var k in p) if (p[k]) return p[k]; return ''; }

  // ---------------- 网关 ----------------
  function buildUrl(f, params) {
    var base = GW.base.replace(/\/+$/, '');
    var q = {};
    var path;
    if (f.max_param) { path = 'x.php'; q['max'] = f.max_param; }
    else { path = f.endpoint || (f.id + '.php'); }
    for (var k in params) if (params[k] !== '') q[k] = params[k];
    if (GW.appid) q['appid'] = GW.appid;
    if (GW.key) q[GW.key_param] = GW.key;
    var qs = Object.keys(q).map(function (k) { return encodeURIComponent(k) + '=' + encodeURIComponent(q[k]); }).join('&');
    return base + '/' + path + '?' + qs;
  }
  function gatewayBlock(res, url) {
    var rows = [['请求地址', url], ['HTTP 状态', String(res.status)]];
    var note = '', state = res.status === 200;
    if (res.error) { note = res.error; state = false; }
    else if (res.body && res.body.trim()[0] === '{') {
      var j = safeJson(res.body);
      if (j) {
        note = j.message || j.msg || '';
        if (j.code !== undefined && j.code !== null && j.code !== 200 && j.code !== 0 && j.code !== '200' && j.code !== '0') state = false;
      }
    }
    return { title: '接口返回', rows: rows, state: state, note: note, raw: res.body };
  }

  // ---------------- gen 画布 ----------------
  function runGen(f, params, mount) {
    var cv = document.createElement('canvas');
    cv.style.margin = '10px auto';
    if (f.id === 'idphoto') {
      var sizes = { '一寸': [295, 413], '二寸': [413, 579], '小一寸': [260, 378], '大一寸': [390, 567], '小二寸': [413, 531], '五寸': [1050, 1499] };
      var sp = params.style || '一寸';
      var w = (sizes[sp] || sizes['一寸'])[0], hh = (sizes[sp] || sizes['一寸'])[1];
      var col = { '白': '#ffffff', '蓝': '#438edb', '红': '#d93a3a', '灰': '#d8d8d8' }[params.bg || '白'] || '#ffffff';
      cv.width = w / 3; cv.height = hh / 3;
      var cx = cv.getContext('2d');
      cx.fillStyle = col; cx.fillRect(0, 0, cv.width, cv.height);
      cx.fillStyle = '#333'; cx.font = '12px sans-serif';
      cx.fillText(sp + ' ' + w + 'x' + hh, 8, 22);
      mount.appendChild(cv);
      mount.appendChild(noteBox('本地绘制，不上传任何照片', false));
      return;
    }
    if (f.id === 'idcardrand') {
      var no = randomIdcard(params.area || '110101', params.gender || '男');
      cv.width = 320; cv.height = 200;
      drawCard(cv, no, '示例姓名', '北京市市辖区', '1990.01.01', params.gender || '男');
      mount.appendChild(cv);
      mount.appendChild(noteBox('生成号码：' + no + '（校验位合法，仅演示排版）', false));
      return;
    }
    if (f.id === 'yyzz') {
      cv.width = 340; cv.height = 240;
      var c = cv.getContext('2d');
      c.fillStyle = '#fff'; c.fillRect(0, 0, 340, 240);
      c.strokeStyle = '#c00'; c.lineWidth = 3; c.strokeRect(8, 8, 324, 224);
      c.fillStyle = '#c00'; c.font = 'bold 20px sans-serif'; c.textAlign = 'center';
      c.fillText('营业执照', 170, 50);
      c.fillStyle = '#333'; c.font = '13px sans-serif';
      c.fillText('名称：' + (params.qyxy || '示例企业（个体）'), 170, 100);
      c.fillText('统一社会信用代码：' + (params.qyxy && /[0-9A-Z]{18}/.test(params.qyxy) ? params.qyxy.toUpperCase() : randomUSCC()), 170, 140);
      c.fillText('（仅排版演示，不具备法律效力）', 170, 190);
      mount.appendChild(cv);
      return;
    }
  }

  function drawCard(cv, no, name, addr, birth, gender) {
    var c = cv.getContext('2d');
    c.fillStyle = '#f4f1e8'; c.fillRect(0, 0, 320, 200);
    c.strokeStyle = '#b00'; c.lineWidth = 4; c.strokeRect(4, 4, 312, 192);
    c.fillStyle = '#222'; c.font = 'bold 16px sans-serif';
    c.fillText('居民身份证', 16, 30);
    c.font = '13px sans-serif';
    c.fillText('姓名 ' + name, 16, 64);
    c.fillText('性别 ' + gender + '  出生 ' + birth, 16, 90);
    c.fillText('住址 ' + addr, 16, 116);
    c.fillText('公民身份号码', 16, 150);
    c.font = 'bold 14px monospace';
    c.fillText(no, 16, 172);
  }
  function randomIdcard(area, gender) {
    area = (area || '110101').substr(0, 6);
    var y = 1980 + Math.floor(Math.random() * 25);
    var m = 1 + Math.floor(Math.random() * 12), d = 1 + Math.floor(Math.random() * 28);
    var seq = (gender === '女' ? 2 : 1) * (1 + Math.floor(Math.random() * 499));
    var s = area + '' + y + pad2(m) + pad2(d) + pad3(seq);
    var w = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2], codes = '10X98765432';
    var sum = 0; for (var i = 0; i < 17; i++) sum += (+s[i]) * w[i];
    return s + codes[sum % 11];
  }
  function pad3(n) { n = '' + n; while (n.length < 3) n = '0' + n; return n; }
  function randomUSCC() {
    var map = '0123456789ABCDEFGHJKLMNPQRTUWXY';
    var body = '91110108';
    for (var i = 0; i < 9; i++) body += map[Math.floor(Math.random() * map.length)];
    var w = [1, 3, 9, 27, 19, 26, 16, 17, 20, 29, 25, 13, 8, 24, 10, 30, 28], sum = 0;
    for (var i = 0; i < 17; i++) sum += map.indexOf(body[i]) * w[i];
    return body + map[(31 - (sum % 31)) % 31];
  }

  function noteBox(text, bad) {
    var n = h('div', 'note' + (bad ? ' bad' : ''), text);
    return n;
  }

  // ---------------- UI ----------------
  function renderTabs() {
    var nav = $('#tabs'); nav.innerHTML = '';
    ['free', 'pro', 'pro2'].forEach(function (t) {
      var b = h('button', t === 'free' ? 'active' : '', TAB_NAMES[t]);
      b.onclick = function () { selectTab(t); };
      b.dataset.tab = t;
      nav.appendChild(b);
    });
  }
  var activeTab = 'free';
  function selectTab(t) {
    activeTab = t;
    document.querySelectorAll('#tabs button').forEach(function (b) {
      b.className = b.dataset.tab === t ? 'active' : '';
    });
    renderList();
  }
  function renderList() {
    var list = $('#list'); list.innerHTML = '';
    FEATURES.filter(function (f) { return f.tab === activeTab; }).forEach(function (f) {
      var item = h('div', 'item');
      var left = h('div');
      left.appendChild(h('div', 'name', f.name));
      if (f.en) left.appendChild(h('div', 'en', f.en));
      var tag = h('span', 'tag ' + f.tab, TAB_NAMES[f.tab]);
      item.appendChild(left); item.appendChild(tag);
      item.onclick = function () { selectFeature(f); };
      list.appendChild(item);
    });
  }
  function selectFeature(f) {
    current = f;
    $('#list').classList.add('hidden');
    $('#panel').classList.remove('hidden');
    $('#ftitle').textContent = f.name;
    $('#fdesc').textContent = f.desc || '';
    var form = $('#form'); form.innerHTML = '';
    (f.params || []).forEach(function (p) {
      var field = h('div', 'field');
      field.appendChild(h('label', null, p[1] + (p[2] ? '（' + p[2] + '）' : '')));
      var inp = document.createElement('input');
      inp.type = 'text'; inp.placeholder = p[2] || ''; inp.dataset.k = p[0];
      field.appendChild(inp); form.appendChild(field);
    });
    $('#result').innerHTML = '';
  }
  function collectParams() {
    var params = {};
    document.querySelectorAll('#form input').forEach(function (i) { params[i.dataset.k] = i.value.trim(); });
    return params;
  }
  function doQuery() {
    var f = current; if (!f) return;
    var params = collectParams();
    $('#result').innerHTML = '<div class="muted">查询中…</div>';
    var blocks = [];
    var localType = (f.kind === 'local' || f.kind === 'both') ? f.local : '';
    if (localType) {
      var lb = runLocal(localType, params, f);
      if (lb) blocks = blocks.concat(lb);
    }
    if (f.kind === 'gen') {
      $('#result').innerHTML = '';
      runGen(f, params, $('#result'));
      return;
    }
    if (f.kind === 'remote' || f.kind === 'both') {
      var url = buildUrl(f, params);
      var res = JSON.parse(QC.gwGet(url));
      blocks.push(gatewayBlock(res, url));
    }
    renderResult(blocks);
  }
  function renderResult(blocks) {
    var box = $('#result'); box.innerHTML = '';
    blocks.forEach(function (b) {
      var card = h('div', 'block');
      var head = h('div', 'bt');
      var dot = h('span', 'dot' + (b.state === true ? '' : (b.state === false ? ' bad' : ' none')));
      head.appendChild(dot); head.appendChild(h('span', null, b.title));
      card.appendChild(head);
      (b.rows || []).forEach(function (r) {
        if (r[1] === '' || r[1] === null || r[1] === undefined) return;
        var row = h('div', 'row');
        row.appendChild(h('span', 'k', r[0]));
        row.appendChild(h('span', 'v', String(r[1])));
        card.appendChild(row);
      });
      if (b.note) card.appendChild(noteBox(b.note, b.state === false));
      if (b.raw) {
        var details = document.createElement('details');
        details.className = 'raw';
        var sum = document.createElement('summary');
        sum.textContent = '原始返回';
        details.appendChild(sum);
        var pre = document.createElement('pre');
        pre.textContent = b.raw.length > 4000 ? b.raw.substr(0, 4000) + ' …' : b.raw;
        details.appendChild(pre);
        card.appendChild(details);
      }
      box.appendChild(card);
    });
    if (!blocks.length) box.innerHTML = '<div class="muted">无可显示结果</div>';
  }

  $('#back').onclick = function () {
    $('#panel').classList.add('hidden');
    $('#list').classList.remove('hidden');
  };
  $('#run').onclick = doQuery;

  // 测试钩子：浏览器中 module 未定义，不影响运行；仅 Node 预验证可用
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
      idcardParse: idcardParse, netaddrParse: netaddrParse, usccParse: usccParse,
      bankParse: bankParse, phoneParse: phoneParse, buildUrl: buildUrl,
      GW: GW, FEATURES: FEATURES
    };
  }

  renderTabs();
  renderList();
})();
